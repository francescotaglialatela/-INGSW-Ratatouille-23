package com.example.demo.DAO;

public interface Addetto_salaDAO {

}
