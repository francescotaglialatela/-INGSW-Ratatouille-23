package com.example.demo.DAO;

public interface AmministratoreDAO {
	public boolean creazioneutenza(String nome,String cognome,String password,String email,String ruolo);
	/*public boolean presenzautenza(String email,String password);*/
}
