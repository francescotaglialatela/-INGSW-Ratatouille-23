package com.example.demo.DAO;

public interface AutenticazioneDAO {
	
	public boolean login(String email,String password);

	public int verifica_primo_accesso(String email);

	public void update_password(String email, String password);

	public boolean verifica_esistenza_email(String email);

	
}