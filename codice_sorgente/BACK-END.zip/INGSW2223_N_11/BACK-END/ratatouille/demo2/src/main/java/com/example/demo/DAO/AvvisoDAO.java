package com.example.demo.DAO;

import java.util.ArrayList;

import com.example.demo.Model.Avviso;

public interface AvvisoDAO {
	public ArrayList<String> searchMyMessage(String myEmail, boolean nascosto);
    public ArrayList<String> openMessage(int idAvviso, String myEmail);
	
	public boolean setAvvisoVisualizzato(String myEmail, int idAvviso);
	
	public int searchLastId();
	public boolean setAvvisoNascosto(String myEmail,int idAvviso);
	public ArrayList<String> searchEmail(String myEmail);
	public boolean sendMessage(Avviso avviso);
	public int countNewMessage(String myEmail);

}
