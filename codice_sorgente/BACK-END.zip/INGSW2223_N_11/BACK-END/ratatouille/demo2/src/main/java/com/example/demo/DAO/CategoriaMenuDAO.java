package com.example.demo.DAO;
import java.util.ArrayList;

import com.example.demo.Model.CategoriaMenu;


public interface CategoriaMenuDAO {
	public ArrayList<String> getCategorieDAO();
	public int numerosottocategorie(String nomeCategoria);
	public void settaggioposizionicategorie(String nomeCategoria,String posizione);
	public ArrayList<String> sottocategorieofCategoria(String nomeCategoria);
	public ArrayList<String> elementidellacategoria(String nomeCategoria);
	public void rimuovielementodellacategoria(String nomelementomenu);
	public ArrayList<String> getelementimacrocategoria(String nomeCategoria);
	public void eliminazionesottoCategoria(String nomeCategoria);
	public ArrayList<String> getelementi_senza_categoria();
	public int ultima_posizione_elemento_nellacategoria(String nomeCategoria);
	public void eliminazionemacroCategoria_e_sottocategorie(String nomeCategoria);
	public void inserisciCategoria(CategoriaMenu categoria);
	public ArrayList<String> getCategorieESottocatgorie();
	public void settaggio_elementi_senza_categoria(String nome_piatto, int posizione);
	public boolean verifica_macrocategoria(String nomecategoria);
	public void inserimento_piatto_nella_macro_categoria(String nome_categoria,String nomepiatto);
	public int posizione_categoria(String nome_categoria);
	public void inserimento_piatto_nella_sottocategoria(String nome_categoria, String nomepiatto);
	public String getCategoria_della_sottocategoria(String nome_sottocategoria);
	void inserimento_piatto_senza_categoria(String nomepiatto);
	void rimuovielementodallacategoria_e_non_dal_menu(String nomelementomenu);
}
