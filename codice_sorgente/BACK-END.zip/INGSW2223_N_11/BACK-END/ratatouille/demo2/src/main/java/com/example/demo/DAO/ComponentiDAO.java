package com.example.demo.DAO;

import com.example.demo.Model.Componenti;

public interface ComponentiDAO {
	public boolean verifica_esistenza_componente(String email);
	public boolean insert_utenza(Componenti componente);
	public String getRuolo_utente_autenticato(String email);
	public String getNomeUtente(String email);
}
