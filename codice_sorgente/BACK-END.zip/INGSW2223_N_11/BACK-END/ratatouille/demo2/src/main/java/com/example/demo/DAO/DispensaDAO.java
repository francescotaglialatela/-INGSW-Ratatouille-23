package com.example.demo.DAO;

import java.util.ArrayList;

import com.example.demo.Model.Prodotto;
import com.example.demo.Model.ProdottoOpenFood;

public interface DispensaDAO {
	public ArrayList<Prodotto> getProdottiDispensa();
	public ArrayList<Prodotto> getProdottiDispensaFiltered(String filtro);
	public ArrayList<ProdottoOpenFood> getProdottiOpenFood();
	public ArrayList<ProdottoOpenFood> getProdottiOpenFoodFiltered(String filtro);
	public ProdottoOpenFood getProdottiOpenFoodBarcode(String filtro);
	public void aumentaQta(String id, float qta);
	public void eliminaProdotto(String id);
	public boolean insertDispensa(String codiceabarre,String nome,String ingredienti,String allergeni,String urlfoto,float quantita,String descrizione, float prezzo,String unita);
	public ArrayList<Prodotto> getProdottiDispensaFilteredBarcode(String filtro);
}
