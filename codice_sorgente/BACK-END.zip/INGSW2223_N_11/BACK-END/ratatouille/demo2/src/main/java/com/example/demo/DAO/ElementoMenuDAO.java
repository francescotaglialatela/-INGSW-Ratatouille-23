package com.example.demo.DAO;

import java.util.ArrayList;
import java.util.Map;

import com.example.demo.Model.ElementoMenu;

public interface ElementoMenuDAO {
	public void rimozione_piatto_dal_menu(String nomepiatto);

	public void settaggioposizione_piatto(String nome_piatto, int posizione);

	public void rimozione_piatto_dall_ordinamento(String nome_piatto);

	void inserisci_piatto_nell_ordinamento(String nomepiatto);

	public ArrayList<ElementoMenu> getProdottiOpendata();

	public void inserisci_piatto(ElementoMenu nuovoelemento);

	public ArrayList<ElementoMenu> getElementiMenu();
	public ElementoMenu getElementoMenuByName(String filtro);
	public String ControlloPresenzaIngredienteInPreparazionePiatto(String elementomenu,String codiceingrediente);
	public void insertIngredientePiatto(String componente,String nome,String ingrediente,float quantita);
	public void eliminaIngredienteAssociato(String nome,String ingrediente);
	public ArrayList<Map<String, Object>> getIngredientiElementoMenu(String filtro);
	public ArrayList<ElementoMenu> getMenuFiltered(String filtronome);	
	public ArrayList<ElementoMenu> getElementiMenuSelezionabili(ArrayList<String> elementiSelezionati);
	public void rimozione_elemento_preparato(String nome_elemento);
}
