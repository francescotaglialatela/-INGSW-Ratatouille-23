package com.example.demo.DAO;
import com.example.demo.Model.*;
public interface OrdineDAO {
public boolean registraOrdine(Ordine ordinaziones);
public int assegnaNumeroOrdine();
public void rimozione_piatto_dagl_ordini(String nome_piatto);
}