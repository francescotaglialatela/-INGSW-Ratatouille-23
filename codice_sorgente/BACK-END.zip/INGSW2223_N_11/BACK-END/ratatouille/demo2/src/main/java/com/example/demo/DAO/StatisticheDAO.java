package com.example.demo.DAO;

import java.util.ArrayList;
import java.util.Map;

public interface StatisticheDAO {
	public ArrayList<String> StatisticheOrdiniEvasi(String dataInizio, String dataFine);
	public ArrayList<Map<String, Object>>  StatistichePiattiFrequenti(String dataInizio, String dataFine);
}
