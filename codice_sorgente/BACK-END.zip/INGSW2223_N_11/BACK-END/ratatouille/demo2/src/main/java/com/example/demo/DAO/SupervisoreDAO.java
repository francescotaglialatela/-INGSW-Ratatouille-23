package com.example.demo.DAO;

public interface SupervisoreDAO {

}
