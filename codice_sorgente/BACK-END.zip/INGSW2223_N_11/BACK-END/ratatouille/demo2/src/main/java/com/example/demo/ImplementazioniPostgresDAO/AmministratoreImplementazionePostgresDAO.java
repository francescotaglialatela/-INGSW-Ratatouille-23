package com.example.demo.ImplementazioniPostgresDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.example.demo.DAO.AmministratoreDAO;
import com.example.demo.DAO.ComponentiDAO;
import com.example.demo.ConnessioneDatabase.*;

public class AmministratoreImplementazionePostgresDAO implements AmministratoreDAO {
	/** The connection. */
	private Connection connection;

	/**
	 * Instantiates a new admin implementazione postgres DAO.
	 */
	public AmministratoreImplementazionePostgresDAO() {
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean creazioneutenza(String nome, String cognome, String password, String email, String ruolo) {
		PreparedStatement insertutenza;
		ComponentiDAO componenti = new ComponentiImplementazionePostgresDAO();
		boolean presente = componenti.verifica_esistenza_componente(email);
		if (presente == true) {
			return false;
		}
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
			insertutenza = connection.prepareStatement(
					"INSERT INTO componenti VALUES ('" + email + "','" + ruolo + "','" + nome + "','" + cognome + "','"
							+ password + "',0)");
			insertutenza.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return true;
	}
}
