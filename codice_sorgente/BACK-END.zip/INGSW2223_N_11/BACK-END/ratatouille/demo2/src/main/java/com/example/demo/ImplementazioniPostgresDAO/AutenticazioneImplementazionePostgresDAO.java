package com.example.demo.ImplementazioniPostgresDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.example.demo.DAO.AutenticazioneDAO;
import com.example.demo.ConnessioneDatabase.ConnessioneDatabase;

public class AutenticazioneImplementazionePostgresDAO implements AutenticazioneDAO {

private Connection connection;
	
	public AutenticazioneImplementazionePostgresDAO() {
		try {
            connection = ConnessioneDatabase.getInstance().getConnection();
        } catch (SQLException e) {

            e.printStackTrace();
        }
	
	}
	
	
	@Override
	public boolean login(String email, String password) {
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
            PreparedStatement loginAdminPS = connection.prepareStatement(
                    "SELECT * FROM COMPONENTI WHERE EMAIL='" + email + "' AND PASSWORD='" + password + "'"
            );
            
            ResultSet rs = loginAdminPS.executeQuery();
            if (!rs.next())
                return false;
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return true;
	}


	@Override
	public int verifica_primo_accesso(String email) {
		int primo_accesso=0;
		PreparedStatement get_accesso;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
			get_accesso = connection.prepareStatement(
                    "SELECT flag_accesso FROM COMPONENTI WHERE EMAIL='" + email + "'"
            );
            
            ResultSet rs = get_accesso.executeQuery();
            if (rs.next()) {
                primo_accesso=rs.getInt("flag_accesso");
                System.out.println(""+primo_accesso);
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
		return primo_accesso;
	}


	@Override
	public void update_password(String email, String password) {
		PreparedStatement update_password;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
			update_password = connection.prepareStatement(
                    "UPDATE componenti SET flag_accesso=1,password='"+password+"' WHERE email='"+email+"'"
            );
            
            update_password.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
	}


	@Override
	public boolean verifica_esistenza_email(String email) {
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
            PreparedStatement verifica = connection.prepareStatement(
                    "SELECT * FROM COMPONENTI WHERE EMAIL='" + email + "'"
            );
            
            ResultSet rs = verifica.executeQuery();
            if (!rs.next()) {
            	rs.close();
            	return false;
            }
                
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return true;
	
	}


		
	

}