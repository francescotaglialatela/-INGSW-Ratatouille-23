package com.example.demo.ImplementazioniPostgresDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import com.example.demo.ConnessioneDatabase.ConnessioneDatabase;
import com.example.demo.DAO.AvvisoDAO;
import com.example.demo.DAO.ComponentiDAO;
import com.example.demo.Model.Avviso;

public class AvvisoImplementazionePostgresDAO implements AvvisoDAO {

	private Connection connection;

	public AvvisoImplementazionePostgresDAO() {
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	@Override
	public boolean sendMessage(Avviso avviso) {
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
			ArrayList<String> emailFound = new ArrayList<>();
			emailFound = searchEmail(avviso.getMittente());
			System.out.println(emailFound.size());
			int idMessage = 0;
			idMessage = searchLastId();
			for (int i = 0; i < emailFound.size(); i++) {
				PreparedStatement sendPS = connection.prepareStatement("INSERT INTO AVVISO "
						+ "VALUES(" + idMessage + ",'" + emailFound.get(i) + "',false,false,'"
						+ avviso.getOggettoMessaggio() + "','" + avviso.getMittente() + "','"
						+ avviso.getTestoMessaggio() + "',now());");
				sendPS.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	@Override
	public int searchLastId() {
		int lastId = 0;
		try {
			PreparedStatement lastIdPS = connection.prepareStatement("select max(id_avviso) from avviso;");
			ResultSet rs = lastIdPS.executeQuery();
			if (rs.next()) {
				lastId = rs.getInt("max") + 1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lastId;
	}

	@Override
	public ArrayList<String> searchEmail(String myEmail) {
		ArrayList<String> userEmail = new ArrayList<>();
		try {
			PreparedStatement searchPS = connection.prepareStatement("SELECT EMAIL FROM "
					+ "COMPONENTI WHERE EMAIL != '" + myEmail + "';");
			ResultSet rs = searchPS.executeQuery();
			while (rs.next()) {
				userEmail.add(rs.getString("email"));
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return userEmail;
	}

	@Override
	public ArrayList<String> searchMyMessage(String myEmail, boolean nascosto) {

		ArrayList<String> messageReceived = new ArrayList<>();
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
			PreparedStatement searchPS = connection.prepareStatement(
					"SELECT ID_AVVISO,MITTENTE,NASCOSTO,VISUALIZZATO,OGGETTO,TESTO FROM AVVISO WHERE DESTINATARIO = '"
							+ myEmail + "' and nascosto =" + nascosto + ";");
			ResultSet rs = searchPS.executeQuery();
			while (rs.next()) {
				messageReceived.add(rs.getString("testo"));
				messageReceived.add(Integer.toString((rs.getInt("id_avviso"))));
				ComponentiDAO componente = new ComponentiImplementazionePostgresDAO();
				messageReceived.add(componente.getRuolo_utente_autenticato(rs.getString("mittente")).toUpperCase());
				messageReceived.add(rs.getString("mittente"));
			}
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();

			return null;
		}

		return messageReceived;
	}

	@Override
	public ArrayList<String> openMessage(int idAvviso, String myEmail) {

		ArrayList<String> openedMessage = new ArrayList<>();
		java.sql.Timestamp timestamp;

		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
			PreparedStatement openMessagePS = connection.prepareStatement(
					"SELECT DISTINCT VISUALIZZATO,NASCOSTO,MITTENTE,OGGETTO,TESTO,DATA_ORD FROM AVVISO WHERE ID_AVVISO="
							+ idAvviso + " and destinatario='" + myEmail + "'");
			ResultSet rs = openMessagePS.executeQuery();
			if (rs.next()) {
				openedMessage.add(rs.getString("oggetto"));
				openedMessage.add(rs.getString("testo"));
				ComponentiDAO componente = new ComponentiImplementazionePostgresDAO();
				openedMessage.add(componente.getRuolo_utente_autenticato(rs.getString("mittente")).toUpperCase());
				openedMessage.add(Boolean.toString(rs.getBoolean("visualizzato")));
				openedMessage.add(Boolean.toString(rs.getBoolean("nascosto")));
				timestamp = rs.getTimestamp("data_ord");

				if (timestamp != null) {
					SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
					String timestampString = format.format(timestamp);
					openedMessage.add(timestampString);
				} else
					openedMessage.add(null);

			}

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}

		return openedMessage;
	}

	@Override
	public boolean setAvvisoVisualizzato(String myEmail, int idAvviso) {
		if (myEmail == "" || idAvviso <= 0) {
			return false;
		}
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
			PreparedStatement controlloemail = connection.prepareStatement(
					"SELECT destinatario FROM  avviso WHERE destinatario='" + myEmail + "'");
			ResultSet rs = controlloemail.executeQuery();
			if (!rs.next()) {
				return false;
			}

			PreparedStatement controlloid = connection.prepareStatement(
					"SELECT id_avviso FROM  avviso WHERE id_avviso=" + idAvviso + "");
			ResultSet rs2 = controlloid.executeQuery();
			if (!rs2.next()) {
				return false;
			}
			PreparedStatement statPS = connection.prepareStatement(
					"UPDATE AVVISO SET VISUALIZZATO= true WHERE DESTINATARIO='" + myEmail + "' AND ID_AVVISO="
							+ idAvviso);
			statPS.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	@Override
	public boolean setAvvisoNascosto(String myEmail, int idAvviso) {

		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
			PreparedStatement nascondiPS = connection.prepareStatement(
					"UPDATE AVVISO SET NASCOSTO = (NASCOSTO!= true) WHERE DESTINATARIO='" + myEmail + "' AND ID_AVVISO="
							+ idAvviso);
			nascondiPS.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}

	@Override
	public int countNewMessage(String myEmail) {

		int result = 0;

		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
			PreparedStatement conPS = connection.prepareStatement(
					"SELECT COUNT(ID_AVVISO) FROM AVVISO WHERE DESTINATARIO='" + myEmail + "'");
			ResultSet rs = conPS.executeQuery();

			if (rs.next()) {
				result = rs.getInt("count");
			}

		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}

		return result;
	}

}