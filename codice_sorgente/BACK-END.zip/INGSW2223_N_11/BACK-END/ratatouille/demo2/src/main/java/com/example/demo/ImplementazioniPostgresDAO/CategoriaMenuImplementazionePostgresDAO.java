package com.example.demo.ImplementazioniPostgresDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.example.demo.ConnessioneDatabase.ConnessioneDatabase;
import com.example.demo.DAO.CategoriaMenuDAO;
import com.example.demo.DAO.ElementoMenuDAO;
import com.example.demo.Model.CategoriaMenu;
import com.example.demo.Model.ElementoMenu;
import com.example.demo.controller.ControllerElementoMenu;

public class CategoriaMenuImplementazionePostgresDAO implements CategoriaMenuDAO {
	private Connection connection;

	/**
	 * Instantiates a new admin implementazione postgres DAO.
	 */
	public CategoriaMenuImplementazionePostgresDAO() {
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ArrayList<String> getCategorieDAO() {
		PreparedStatement categoriepresenti;
		ArrayList<String> categorie = new ArrayList<String>();
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			categoriepresenti = connection.prepareStatement(
					"SELECT DISTINCT nome,posizionelmenu FROM categoria where categoriaprincipale IS NULL OR (categoriaprincipale='None' and nome<>'Noname') ORDER BY posizionelmenu;");
			ResultSet rs = categoriepresenti.executeQuery();
			while (rs.next()) {

				String nome_categoria = rs.getString("nome");
				categorie.add(nome_categoria);

			}
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return categorie;
	}

	public int numerosottocategorie(String nomeCategoria) {
		int numerosottocategorie = 0;
		PreparedStatement sottocategoriepresenti;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			sottocategoriepresenti = connection.prepareStatement(
					"select DISTINCT nome from categoria where categoriaprincipale='" + nomeCategoria + "'and nome<>'"
							+ nomeCategoria + "';");
			ResultSet rs = sottocategoriepresenti.executeQuery();
			while (rs.next()) {
				numerosottocategorie++;

			}
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("num" + numerosottocategorie);
		return numerosottocategorie;
	}

	public void settaggioposizionicategorie(String nomeCategoria, String posizione) {
		PreparedStatement updatecategorie;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			updatecategorie = connection.prepareStatement(
					"UPDATE categoria set posizionelmenu='" + posizione + "' where nome='" + nomeCategoria
							+ "' and (categoriaprincipale<>'" + nomeCategoria + "' OR categoriaprincipale is null)");
			updatecategorie.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public ArrayList<String> sottocategorieofCategoria(String nomeCategoria) {
		PreparedStatement sottocategorie;
		ArrayList<String> nome_sottocategorie = new ArrayList<String>();
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			sottocategorie = connection.prepareStatement(
					"select DISTINCT nome from categoria where categoriaprincipale='" + nomeCategoria + "' and nome<>'"
							+ nomeCategoria + "'");
			ResultSet rs = sottocategorie.executeQuery();
			while (rs.next()) {
				nome_sottocategorie.add(rs.getString("nome"));
			}
			// connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return nome_sottocategorie;
	}

	public ArrayList<String> elementidellacategoria(String nomeCategoria) {
		PreparedStatement elementi;
		ArrayList<String> nome_elementi = new ArrayList<String>();
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			elementi = connection.prepareStatement(
					"select elementomenu from categoria where nome='" + nomeCategoria + "';");
			ResultSet rs = elementi.executeQuery();
			while (rs.next()) {
				nome_elementi.add(rs.getString("elementomenu"));
			}
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return nome_elementi;
	}

	@Override
	public void rimuovielementodellacategoria(String nomelementomenu) {
		// TODO Auto-generated method stub
		PreparedStatement eliminazione;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// // TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			eliminazione = connection.prepareStatement(
					"delete from categoria where elementomenu='" + nomelementomenu + "';");
			eliminazione.executeUpdate();
			connection.close();
			System.out.println("" + nomelementomenu + "-");
			ControllerElementoMenu elementomenu = new ControllerElementoMenu();
			elementomenu.rimozione_piatto(nomelementomenu);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public ArrayList<String> getelementimacrocategoria(String nomeCategoria) {
		// TODO Auto-generated method stub
		ArrayList<String> elementi_categoria = new ArrayList<String>();
		PreparedStatement getelementi;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			getelementi = connection.prepareStatement(
					"select elementomenu,posizionelmenu from categoria where nome='" + nomeCategoria
							+ "' and elementomenu not in (select elementomenu from categoria where categoriaprincipale='"
							+ nomeCategoria + "' and nome<>'" + nomeCategoria + "')ORDER BY posizionelmenu");
			ResultSet rs = getelementi.executeQuery();
			while (rs.next()) {
				elementi_categoria.add(rs.getString("elementomenu"));
			}
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return elementi_categoria;
	}

	@Override
	public int ultima_posizione_elemento_nellacategoria(String nomeCategoria) {
		// TODO Auto-generated method stub
		PreparedStatement getelementi;
		int posizione = 0;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			getelementi = connection.prepareStatement(
					"select MAX (posizionelmenu) from categoria where nome='" + nomeCategoria + "'");
			ResultSet rs = getelementi.executeQuery();
			if (rs.next()) {
				posizione = rs.getInt(1);
			}
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return posizione;
	}

	public int posizioneultimacategoria_nellecategorie() {
		int posizione = 0;
		PreparedStatement get_posizione;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			get_posizione = connection.prepareStatement(
					"SELECT MAX(posizionelmenu) FROM categoria where categoriaprincipale IS NULL");
			ResultSet rs = get_posizione.executeQuery();
			if (rs.next()) {
				posizione = rs.getInt(1);

			}
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return posizione;
	}

	@Override
	public void eliminazionesottoCategoria(String nomesottoCategoria) {

		ArrayList<String> elementisottocategoria = new ArrayList<String>();

		PreparedStatement eliminazionelmentidallasottoCategoria;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			elementisottocategoria = elementidellacategoria(nomesottoCategoria);
			connection = ConnessioneDatabase.getInstance().getConnection();
			for (String elementomenu : elementisottocategoria) {

				eliminazionelmentidallasottoCategoria = connection.prepareStatement(
						"delete from categoria where elementomenu='" + elementomenu + "' and nome='"
								+ nomesottoCategoria + "'");
				System.out.println(elementomenu);
				eliminazionelmentidallasottoCategoria.executeUpdate();
			}
			connection.close();
		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public ArrayList<String> getelementi_senza_categoria() {
		// TODO Auto-generated method stub
		PreparedStatement elementi_senza_categoria;
		ArrayList<String> elementi = new ArrayList<String>();
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			elementi_senza_categoria = connection.prepareStatement(
					"select elementomenu,posizionelmenu from categoria where nome='Noname' and categoriaprincipale='None' ORDER BY posizionelmenu;");
			ResultSet rs = elementi_senza_categoria.executeQuery();
			while (rs.next()) {
				elementi.add(rs.getString("elementomenu"));
			}
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return elementi;
	}

	@Override
	public void eliminazionemacroCategoria_e_sottocategorie(String nomeCategoria) {
		// TODO Auto-generated method stub

		PreparedStatement eliminazione_categoria_con_sottocategorie;
		ArrayList<String> elementi = new ArrayList<String>();
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		elementi = elementidellacategoria(nomeCategoria);
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();

			for (String elementomenu : elementi) {
				eliminazione_categoria_con_sottocategorie = connection.prepareStatement(
						"delete from categoria where elementomenu='" + elementomenu + "'");
				eliminazione_categoria_con_sottocategorie.executeUpdate();
				ElementoMenuDAO elementomenuDAO = new ElementoMenuImplementazionePostgresDAO();
				elementomenuDAO.rimozione_piatto_dall_ordinamento(elementomenu);
				connection = ConnessioneDatabase.getInstance().getConnection();
			}
			PreparedStatement verifica_esistenza_CategoriaNone = connection.prepareStatement(
					"SELECT DISTINCT nome,posizionelmenu  FROM categoria WHERE nome = 'None' and categoriaprincipale='None'");
			ResultSet rs = verifica_esistenza_CategoriaNone.executeQuery();
			int posizione = 0;
			PreparedStatement insert;
			if (rs.next()) {
				posizione = rs.getInt("posizionelmenu");
			} else {
				int posizione_ultima_categoria = posizioneultimacategoria_nellecategorie();
				posizione = posizione_ultima_categoria + 1;
				connection = ConnessioneDatabase.getInstance().getConnection();
			}
			for (String elementomenu : elementi) {
				insert = connection.prepareStatement(
						"insert into categoria VALUES('None','None','" + elementomenu + "'," + posizione + ")");
				insert.executeUpdate();
				int max_posizione = ultima_posizione_elemento_nellacategoria("Noname");
				int posizione_elemento_attuale = max_posizione + 1;
				System.out.println("pos att:" + posizione_elemento_attuale);
				connection = ConnessioneDatabase.getInstance().getConnection();
				insert = connection.prepareStatement(
						"insert into categoria VALUES('None','Noname','" + elementomenu + "',"
								+ posizione_elemento_attuale + ")");
				insert.executeUpdate();

			}
			connection.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void rimuovielementodallacategoria_e_non_dal_menu(String nomelementomenu) {
		// TODO Auto-generated method stub
		PreparedStatement eliminazione;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// // TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			eliminazione = connection.prepareStatement(
					"delete from categoria where elementomenu='" + nomelementomenu + "';");
			eliminazione.executeUpdate();
			connection.close();
			System.out.println("" + nomelementomenu + "-");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void inserisciCategoria(CategoriaMenu categoria) {
		// TODO Auto-generated method stub
		System.out.println("sto quaaa");
		PreparedStatement inserimento_categoria;
		PreparedStatement posizione_categoria_None;
		ArrayList<ElementoMenu> elementimenu = categoria.getelementimenu_della_categoria();
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		for (ElementoMenu elemento : elementimenu) {
			rimuovielementodallacategoria_e_non_dal_menu(elemento.getNome());
		}
		if (categoria.getNome_Categoria_principale().equals("")) {
			int posizione_ultima_categoria = posizioneultimacategoria_nellecategorie();
			try {
				connection = ConnessioneDatabase.getInstance().getConnection();
				posizione_categoria_None = connection.prepareStatement(
						"select posizionelmenu from categoria where nome='None'");
				ResultSet rs = posizione_categoria_None.executeQuery();
				int posizione_nuova_categoria = 0;
				if (rs.next()) {
					int posizione_ottenuta = rs.getInt(1);
					if ((posizione_ottenuta - posizione_ultima_categoria) == 1) {
						// update a none
						PreparedStatement update_None;
						posizione_nuova_categoria = posizione_ottenuta;
						posizione_ottenuta += 1;
						update_None = connection.prepareStatement(
								"update categoria set posizionelmenu=" + posizione_ottenuta
										+ " where nome='None' and categoriaprincipale='None'");
						update_None.executeUpdate();
					} else {
						posizione_nuova_categoria = posizione_ultima_categoria + 1;
					}
				} else {
					posizione_nuova_categoria = posizione_ultima_categoria + 1;
				}

				for (ElementoMenu elemento : elementimenu) {
					// PROVARE
					ElementoMenuDAO elementomenu = new ElementoMenuImplementazionePostgresDAO();
					elementomenu.inserisci_piatto_nell_ordinamento(elemento.getNome());
					connection = ConnessioneDatabase.getInstance().getConnection();
					// PROVARE
					inserimento_categoria = connection
							.prepareStatement("insert into categoria VALUES(null,'" + categoria.getNome() + "','"
									+ elemento.getNome() + "'," + posizione_nuova_categoria + ")");
					inserimento_categoria.executeUpdate();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			int numero_sottocategorie = numerosottocategorie(categoria.getNome_Categoria_principale());
			int posizione_nuova_categoria = numero_sottocategorie + 1;
			int posizione_macro_categoria = 0;
			try {
				PreparedStatement inserimento_macro_categoria;
				connection = ConnessioneDatabase.getInstance().getConnection();
				for (ElementoMenu elemento : elementimenu) {
					inserimento_categoria = connection.prepareStatement("insert into categoria VALUES('"
							+ categoria.getNome_Categoria_principale() + "','" + categoria.getNome() + "','"
							+ elemento.getNome() + "'," + posizione_nuova_categoria + ")");
					inserimento_categoria.executeUpdate();
				}
				posizione_macro_categoria = posizione_categoria(categoria.getNome_Categoria_principale());
				connection = ConnessioneDatabase.getInstance().getConnection();
				for (ElementoMenu elemento : elementimenu) {
					// PROVARE
					ElementoMenuDAO elementomenu = new ElementoMenuImplementazionePostgresDAO();
					elementomenu.inserisci_piatto_nell_ordinamento(elemento.getNome());
					connection = ConnessioneDatabase.getInstance().getConnection();
					// PROVARE
					inserimento_macro_categoria = connection.prepareStatement(
							"insert into categoria VALUES(null,'" + categoria.getNome_Categoria_principale() + "','"
									+ elemento.getNome() + "'," + posizione_macro_categoria + ")");
					inserimento_macro_categoria.executeUpdate();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	@Override
	public ArrayList<String> getCategorieESottocatgorie() {
		ArrayList<String> lista_categorie_e_sottocategorie = new ArrayList<String>();
		PreparedStatement selezione_categorie_e_sottocategorie;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			selezione_categorie_e_sottocategorie = connection
					.prepareStatement("select DISTINCT nome from categoria where nome<>'Noname'");
			ResultSet rs = selezione_categorie_e_sottocategorie.executeQuery();
			while (rs.next()) {
				String nome_categoria = rs.getString("nome");
				lista_categorie_e_sottocategorie.add(nome_categoria);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lista_categorie_e_sottocategorie;
	}

	@Override
	public void settaggio_elementi_senza_categoria(String nome_piatto, int posizione) {
		PreparedStatement updatelemento;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			updatelemento = connection.prepareStatement(
					"UPDATE categoria set posizionelmenu=" + posizione + " where elementomenu='" + nome_piatto
							+ "' and nome='Noname'");
			updatelemento.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public boolean verifica_macrocategoria(String nomecategoria) {
		// TODO Auto-generated method stub
		ArrayList<String> categorie = getCategorieDAO();
		for (String macrocategoria : categorie) {
			if (macrocategoria.equals(nomecategoria)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public int posizione_categoria(String nome_categoria) {
		// TODO Auto-generated method stub
		PreparedStatement getposizione;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			getposizione = connection.prepareStatement(
					"SELECT DISTINCT posizionelmenu from categoria where nome='" + nome_categoria + "'");
			ResultSet rs = getposizione.executeQuery();
			connection.close();
			if (rs.next()) {

				return rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public void inserimento_piatto_nella_macro_categoria(String nomecategoria, String nomepiatto) {
		// TODO Auto-generated method stub
		PreparedStatement insert;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			int posizione = posizione_categoria(nomecategoria);
			connection = ConnessioneDatabase.getInstance().getConnection();
			insert = connection.prepareStatement(
					"insert into categoria VALUES(null,'" + nomecategoria + "','" + nomepiatto + "'," + posizione
							+ ")");
			insert.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public String getCategoria_della_sottocategoria(String nome_sottocategoria) {
		String nomeCategoria = null;
		PreparedStatement getMacroCategoria;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			getMacroCategoria = connection.prepareStatement(
					"select DISTINCT categoriaprincipale from categoria where nome='" + nome_sottocategoria + "'");
			ResultSet rs = getMacroCategoria.executeQuery();
			if (rs.next()) {
				nomeCategoria = rs.getString("categoriaprincipale");
				return nomeCategoria;
			}
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return nomeCategoria;
	}

	@Override
	public void inserimento_piatto_senza_categoria(String nomepiatto) {
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
			PreparedStatement verifica_esistenza_CategoriaNone = connection.prepareStatement(
					"SELECT DISTINCT nome,posizionelmenu  FROM categoria WHERE nome = 'None' and categoriaprincipale='None'");
			ResultSet rs = verifica_esistenza_CategoriaNone.executeQuery();
			int posizione = 0;
			if (rs.next()) {
				PreparedStatement insert;
				posizione = rs.getInt("posizionelmenu");
			} else {
				int posizione_ultima_categoria = posizioneultimacategoria_nellecategorie();
				connection = ConnessioneDatabase.getInstance().getConnection();
				posizione = posizione_ultima_categoria + 1;
			}
			PreparedStatement insert = connection.prepareStatement(
					"insert into categoria VALUES('None','None','" + nomepiatto + "'," + posizione + ")");
			insert.executeUpdate();
			int max_posizione = ultima_posizione_elemento_nellacategoria("Noname");
			int posizione_elemento_attuale = max_posizione + 1;
			System.out.println("pos att:" + posizione_elemento_attuale);
			connection = ConnessioneDatabase.getInstance().getConnection();
			insert = connection.prepareStatement(
					"insert into categoria VALUES('None','Noname','" + nomepiatto + "'," + posizione_elemento_attuale
							+ ")");
			insert.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void inserimento_piatto_nella_sottocategoria(String nome_categoria, String nomepiatto) {
		String macroCategoria = getCategoria_della_sottocategoria(nome_categoria);
		inserimento_piatto_nella_macro_categoria(macroCategoria, nomepiatto);
		PreparedStatement insert_sottocategoria;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			int posizione = posizione_categoria(nome_categoria);
			connection = ConnessioneDatabase.getInstance().getConnection();
			insert_sottocategoria = connection.prepareStatement(
					"insert into categoria VALUES('" + macroCategoria + "','" + nome_categoria + "','" + nomepiatto
							+ "'," + posizione + ")");
			insert_sottocategoria.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
