package com.example.demo.ImplementazioniPostgresDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.example.demo.ConnessioneDatabase.ConnessioneDatabase;
import com.example.demo.DAO.ComponentiDAO;
import com.example.demo.Model.Componenti;

public class ComponentiImplementazionePostgresDAO implements ComponentiDAO {
	private Connection connection;

	public ComponentiImplementazionePostgresDAO() {
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public boolean verifica_esistenza_componente(String email) {
		PreparedStatement verifica_presenza;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			verifica_presenza = connection.prepareStatement(
					"SELECT * FROM componenti where email='" + email + "'");
			ResultSet rs = verifica_presenza.executeQuery();
			if (rs.next()) {
				return true;
			}
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	public boolean insert_utenza(Componenti componente) {
		PreparedStatement insertutenza;

		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			insertutenza = connection.prepareStatement(
					"INSERT INTO componenti VALUES ('" + componente.getEmail() + "','" + componente.getRuolo() + "','"
							+ componente.getNome() + "','" + componente.getCognome() + "','" + componente.getPassword()
							+ "','" + componente.getSesso() + "',0)");
			insertutenza.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return true;
	}

	@Override
	public String getRuolo_utente_autenticato(String email) {
		String role = new String();
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
			PreparedStatement searchRolePS = connection
					.prepareStatement("SELECT RUOLO FROM COMPONENTI WHERE EMAIL= '" + email + "';");
			ResultSet rs = searchRolePS.executeQuery();
			if (rs.next()) {
				role = rs.getString("ruolo");
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return role;
	}

	@Override
	public String getNomeUtente(String email) {
		String nome = new String();
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
			PreparedStatement searchRolePS = connection
					.prepareStatement("SELECT nome FROM COMPONENTI WHERE EMAIL= '" + email + "';");
			ResultSet rs = searchRolePS.executeQuery();
			if (rs.next()) {
				nome = rs.getString("nome");
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return nome;
	}

}
