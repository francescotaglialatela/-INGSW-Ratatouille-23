package com.example.demo.ImplementazioniPostgresDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.example.demo.ConnessioneDatabase.ConnessioneDatabase;
import com.example.demo.DAO.DispensaDAO;
import com.example.demo.Model.Prodotto;
import com.example.demo.Model.ProdottoOpenFood;

public class DispensaImplementazionePostgresDAO implements DispensaDAO {
	private Connection connection;

	/**
	 * Instantiates a new admin implementazione postgres DAO.
	 */
	public DispensaImplementazionePostgresDAO() {
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ArrayList<Prodotto> getProdottiDispensa() {
		PreparedStatement ProdottiDispensa;
		ArrayList<Prodotto> prodotti = new ArrayList<Prodotto>();
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			ProdottiDispensa = connection.prepareStatement(
					"SELECT * FROM prodotti;");
			ResultSet rs = ProdottiDispensa.executeQuery();
			while (rs.next()) {
				String codiceabarre = rs.getString("codiceabarre");
				String nome = rs.getString("nomeprodotto");
				String ingredienti = rs.getString("ingredienti");
				String allergeni = rs.getString("allergeni");
				String urlfoto = rs.getString("urlfoto");
				String unita = rs.getString("unita");
				String descrizione = rs.getString("descrizione");

				float quantita = rs.getFloat("quantita");
				float prezzo = rs.getFloat("prezzo");

				Prodotto prodottodainserire = new Prodotto(codiceabarre, nome, ingredienti, allergeni, urlfoto, unita,
						descrizione, quantita, prezzo);
				prodotti.add(prodottodainserire);
				// System.out.println(prodottodainserire.nome);

			}
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return prodotti;
	}

	public void aumentaQta(String id, float qta) {
		PreparedStatement modificaProdotto;
		PreparedStatement eliminazione_prodotto_quantitainsufficiente;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			modificaProdotto = connection.prepareStatement(
					"UPDATE PRODOTTI SET quantita = quantita +" + qta + " WHERE codiceabarre='" + id + "';");
			eliminazione_prodotto_quantitainsufficiente = connection
					.prepareStatement("DELETE FROM prodotti WHERE quantita <= 0");
			modificaProdotto.executeUpdate();
			eliminazione_prodotto_quantitainsufficiente.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void eliminaProdotto(String id) {
		PreparedStatement modificaProdotto;
		PreparedStatement elimina_dalla_preparazione;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			elimina_dalla_preparazione = connection.prepareStatement(
					"DELETE FROM preparazione_piatto WHERE ingrediente='" + id + "';");
			elimina_dalla_preparazione.executeUpdate();
			modificaProdotto = connection.prepareStatement(
					"DELETE FROM PRODOTTI WHERE codiceabarre='" + id + "';");
			modificaProdotto.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public ArrayList<Prodotto> getProdottiDispensaFiltered(String filtro) {
		PreparedStatement ProdottiDispensa;
		ArrayList<Prodotto> prodotti = new ArrayList<Prodotto>();
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			ProdottiDispensa = connection.prepareStatement(
					"SELECT * FROM prodotti WHERE nomeprodotto ILIKE '%" + filtro + "%'");
			ResultSet rs = ProdottiDispensa.executeQuery();
			while (rs.next()) {
				String codiceabarre = rs.getString("codiceabarre");
				String nome = rs.getString("nomeprodotto");
				String ingredienti = rs.getString("ingredienti");
				String allergeni = rs.getString("allergeni");
				String urlfoto = rs.getString("urlfoto");
				String unita = rs.getString("unita");
				String descrizione = rs.getString("descrizione");
				float quantita = rs.getFloat("quantita");
				float prezzo = rs.getFloat("prezzo");

				Prodotto prodottodainserire = new Prodotto(codiceabarre, nome, ingredienti, allergeni, urlfoto, unita,
						descrizione, quantita, prezzo);
				prodotti.add(prodottodainserire);
				// System.out.println(prodottodainserire.nome);

			}
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return prodotti;
	}

	public ArrayList<ProdottoOpenFood> getProdottiOpenFoodFiltered(String filtro) {
		PreparedStatement ProdottiDispensa;
		ArrayList<ProdottoOpenFood> prodotti = new ArrayList<ProdottoOpenFood>();
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			ProdottiDispensa = connection.prepareStatement(
					"SELECT * FROM openfood WHERE nomeprodotto ILIKE '%" + filtro + "%' LIMIT 10");
			ResultSet rs = ProdottiDispensa.executeQuery();
			while (rs.next()) {
				String codiceabarre = rs.getString("codiceabarre");
				String nome = rs.getString("nomeprodotto");
				String ingredienti = rs.getString("ingredienti");
				String allergeni = rs.getString("allergeni");
				String urlfoto = rs.getString("image");
				ProdottoOpenFood prodottodainserire = new ProdottoOpenFood(codiceabarre, nome, ingredienti, allergeni,
						urlfoto);
				prodotti.add(prodottodainserire);
				// System.out.println(prodottodainserire.nome);
				System.out.println(ProdottiDispensa);
			}
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return prodotti;
	}

	public ProdottoOpenFood getProdottiOpenFoodBarcode(String filtro) {
		PreparedStatement ProdottiDispensa;
		ProdottoOpenFood prodottodainserire = null;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			ProdottiDispensa = connection.prepareStatement(
					"SELECT * FROM openfood WHERE codiceabarre ILIKE '" + filtro + "' LIMIT 1");
			ResultSet rs = ProdottiDispensa.executeQuery();
			while (rs.next()) {
				String codiceabarre = rs.getString("codiceabarre");
				String nome = rs.getString("nomeprodotto");
				String ingredienti = rs.getString("ingredienti");
				String allergeni = rs.getString("allergeni");
				String urlfoto = rs.getString("image");
				prodottodainserire = new ProdottoOpenFood(codiceabarre, nome, ingredienti, allergeni, urlfoto);
				// System.out.println(prodottodainserire.nome);
				System.out.println(ProdottiDispensa);

			}
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
		return prodottodainserire;
	}

	public boolean insertDispensa(String codiceabarre, String nome, String ingredienti, String allergeni,
			String urlfoto, float quantita, String descrizione, float prezzo, String unita) {
		PreparedStatement inserisciProdotto;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			inserisciProdotto = connection.prepareStatement(
					"INSERT INTO PRODOTTI (codiceabarre, nomeprodotto, ingredienti, allergeni, urlfoto, unita, descrizione, quantita, prezzo) VALUES ('"
							+ codiceabarre + "','" + nome + "','" + ingredienti + "','" + allergeni + "','" + urlfoto
							+ "','" + unita + "','" + descrizione + "','" + quantita + "','" + prezzo + "');");
			inserisciProdotto.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public ArrayList<Prodotto> getProdottiDispensaFilteredBarcode(String filtro) {
		PreparedStatement ProdottiDispensa;
		ArrayList<Prodotto> prodotti = new ArrayList<Prodotto>();
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			ProdottiDispensa = connection.prepareStatement(
					"SELECT * FROM prodotti WHERE codiceabarre ILIKE '" + filtro + "' LIMIT 1");
			ResultSet rs = ProdottiDispensa.executeQuery();
			while (rs.next()) {
				String codiceabarre = rs.getString("codiceabarre");
				String nome = rs.getString("nomeprodotto");
				String ingredienti = rs.getString("ingredienti");
				String allergeni = rs.getString("allergeni");
				String urlfoto = rs.getString("urlfoto");
				String unita = rs.getString("unita");
				String descrizione = rs.getString("descrizione");
				float quantita = rs.getFloat("quantita");
				float prezzo = rs.getFloat("prezzo");

				Prodotto prodottodainserire = new Prodotto(codiceabarre, nome, ingredienti, allergeni, urlfoto, unita,
						descrizione, quantita, prezzo);
				prodotti.add(prodottodainserire);
				// System.out.println(prodottodainserire.nome);
				System.out.println(ProdottiDispensa);
			}
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return prodotti;
	}

	public ArrayList<ProdottoOpenFood> getProdottiOpenFood() {
		PreparedStatement ProdottiOpenFood;
		ArrayList<ProdottoOpenFood> prodotti = new ArrayList<ProdottoOpenFood>();
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			ProdottiOpenFood = connection.prepareStatement(
					"SELECT * FROM openfood LIMIT 100;");
			ResultSet rs = ProdottiOpenFood.executeQuery();
			while (rs.next()) {
				String codiceabarre = rs.getString("codiceabarre");
				String nome = rs.getString("nomeprodotto");
				String ingredienti = rs.getString("ingredienti");
				String allergeni = rs.getString("allergeni");
				String urlfoto = rs.getString("image");
				ProdottoOpenFood prodottodainserire = new ProdottoOpenFood(codiceabarre, nome, ingredienti, allergeni,
						urlfoto);
				prodotti.add(prodottodainserire);
				// System.out.println(prodottodainserire.nome);

			}
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return prodotti;
	}

}