package com.example.demo.ImplementazioniPostgresDAO;

import java.sql.SQLException;

import com.example.demo.ConnessioneDatabase.ConnessioneDatabase;
import com.example.demo.DAO.ElementoMenuDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.example.demo.Model.ElementoMenu;

public class ElementoMenuImplementazionePostgresDAO implements ElementoMenuDAO {
	private Connection connection;

	public ElementoMenuImplementazionePostgresDAO() {
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void rimozione_piatto_dal_menu(String nomepiatto) {
		// TODO Auto-generated method stub
		PreparedStatement rimozione_piatto;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			rimozione_piatto = connection.prepareStatement(
					"DELETE FROM elementomenu where nomelemento='" + nomepiatto + "'");
			rimozione_piatto.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void inserisci_piatto_nell_ordinamento(String nomepiatto) {
		// TODO Auto-generated method stub
		PreparedStatement inserimento_piatto;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			inserimento_piatto = connection.prepareStatement(
					"INSERT INTO ordinamento (nomelmentomenu, posizione) VALUES ('" + nomepiatto
							+ "',(SELECT MAX(posizione)+1 FROM ordinamento))");
			inserimento_piatto.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void settaggioposizione_piatto(String nome_piatto, int posizione) {
		PreparedStatement updatepiatto;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			updatepiatto = connection.prepareStatement(
					"UPDATE ordinamento set posizione=" + posizione + " where nomelmentomenu='" + nome_piatto + "'");
			updatepiatto.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void rimozione_piatto_dall_ordinamento(String nome_piatto) {
		PreparedStatement rimozione_piatto;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			rimozione_piatto = connection.prepareStatement(
					"DELETE FROM ordinamento where nomelmentomenu='" + nome_piatto + "'");
			rimozione_piatto.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public ArrayList<ElementoMenu> getProdottiOpendata() {

		ArrayList<ElementoMenu> elementi = new ArrayList<ElementoMenu>();
		PreparedStatement select_elementi;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			select_elementi = connection.prepareStatement(
					"SELECT DISTINCT nomeprodotto,ingredienti,allergeni from openfood");
			ResultSet rs = select_elementi.executeQuery();
			while (rs.next()) {
				String Nome = rs.getString("nomeprodotto");
				String Descrizione = rs.getString("ingredienti");
				String Allergeni = rs.getString("allergeni");
				ElementoMenu elemento = new ElementoMenu(Nome, Descrizione, 0, Allergeni);
				elementi.add(elemento);
			}

			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return elementi;
	}

	@Override
	public void inserisci_piatto(ElementoMenu nuovoelemento) {
		// TODO Auto-generated method stub
		PreparedStatement inserimento;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			inserimento = connection.prepareStatement(
					"insert into elementomenu VALUES('" + nuovoelemento.getNome() + "','"
							+ nuovoelemento.getDescrizione() + "'," + nuovoelemento.getCosto() + ",'"
							+ nuovoelemento.getAllergeni() + "')");
			inserimento.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ArrayList<ElementoMenu> getElementiMenu() {
		PreparedStatement getElementi;
		ArrayList<ElementoMenu> elementiMenu = new ArrayList<ElementoMenu>();
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			getElementi = connection.prepareStatement(
					"SELECT * FROM elementomenu;");
			ResultSet rs = getElementi.executeQuery();
			while (rs.next()) {
				String nome = rs.getString("nomelemento");
				String descrizione = rs.getString("descrizione");
				float costo = rs.getFloat("costo");
				String allergeni = rs.getString("allergeni");
				ElementoMenu elementoMenuDaInserire = new ElementoMenu(nome, descrizione, costo, allergeni);
				elementiMenu.add(elementoMenuDaInserire);
				// System.out.println(prodottodainserire.nome);
			}
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return elementiMenu;
	}

	@Override
	public ElementoMenu getElementoMenuByName(String filtro) {
		PreparedStatement getElemento;
		ElementoMenu elementoMenuDaInserire = null;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			getElemento = connection.prepareStatement(
					"SELECT * FROM elementomenu WHERE nomelemento ILIKE '" + filtro + "' LIMIT 1");
			ResultSet rs = getElemento.executeQuery();
			while (rs.next()) {
				String nome = rs.getString("nomelemento");
				String descrizione = rs.getString("descrizione");
				float costo = rs.getFloat("costo");
				String allergeni = rs.getString("allergeni");
				elementoMenuDaInserire = new ElementoMenu(nome, descrizione, costo, allergeni);

				// System.out.println(prodottodainserire.nome);
			}
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
		return elementoMenuDaInserire;
	}

	@Override
	public ArrayList<ElementoMenu> getMenuFiltered(String filtronome) {
		PreparedStatement MenuFiltered;
		ArrayList<ElementoMenu> elementiMenu = new ArrayList<ElementoMenu>();
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		try {
			MenuFiltered = connection.prepareStatement("SELECT * FROM "
					+ "elementomenu WHERE nomelemento ILIKE '%" + filtronome + "%'");
			ResultSet rs = MenuFiltered.executeQuery();
			while (rs.next()) {
				String nomelemento = rs.getString("nomelemento");
				String descrizione = rs.getString("descrizione");
				float costo = rs.getFloat("costo");
				String allergeni = rs.getString("allergeni");
				ElementoMenu elementodainserire = new ElementoMenu(nomelemento, descrizione, costo, allergeni);
				elementiMenu.add(elementodainserire);
				// System.out.println(prodottodainserire.nome); 
			}
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return elementiMenu;
	}

	public String ControlloPresenzaIngredienteInPreparazionePiatto(String elementomenu, String codiceingrediente) {
		PreparedStatement getElemento;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
			getElemento = connection.prepareStatement(
					"SELECT * FROM preparazione_piatto WHERE elementomenu='" + elementomenu + "' AND ingrediente = '"
							+ codiceingrediente + "';");
			ResultSet rs = getElemento.executeQuery();
			if (!rs.next()) {
				connection.close();
				return "nonPresente";
			} else {
				connection.close();
				return "Presente";
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "nonPresente";
		}
	}

	public void insertIngredientePiatto(String componente, String nome, String ingrediente, float quantita) {
		PreparedStatement inserisciingrediente;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			inserisciingrediente = connection.prepareStatement(
					"INSERT INTO preparazione_piatto VALUES ('" + componente + "','" + nome + "','" + ingrediente + "',"
							+ quantita + ");");
			inserisciingrediente.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void eliminaIngredienteAssociato(String nome, String ingrediente) {
		PreparedStatement modificaProdotto;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			modificaProdotto = connection.prepareStatement(
					"DELETE FROM preparazione_piatto WHERE elementomenu='" + nome + "' AND ingrediente='" + ingrediente
							+ "';");
			modificaProdotto.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public ArrayList<ElementoMenu> getElementiMenuSelezionabili(ArrayList<String> elementiSelezionati) {
		StringBuilder query;
		if (elementiSelezionati.size() > 0) {
			query = new StringBuilder("SELECT * FROM elementomenu WHERE ");
			for (int i = 0; i < elementiSelezionati.size(); i++) {
				query.append("nomelemento != '").append(elementiSelezionati.get(i)).append("'");
				if (i < elementiSelezionati.size() - 1) {
					query.append(" AND ");
				}
			}
		} else
			query = new StringBuilder("SELECT * FROM elementomenu");
		PreparedStatement getElementi;
		ArrayList<ElementoMenu> elementiMenu = new ArrayList<ElementoMenu>();
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			getElementi = connection.prepareStatement(query.toString());
			// "SELECT * FROM elementomenu where nomelemento!=''");
			ResultSet rs = getElementi.executeQuery();
			while (rs.next()) {
				String nome = rs.getString("nomelemento");
				String descrizione = rs.getString("descrizione");
				float costo = rs.getFloat("costo");
				String allergeni = rs.getString("allergeni");
				ElementoMenu elementoMenuDaInserire = new ElementoMenu(nome, descrizione, costo, allergeni);
				elementiMenu.add(elementoMenuDaInserire);// System.out.println(prodottodainserire.nome);
			}
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return elementiMenu;
	}

	@Override
	public ArrayList<Map<String, Object>> getIngredientiElementoMenu(String filtro) {
		PreparedStatement getElementi;
		ArrayList<Map<String, Object>> ingredienti = new ArrayList<Map<String, Object>>();

		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			getElementi = connection.prepareStatement(
					"SELECT * FROM preparazione_piatto WHERE elementomenu ='" + filtro + "';");
			ResultSet rs = getElementi.executeQuery();
			while (rs.next()) {
				String ingrediente = rs.getString("ingrediente");
				float quantitanecessaria = rs.getFloat("quantitanecessaria");
				PreparedStatement getnomeingrediente;
				getnomeingrediente = connection
						.prepareStatement("SELECT * FROM prodotti WHERE codiceabarre='" + ingrediente + "';");
				ResultSet rs2 = getnomeingrediente.executeQuery();
				while (rs2.next()) {
					String nomeingrediente = rs2.getString("nomeprodotto");
					String unita = rs2.getString("unita");
					Map<String, Object> ingredienteDaInviare = new HashMap<>();
					ingredienteDaInviare.put("nomeingrediente", nomeingrediente);
					ingredienteDaInviare.put("quantitaIngrediente", quantitanecessaria);
					ingredienteDaInviare.put("unita", unita);
					ingredienti.add(ingredienteDaInviare);
				}
				;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return ingredienti;
	}

	@Override
	public void rimozione_elemento_preparato(String nome_elemento) {
		// TODO Auto-generated method stub
		PreparedStatement rimozione;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
			rimozione = connection.prepareStatement(
					"DELETE FROM preparazione_piatto WHERE elementomenu='" + nome_elemento + "'");
			rimozione.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
