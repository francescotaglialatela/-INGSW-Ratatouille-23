package com.example.demo.ImplementazioniPostgresDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.example.demo.ConnessioneDatabase.ConnessioneDatabase;
import com.example.demo.DAO.OrdineDAO;
import com.example.demo.Model.Ordine;

public class OrdineImplementazionePostgresDAO implements OrdineDAO {
	private Connection connection;

	public OrdineImplementazionePostgresDAO() {
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean registraOrdine(Ordine ordinazione) {
		try {
			PreparedStatement registraPS = connection.prepareStatement("INSERT INTO "
					+ "ORDINE VALUES(" + ordinazione.getNumeroOrdine() + "," + ordinazione.getNumeroTavolo() + ","
					+ ordinazione.getPrezzo() + ",'" + ordinazione.getElementoMenu().toLowerCase() + "',"
					+ ordinazione.getQuantita() + ",'" + ordinazione.getRegistratore() + "',NOW());");
			registraPS.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	@Override
	public int assegnaNumeroOrdine() {
		int result = 0;
		try {
			PreparedStatement ordinePS = connection.prepareStatement("SELECT MAX(ID_ORDINE) FROM ORDINE");
			ResultSet rs = ordinePS.executeQuery();
			if (rs.next()) {
				result = rs.getInt("max") + 1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
		return result;
	}

	@Override
	public void rimozione_piatto_dagl_ordini(String nome_piatto) {
		// TODO Auto-generated method stub
		PreparedStatement rimozione;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
			rimozione = connection.prepareStatement(
					"DELETE FROM ORDINE WHERE elementomenu='" + nome_piatto + "'");
			rimozione.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
