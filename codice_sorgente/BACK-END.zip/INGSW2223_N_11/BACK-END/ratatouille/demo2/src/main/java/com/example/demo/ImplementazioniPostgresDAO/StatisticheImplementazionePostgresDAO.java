package com.example.demo.ImplementazioniPostgresDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.example.demo.ConnessioneDatabase.ConnessioneDatabase;
import com.example.demo.DAO.StatisticheDAO;

public class StatisticheImplementazionePostgresDAO implements StatisticheDAO {
	private Connection connection;

	@Override
	public ArrayList<String> StatisticheOrdiniEvasi(String dataInizio, String dataFine) {
		ArrayList<String> ordiniEvasi = new ArrayList<>();
		String utenteCompleto;
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
			PreparedStatement statistichePS = connection.prepareStatement("SELECT ADDETTO_SALA, COUNT(*),NOME,COGNOME, "
					+ "SUM(QUANTITA_ELEMENTOMENU * PREZZO) AS totale_quantita FROM ORDINE "
					+ "JOIN componenti ON ORDINE.addetto_SALA = componenti.email WHERE "
					+ "DATA_ORDINE BETWEEN'" + dataInizio + "' AND '" + dataFine + "' GROUP BY ORDINE.ADDETTO_SALA,"
					+ "COMPONENTI.NOME,COMPONENTI.COGNOME");
			ResultSet rs = statistichePS.executeQuery();
			while (rs.next()) {
				utenteCompleto = rs.getString("nome") + " " + rs.getString("cognome") + " ("
						+ rs.getString("addetto_sala") + ")";
				ordiniEvasi.add(utenteCompleto);
				ordiniEvasi.add(Integer.toString(rs.getInt("count")));
				ordiniEvasi.add(rs.getString("totale_quantita"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return ordiniEvasi;
	}

	@Override
	public ArrayList<Map<String, Object>> StatistichePiattiFrequenti(String dataInizio, String dataFine) {
		ArrayList<Map<String, Object>> statistiche = new ArrayList<Map<String, Object>>();
		try {
			connection = ConnessioneDatabase.getInstance().getConnection();
			PreparedStatement statistichePS = connection
					.prepareStatement("SELECT ELEMENTOMENU, SUM(quantita_elementomenu) "
							+ "FROM ORDINE WHERE DATA_ORDINE BETWEEN'" + dataInizio + "' AND '" + dataFine + "' "
							+ "GROUP BY ELEMENTOMENU");
			ResultSet rs = statistichePS.executeQuery();
			while (rs.next()) {
				Map<String, Object> statisticaPiatto = new HashMap<>();
				statisticaPiatto.put("nome", rs.getString("elementomenu"));
				statisticaPiatto.put("valore", rs.getInt(2));
				statistiche.add(statisticaPiatto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return statistiche;
	}
}
