package com.example.demo.ImplementazioniPostgresDAO;

import com.example.demo.DAO.SupervisoreDAO;

public class SupervisoreImplementazionePostgresDAO implements SupervisoreDAO {

}
