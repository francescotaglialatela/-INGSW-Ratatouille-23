package com.example.demo.Model;

import java.sql.Date;

public class Avviso {
	String destinatario;
	String Oggetto_del_messaggio;
	String mittente;
	String testo_del_messaggio;
	Date data;

	public Avviso(String Oggetto_del_messaggio, String testo_del_messaggio, String destinatario, String mittente) {
		this.destinatario = destinatario;
		this.mittente = mittente;
		this.Oggetto_del_messaggio = Oggetto_del_messaggio;
		this.testo_del_messaggio = testo_del_messaggio;
	}

	public String getMittente() {
		return mittente;
	}

	public String getDestinatario() {
		return destinatario;
	}

	public String getOggettoMessaggio() {
		return Oggetto_del_messaggio;
	}

	public String getTestoMessaggio() {
		return testo_del_messaggio;
	}

}