package com.example.demo.Model;

import java.util.ArrayList;

public class CategoriaMenu {

	String Nome_Categoria_Principale;
	String Nome;
	ArrayList<ElementoMenu> elementimenu_della_Categoria;
	int Posizione_nel_menu;

	public CategoriaMenu(String Nome_Categoria_Principale, String Nome,
			ArrayList<ElementoMenu> elementimenu_della_Categoria, int Posizione_nel_menu) {
		System.out.println("dddd" + Nome_Categoria_Principale);
		this.Nome_Categoria_Principale = Nome_Categoria_Principale;
		this.Nome = Nome;
		this.elementimenu_della_Categoria = elementimenu_della_Categoria;
		this.Posizione_nel_menu = Posizione_nel_menu;
	}

	public String getNome() {
		return Nome;
	}

	public String getNome_Categoria_principale() {
		return Nome_Categoria_Principale;
	}

	public int getPosizionelmenu() {
		return Posizione_nel_menu;
	}

	public ArrayList<ElementoMenu> getelementimenu_della_categoria() {
		return elementimenu_della_Categoria;
	}

}
