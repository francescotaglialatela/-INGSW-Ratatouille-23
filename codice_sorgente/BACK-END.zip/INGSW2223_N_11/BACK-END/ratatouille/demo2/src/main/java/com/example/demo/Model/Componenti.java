package com.example.demo.Model;

public class Componenti {
	String email;
	String password;
	String sesso;
	String nome;
	String ruolo;
	String cognome;

	public Componenti(String email, String password, String nome, String cognome, String sesso, String ruolo) {
		this.email = email;
		this.password = password;
		this.nome = nome;
		this.cognome = cognome;
		this.sesso = sesso;
		this.ruolo = ruolo;
	}

	public String getEmail() {
		return email;
	}

	public String getPassword() {
		return password;
	}

	public String getSesso() {
		return sesso;
	}

	public String getNome() {
		return nome;
	}

	public String getCognome() {
		return cognome;
	}

	public String getRuolo() {
		return ruolo;
	}
}
