package com.example.demo.Model;

public class ElementoMenu {
	String Nome;
	String Descrizione;
	float Costo;
	String Allergeni;

	public ElementoMenu(String Nome, String Descrizione, float Costo, String Allergeni) {
		this.Nome = Nome;
		this.Descrizione = Descrizione;
		this.Costo = Costo;
		this.Allergeni = Allergeni;
	}

	public String getNome() {
		return Nome;
	}

	public String getDescrizione() {
		return Descrizione;
	}

	public float getCosto() {
		return Costo;
	}

	public String getAllergeni() {
		return Allergeni;
	}

}
