package com.example.demo.Model;

public class Ordine {
	int numeroOrdine;
	int numeroTavolo;
	float prezzo;
	String elementoMenu;
	int quantita;
	String registratore;

	public Ordine(int numOrdine, int numTavolo, float prezzo, String elementoMenu, int quantita, String registratore) {
		this.numeroOrdine = numOrdine;
		this.numeroTavolo = numTavolo;
		this.prezzo = prezzo;
		this.elementoMenu = elementoMenu;
		this.quantita = quantita;
		this.registratore = registratore;
	}

	public int getNumeroOrdine() {
		return numeroOrdine;
	}

	public int getNumeroTavolo() {
		return numeroTavolo;
	}

	public float getPrezzo() {
		return prezzo;
	}

	public String getElementoMenu() {
		return elementoMenu;
	}

	public int getQuantita() {
		return quantita;
	}

	public String getRegistratore() {
		return registratore;
	}
}