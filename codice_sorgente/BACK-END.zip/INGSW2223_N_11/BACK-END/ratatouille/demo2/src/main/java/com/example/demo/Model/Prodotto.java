package com.example.demo.Model;

public class Prodotto {
	String codice_a_barre;
	String nome;
	String ingredienti;
	String allergeni;
	String urlfoto;
	String unita;
	String descrizione;
	float quantita;
	float prezzo;

	public Prodotto(String codice_a_barre, String nome, String ingredienti, String allergeni, String urlfoto,
			String unita, String descrizione, float quantita, float prezzo) {
		this.codice_a_barre = codice_a_barre;
		this.nome = nome;
		this.ingredienti = ingredienti;
		this.allergeni = allergeni;
		this.urlfoto = urlfoto;
		this.unita = unita;
		this.descrizione = descrizione;
		this.quantita = quantita;
		this.prezzo = prezzo;
	}

	public String getCodice_a_barre() {
		return this.codice_a_barre;
	}

	public String getNome() {
		return this.nome;
	}

	public String getIngredienti() {
		return this.ingredienti;
	}

	public String getAllergeni() {
		return this.allergeni;
	}

	public String getUrlfoto() {
		return this.urlfoto;
	}

	public String getUnita() {
		return this.unita;
	}

	public String getDescrizione() {
		return this.descrizione;
	}

	public float getQuantita() {
		return this.quantita;
	}

	public float getPrezzo() {
		return this.prezzo;
	}

}
