package com.example.demo.Model;

public class ProdottoOpenFood {
	String codice_a_barre;
	String nome;
	String ingredienti;
	String allergeni;
	String urlfoto;

	public ProdottoOpenFood(String codice_a_barre, String nome, String ingredienti, String allergeni, String urlfoto) {
		this.codice_a_barre = codice_a_barre;
		this.nome = nome;
		this.ingredienti = ingredienti;
		this.allergeni = allergeni;
		this.urlfoto = urlfoto;
	}

	public String getCodice_a_barre() {
		return this.codice_a_barre;
	}

	public String getNome() {
		return this.nome;
	}

	public String getIngredienti() {
		return this.ingredienti;
	}

	public String getAllergeni() {
		return this.allergeni;
	}

	public String getUrlfoto() {
		return this.urlfoto;
	}
}