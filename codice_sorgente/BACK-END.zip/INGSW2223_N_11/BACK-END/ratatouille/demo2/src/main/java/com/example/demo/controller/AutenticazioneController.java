package com.example.demo.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DAO.AutenticazioneDAO;
import com.example.demo.ImplementazioniPostgresDAO.AutenticazioneImplementazionePostgresDAO;

@RestController
@CrossOrigin
public class AutenticazioneController {
	
	
	public boolean login(String email,String password) {
		AutenticazioneDAO aut = new AutenticazioneImplementazionePostgresDAO();
		boolean result = aut.login(email, password);
		return result;
	
	}
	@RequestMapping("/primo_accesso/{email}")
	public int verifica_primo_accesso(@PathVariable String email) {
     AutenticazioneDAO aut = new AutenticazioneImplementazionePostgresDAO();
		int result = aut.verifica_primo_accesso(email);
		
		return result;
	}
	
	public void update_password(String email,String password) {
	     AutenticazioneDAO aut = new AutenticazioneImplementazionePostgresDAO();
		 aut.update_password(email,password);
		}
	@RequestMapping("/verifica_email/{email}")
	public boolean verifica_esistenza_email(@PathVariable String email){
		AutenticazioneDAO aut = new AutenticazioneImplementazionePostgresDAO();
		 return aut.verifica_esistenza_email(email);
	}
	
}