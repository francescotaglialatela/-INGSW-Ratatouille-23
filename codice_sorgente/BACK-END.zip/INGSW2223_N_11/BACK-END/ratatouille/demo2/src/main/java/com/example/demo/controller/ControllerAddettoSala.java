package com.example.demo.controller;

import java.util.Map;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.DAO.OrdineDAO;
import com.example.demo.ImplementazioniPostgresDAO.OrdineImplementazionePostgresDAO;
import com.example.demo.Model.Ordine;

@CrossOrigin
@RestController
public class ControllerAddettoSala {
	@RequestMapping(value = "/addettoSala/service/sendOrdine", method = RequestMethod.POST)
	public boolean registra_Ordine(@RequestBody Map<String, Object> payload) {
		boolean result = false;
		String prezzoString = String.valueOf(payload.get("prezzo"));
		float prezzo = Float.parseFloat(prezzoString);
		int numeroOrdine = (Integer) payload.get("numeroOrdine");
		int numeroTavolo = (Integer) payload.get("numeroTavolo");
		String elementoMenu = (String) payload.get("elementoMenu");
		int quantita = (Integer) payload.get("quantita");
		String registratore = (String) payload.get("registratore");
		OrdineDAO ord = new OrdineImplementazionePostgresDAO();
		Ordine ordinazione = new Ordine(numeroOrdine, numeroTavolo, prezzo, elementoMenu, quantita, registratore);
		result = ord.registraOrdine(ordinazione);
		return result;
	}

	@RequestMapping("/getNumeroOrdine")
	public int assegnaNumeroOrdine() {
		int result = 0;
		OrdineDAO ord = new OrdineImplementazionePostgresDAO();
		result = ord.assegnaNumeroOrdine();
		return result;
	}

}
