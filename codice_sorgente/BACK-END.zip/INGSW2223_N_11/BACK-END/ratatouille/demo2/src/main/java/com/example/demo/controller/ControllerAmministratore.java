package com.example.demo.controller;

import com.example.demo.DAO.*;
import com.example.demo.ImplementazioniPostgresDAO.*;
import com.example.demo.Model.Componenti;
import jakarta.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Map;

import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin
@RestController
public class ControllerAmministratore {
	@RequestMapping(value = "/admin/creazioneutenze", method = RequestMethod.POST)
	public boolean creazioneutenza(@RequestBody Map<String, Object> payload, HttpServletRequest request) {

		String nome = (String) payload.get("Nome");
		String cognome = (String) payload.get("Cognome");
		String sesso = (String) payload.get("Sesso");
		String email = (String) payload.get("Email");
		String password = (String) payload.get("Password");
		String ruolo = (String) payload.get("Ruolo");

		ComponentiDAO componenteDAO = new ComponentiImplementazionePostgresDAO();
		boolean presenza = componenteDAO.verifica_esistenza_componente(email);
		if (presenza == true)
			return false;
		Componenti componente = new Componenti(email, password, nome, cognome, sesso, ruolo);
		return componenteDAO.insert_utenza(componente);
	}

	@RequestMapping("/recupera/dati/ordini-evasi/{dataInizio}/{dataFine}")
	public ArrayList<String> VisualizzaStatisticheOrdiniEvasi(@PathVariable String dataInizio,
			@PathVariable String dataFine) {
		ArrayList<String> ordiniEvasi = new ArrayList<>();
		StatisticheDAO statistiche = new StatisticheImplementazionePostgresDAO();
		ordiniEvasi = statistiche.StatisticheOrdiniEvasi(dataInizio, dataFine);
		return ordiniEvasi;
	}

	@RequestMapping("/recupera/dati/piatti-frequenti/{dataInizio}/{dataFine}")
	public ArrayList<Map<String, Object>> VisualizzaStatistichePiattiFrequenti(@PathVariable String dataInizio,
			@PathVariable String dataFine) {
		ArrayList<Map<String, Object>> piattiFrequenti = new ArrayList<>();
		StatisticheDAO statistiche = new StatisticheImplementazionePostgresDAO();
		piattiFrequenti = statistiche.StatistichePiattiFrequenti(dataInizio, dataFine);
		return piattiFrequenti;
	}
}
