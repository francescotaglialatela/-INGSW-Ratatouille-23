package com.example.demo.controller;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DAO.AvvisoDAO;
import com.example.demo.ImplementazioniPostgresDAO.AvvisoImplementazionePostgresDAO;
import com.example.demo.Model.Avviso;

@RestController
@CrossOrigin
public class ControllerAvviso {

	@RequestMapping("/admin/service/searchMessage/{myEmail}/{nascosto}")
	public ArrayList<String> searchMyMessageFromDB(@PathVariable String myEmail, @PathVariable boolean nascosto) {

		AvvisoDAO avs = new AvvisoImplementazionePostgresDAO();

		ArrayList<String> messageReceived = new ArrayList<>();

		messageReceived = avs.searchMyMessage(myEmail, nascosto);

		return messageReceived;
	}

	@RequestMapping("/admin/service/openMessage/{idAvviso}/{myEmail}")
	public ArrayList<String> openMessage(@PathVariable int idAvviso, @PathVariable String myEmail) {
		AvvisoDAO avs = new AvvisoImplementazionePostgresDAO();

		ArrayList<String> openedMessage = new ArrayList<>();

		openedMessage = avs.openMessage(idAvviso, myEmail);

		return openedMessage;
	}

	public boolean settaggio_visualizzazione_avviso(String myEmail, int idAvviso) {
		boolean result = false;

		AvvisoDAO avs = new AvvisoImplementazionePostgresDAO();
		result = avs.setAvvisoVisualizzato(myEmail, idAvviso);

		return result;

	}

	public boolean settaggio_nascondi_avviso(String myEmail, int idAvviso) {

		boolean result = false;

		AvvisoDAO avs = new AvvisoImplementazionePostgresDAO();

		result = avs.setAvvisoNascosto(myEmail, idAvviso);

		return result;

	}

	@RequestMapping("/message/getNewMessage/{myEmail}")
	public int countNewMessage(@PathVariable String myEmail) {
		int result = 0;

		AvvisoDAO avs = new AvvisoImplementazionePostgresDAO();

		result = avs.countNewMessage(myEmail);

		return result;
	}

	public boolean inserimento_avviso(Avviso avviso) {
		boolean response = false;
		AvvisoDAO avs = new AvvisoImplementazionePostgresDAO();
		response = avs.sendMessage(avviso);
		return response;

	}

}