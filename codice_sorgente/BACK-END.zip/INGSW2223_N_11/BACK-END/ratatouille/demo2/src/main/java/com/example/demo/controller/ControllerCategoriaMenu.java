package com.example.demo.controller;

import com.example.demo.DAO.CategoriaMenuDAO;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletResponse;

import com.example.demo.ImplementazioniPostgresDAO.*;
import com.example.demo.Model.CategoriaMenu;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.ArrayList;

import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin
@RestController
public class ControllerCategoriaMenu {
	@RequestMapping("/getCategorie")
	public void getCategorie(HttpServletResponse response) {
		CategoriaMenuDAO categorieDAO = new CategoriaMenuImplementazionePostgresDAO();
		ArrayList<String> categorie = categorieDAO.getCategorieDAO();
		ObjectMapper mapper = new ObjectMapper();
		try {
			String json = mapper.writeValueAsString(categorie);
			response.setContentType("applicazion/json");
			response.getWriter().write(json);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@RequestMapping("/getCategorie_e_SottoCategorie")
	public ArrayList<String> selezionamento_categorie_sottocategorie() {
		CategoriaMenuDAO categorieDAO = new CategoriaMenuImplementazionePostgresDAO();
		return categorieDAO.getCategorieESottocatgorie();
	}

	@RequestMapping("/numsottocategorie/{nome}")
	public int getNumeroSottoCategorieofCategoria(@PathVariable String nome) {
		System.out.println(nome);
		CategoriaMenuDAO categoriaDAO = new CategoriaMenuImplementazionePostgresDAO();
		return categoriaDAO.numerosottocategorie(nome);
	}

	public void settaggioposizionecategorie(String nome, String posizione) {
		CategoriaMenuDAO categoriaDAO = new CategoriaMenuImplementazionePostgresDAO();
		categoriaDAO.settaggioposizionicategorie(nome, posizione);
	}

	@RequestMapping("/getsottocategorie/{nomeCategoria}")
	public ArrayList<String> getSottoCategorieofCategoria(@PathVariable String nomeCategoria) {
		CategoriaMenuDAO categoriaDAO = new CategoriaMenuImplementazionePostgresDAO();
		return categoriaDAO.sottocategorieofCategoria(nomeCategoria);
	}

	public void eliminazionesottoCategoria(@PathVariable String nomesottoCategoria) {
		CategoriaMenuDAO categoriaDAO = new CategoriaMenuImplementazionePostgresDAO();
		categoriaDAO.eliminazionesottoCategoria(nomesottoCategoria);
	}

	public void eliminazionemacroCategoria_e_sottocategorie(@PathVariable String nomeCategoria) {
		CategoriaMenuDAO categoriaDAO = new CategoriaMenuImplementazionePostgresDAO();
		categoriaDAO.eliminazionemacroCategoria_e_sottocategorie(nomeCategoria);
	}

	@RequestMapping("/getelementidellacategoria/{nomeCategoria}")
	public ArrayList<String> getelementiofCategoria(@PathVariable String nomeCategoria) {
		CategoriaMenuDAO categoriaDAO = new CategoriaMenuImplementazionePostgresDAO();
		return categoriaDAO.elementidellacategoria(nomeCategoria);
	}

	public void rimozione_elemento_dalla_categoria(String nomelementomenu) {
		CategoriaMenuDAO categoriaDAO = new CategoriaMenuImplementazionePostgresDAO();
		categoriaDAO.rimuovielementodellacategoria(nomelementomenu);
	}

	@RequestMapping("/getelementi_dellaMacrocategoria/{nomeCategoria}")
	public ArrayList<String> elementidellaMacrocategoria(@PathVariable String nomeCategoria) {
		CategoriaMenuDAO categoriaDAO = new CategoriaMenuImplementazionePostgresDAO();
		return categoriaDAO.getelementimacrocategoria(nomeCategoria);
	}

	@RequestMapping("/elementi_senza_categoria")
	public ArrayList<String> elementi_senza_categoria() {
		CategoriaMenuDAO categoriaDAO = new CategoriaMenuImplementazionePostgresDAO();
		return categoriaDAO.getelementi_senza_categoria();
	}

	public void inserimentocategoria(@RequestBody CategoriaMenu categoria) {
		CategoriaMenuDAO categoriaDAO = new CategoriaMenuImplementazionePostgresDAO();
		categoriaDAO.inserisciCategoria(categoria);
	}

	public void settaggio_posizione_elementi_senza_categoria(String nome_piatto, int posizione) {
		CategoriaMenuDAO categoriaDAO = new CategoriaMenuImplementazionePostgresDAO();
		categoriaDAO.settaggio_elementi_senza_categoria(nome_piatto, posizione);
	}

}
