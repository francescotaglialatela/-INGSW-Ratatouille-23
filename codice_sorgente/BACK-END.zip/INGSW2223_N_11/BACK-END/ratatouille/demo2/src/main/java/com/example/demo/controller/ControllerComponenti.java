package com.example.demo.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.DAO.ComponentiDAO;
import com.example.demo.ImplementazioniPostgresDAO.ComponentiImplementazionePostgresDAO;

@CrossOrigin
@RestController
public class ControllerComponenti {
	@RequestMapping("/getRuolo/{email}")
	public String getRuolo_utente_autenticato(@PathVariable String email) {
		String result = null;
		ComponentiDAO componente = new ComponentiImplementazionePostgresDAO();
		result = componente.getRuolo_utente_autenticato(email);
		return result;
	}

	@RequestMapping("/getNomeComponente/{email}")
	public String getNomeUtente(@PathVariable String email) {
		String result = null;
		ComponentiDAO componente = new ComponentiImplementazionePostgresDAO();
		result = componente.getNomeUtente(email);
		return result;
	}

	@PutMapping("/admin/service/visualizza/{myEmail}/{idAvviso}")
	public boolean setAvvisoVisualizzato(@PathVariable String myEmail, @PathVariable int idAvviso) {
		ControllerAvviso controlleravviso = new ControllerAvviso();
		return controlleravviso.settaggio_visualizzazione_avviso(myEmail, idAvviso);
	}

	@PutMapping("/message/service/nascondi/{myEmail}/{idAvviso}")
	public boolean setAvvisoNascosto(@PathVariable String myEmail, @PathVariable int idAvviso) {
		ControllerAvviso controlleravviso = new ControllerAvviso();
		return controlleravviso.settaggio_nascondi_avviso(myEmail, idAvviso);

	}

	@RequestMapping("/login/{email}/{password}")
	public boolean effettua_login(@PathVariable String email, @PathVariable String password) {
		AutenticazioneController controllerautenticazione = new AutenticazioneController();
		return controllerautenticazione.login(email, password);
	}

	@RequestMapping("/update_password/{email}/{password}")
	public void cambio_password_al_primoaccesso(@PathVariable String email, @PathVariable String password) {
		AutenticazioneController controllerautenticazione = new AutenticazioneController();
		controllerautenticazione.update_password(email, password);
	}
}
