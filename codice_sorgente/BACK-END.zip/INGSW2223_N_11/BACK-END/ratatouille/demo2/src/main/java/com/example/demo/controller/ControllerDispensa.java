package com.example.demo.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import org.springframework.web.bind.annotation.*;
import com.example.demo.DAO.DispensaDAO;
import com.example.demo.ImplementazioniPostgresDAO.DispensaImplementazionePostgresDAO;
import com.example.demo.Model.Prodotto;
import com.example.demo.Model.ProdottoOpenFood;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletResponse;



@CrossOrigin(origins = "*")
@RestController
public class ControllerDispensa {
	@GetMapping("/dispensa")
	public void  getDispensa(HttpServletResponse response){
		DispensaDAO dispensaDAO=new DispensaImplementazionePostgresDAO();
		ArrayList<Prodotto> prodottidainviare=dispensaDAO.getProdottiDispensa();
		ObjectMapper mapper = new ObjectMapper();
		for (Prodotto p : prodottidainviare) {
		    System.out.println(p);
		}
		try {
			String json = mapper.writeValueAsString(prodottidainviare);
			response.setContentType("applicazion/json");
			response.getWriter().write(json);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	public void AumentaQuantita(@RequestBody Map<String, Object> payload) {
		  DispensaDAO dispensaDAO=new DispensaImplementazionePostgresDAO();
		  String id = (String) payload.get("id");
		  String quantitaString = (String) payload.get("value");
		  float quantita = Float.parseFloat(quantitaString);
		  dispensaDAO.aumentaQta(id, quantita);
		  return;
		}
	
	public void DiminuisciQuantita(@RequestBody Map<String, Object> payload) {
		  DispensaDAO dispensaDAO=new DispensaImplementazionePostgresDAO();
		  String id = (String) payload.get("id");
		  String quantitaString = (String) payload.get("value");
		  float quantita = Float.parseFloat(quantitaString);
		  dispensaDAO.aumentaQta(id, -quantita);
		  return;
		}
	
	public void EliminaProdotto(@RequestBody Map<String, Object> payload) {
		  DispensaDAO dispensaDAO=new DispensaImplementazionePostgresDAO();
		  String id = (String) payload.get("id");
		  System.out.println("prima dell'elimina");
		  dispensaDAO.eliminaProdotto(id);
		  System.out.println("dopo");
		  return;
		}
	@PostMapping("/srcdispensa")
	public void  getSearchedDispensa(@RequestBody Map<String, Object> payload,HttpServletResponse response){
		DispensaDAO dispensaDAO=new DispensaImplementazionePostgresDAO();
		String filtronome = (String) payload.get("ricerca");
		ArrayList<Prodotto> prodottidainviare=dispensaDAO.getProdottiDispensaFiltered(filtronome);
		ObjectMapper mapper = new ObjectMapper();
		try {
			String json = mapper.writeValueAsString(prodottidainviare);
			response.setContentType("applicazion/json");
			response.getWriter().write(json);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@PostMapping("/srcopenfood")
	public void  getProductOpenFood(@RequestBody Map<String, Object> payload,HttpServletResponse response){
		DispensaDAO dispensaDAO=new DispensaImplementazionePostgresDAO();
		String filtronome = (String) payload.get("ricerca");
		ArrayList<ProdottoOpenFood> prodottidainviare=dispensaDAO.getProdottiOpenFoodFiltered(filtronome);
		ObjectMapper mapper = new ObjectMapper();
		try {
			String json = mapper.writeValueAsString(prodottidainviare);
			response.setContentType("applicazion/json");
			response.getWriter().write(json);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@PostMapping("/openfoodbybarcode")
	public void  getProductOpenFoodBarcode(@RequestBody Map<String, Object> payload,HttpServletResponse response){
		DispensaDAO dispensaDAO=new DispensaImplementazionePostgresDAO();
		String filtronome = (String) payload.get("ricerca");
		ProdottoOpenFood prodottidainviare=dispensaDAO.getProdottiOpenFoodBarcode(filtronome);
		ObjectMapper mapper = new ObjectMapper();
		try {
			String json = mapper.writeValueAsString(prodottidainviare);
			response.setContentType("applicazion/json");
			response.getWriter().write(json);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public boolean  insertDispensa(@RequestBody Map<String, Object> payload,HttpServletResponse response){
		DispensaDAO dispensaDAO=new DispensaImplementazionePostgresDAO();	  
		String codiceabarre = (String) payload.get("codiceabarre");
		String nome = (String) payload.get("nome");
		String ingredienti = (String) payload.get("ingredienti");
		String allergeni = (String) payload.get("allergeni");
		String urlfoto = (String) payload.get("urlfoto");
		String quantitaString = (String) payload.get("quantita");
		  float quantita = Float.parseFloat(quantitaString);
		
		String descrizione = (String) payload.get("descrizione");
		String prezzoString = (String) payload.get("prezzo");
		  float prezzo = Float.parseFloat(prezzoString);
		String unita = (String) payload.get("unita");
		return dispensaDAO.insertDispensa(codiceabarre,nome,ingredienti,allergeni,urlfoto,quantita,descrizione,prezzo,unita);

		
	}
	
	@GetMapping("/openfood")
	public void  getOpenFood(HttpServletResponse response){
		DispensaDAO dispensaDAO=new DispensaImplementazionePostgresDAO();
		ArrayList<ProdottoOpenFood> prodottidainviare=dispensaDAO.getProdottiOpenFood();
		ObjectMapper mapper = new ObjectMapper();
		try {
			String json = mapper.writeValueAsString(prodottidainviare);
			response.setContentType("applicazion/json");
			response.getWriter().write(json);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	
}