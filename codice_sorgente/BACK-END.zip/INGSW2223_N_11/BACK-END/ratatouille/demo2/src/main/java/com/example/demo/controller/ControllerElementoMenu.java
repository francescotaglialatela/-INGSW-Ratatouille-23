package com.example.demo.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DAO.CategoriaMenuDAO;
import com.example.demo.DAO.ElementoMenuDAO;
import com.example.demo.DAO.OrdineDAO;
import com.example.demo.ImplementazioniPostgresDAO.CategoriaMenuImplementazionePostgresDAO;
import com.example.demo.ImplementazioniPostgresDAO.ElementoMenuImplementazionePostgresDAO;
import com.example.demo.ImplementazioniPostgresDAO.OrdineImplementazionePostgresDAO;
import com.example.demo.Model.ElementoMenu;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletResponse;

@CrossOrigin
@RestController
public class ControllerElementoMenu {
	public void rimozione_piatto(String nome_piatto) {
		ElementoMenuDAO elementomenu = new ElementoMenuImplementazionePostgresDAO();
		elementomenu.rimozione_piatto_dal_menu(nome_piatto);
		elementomenu.rimozione_piatto_dall_ordinamento(nome_piatto);
		// rimuovi piatto statistiche
		OrdineDAO ordine = new OrdineImplementazionePostgresDAO();
		ordine.rimozione_piatto_dagl_ordini(nome_piatto);
		elementomenu.rimozione_elemento_preparato(nome_piatto);
		// rimuovi piatto dalle statistiche
	}

	public void settaggio_posizioni_piatto(@PathVariable String nome_piatto, @PathVariable int posizione) {
		ElementoMenuDAO elementomenuDAO = new ElementoMenuImplementazionePostgresDAO();
		elementomenuDAO.settaggioposizione_piatto(nome_piatto, posizione);
	}

	@GetMapping("/elementimenu")
	public void getElementi(HttpServletResponse response) {
		ElementoMenuDAO preparazionepiattoDAO = new ElementoMenuImplementazionePostgresDAO();
		ArrayList<ElementoMenu> piattidainviare = preparazionepiattoDAO.getElementiMenu();
		ObjectMapper mapper = new ObjectMapper();
		try {
			String json = mapper.writeValueAsString(piattidainviare);
			response.setContentType("applicazion/json");
			response.getWriter().write(json);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@RequestMapping("/get_elementi_OpenFood")
	public ArrayList<ElementoMenu> getProdottiOpendata() {
		ElementoMenuDAO elementomenuDAO = new ElementoMenuImplementazionePostgresDAO();
		return elementomenuDAO.getProdottiOpendata();
	}

	public boolean verifica_presenza(ElementoMenu elementomenu) {
		ElementoMenuDAO elementomenuDAO = new ElementoMenuImplementazionePostgresDAO();
		;
		ArrayList<ElementoMenu> elementimenu = new ArrayList<ElementoMenu>();
		elementimenu = elementomenuDAO.getElementiMenu();
		for (ElementoMenu elemento : elementimenu) {

			if (elemento.getNome().equalsIgnoreCase(elementomenu.getNome()))
				return true;
		}
		return false;
	}

	public boolean inserisci_piatto(String nome_categoria, ElementoMenu nuovoelemento) {
		ElementoMenuDAO elementomenuDAO = new ElementoMenuImplementazionePostgresDAO();
		boolean presenza = verifica_presenza(nuovoelemento);
		if (presenza == true)
			return false;
		elementomenuDAO.inserisci_piatto(nuovoelemento);

		if (nome_categoria.equals("")) {
			CategoriaMenuDAO categoriamenuDAO = new CategoriaMenuImplementazionePostgresDAO();
			categoriamenuDAO.inserimento_piatto_senza_categoria(nuovoelemento.getNome());
		} else {
			CategoriaMenuDAO categorieDAO = new CategoriaMenuImplementazionePostgresDAO();
			boolean macro_categoria = categorieDAO.verifica_macrocategoria(nome_categoria);
			if (macro_categoria == false) {
				System.out.println("sottocateg");
				categorieDAO.inserimento_piatto_nella_sottocategoria(nome_categoria, nuovoelemento.getNome());
			} else {
				System.out.println("macrocateg");// funziona
				categorieDAO.inserimento_piatto_nella_macro_categoria(nome_categoria, nuovoelemento.getNome());
			}
			elementomenuDAO.inserisci_piatto_nell_ordinamento(nuovoelemento.getNome());
		}
		return true;

	}

	@PostMapping("/elementimenuselezionabili")
	public void getElementiMenuSelezionabili(HttpServletResponse response,
			@RequestBody ArrayList<String> elementiSelezionati) {
		ElementoMenuDAO preparazionepiattoDAO = new ElementoMenuImplementazionePostgresDAO();
		ArrayList<ElementoMenu> piattidainviare = preparazionepiattoDAO
				.getElementiMenuSelezionabili(elementiSelezionati);
		ObjectMapper mapper = new ObjectMapper();
		try {
			String json = mapper.writeValueAsString(piattidainviare);
			response.setContentType("applicazion/json");
			response.getWriter().write(json);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@PostMapping("/elementomenubyname")
	public void getElementoByName(@RequestBody Map<String, Object> payload, HttpServletResponse response) {
		ElementoMenuDAO preparazionepiattoDAO = new ElementoMenuImplementazionePostgresDAO();
		String filtronome = (String) payload.get("ricerca");
		ElementoMenu prodottidainviare = preparazionepiattoDAO.getElementoMenuByName(filtronome);
		ObjectMapper mapper = new ObjectMapper();
		try {
			String json = mapper.writeValueAsString(prodottidainviare);
			response.setContentType("applicazion/json");
			response.getWriter().write(json);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@PostMapping("/srcmenu")
	public void getSearchedMenu(@RequestBody Map<String, Object> payload, HttpServletResponse response) {
		ElementoMenuDAO preparazionepiattoDAO = new ElementoMenuImplementazionePostgresDAO();
		String filtronome = (String) payload.get("ricerca");
		ArrayList<ElementoMenu> prodottidainviare = preparazionepiattoDAO.getMenuFiltered(filtronome);
		ObjectMapper mapper = new ObjectMapper();
		try {
			String json = mapper.writeValueAsString(prodottidainviare);
			response.setContentType("applicazion/json");
			response.getWriter().write(json);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@PostMapping("/ingredientebybarcodeinelemento")
	public String ControlloIngredienteGiaPresenteNelPiatto(@RequestBody Map<String, Object> payload) {
		ElementoMenuDAO preparazionepiattoDAO = new ElementoMenuImplementazionePostgresDAO();
		String elementomenu = (String) payload.get("elementomenu");
		String codiceingrediente = (String) payload.get("codice_a_barre_ingrediente");
		String controllo = preparazionepiattoDAO.ControlloPresenzaIngredienteInPreparazionePiatto(elementomenu,
				codiceingrediente);
		return controllo;
	}

	public void Inserimento_Ingrediente_Nella_Preparazione_di_un_Piatto(String preparatore, String nome_elementomenu,
			String ingrediente, float quantita) {
		ElementoMenuDAO preparazionepiattoDAO = new ElementoMenuImplementazionePostgresDAO();
		preparazionepiattoDAO.insertIngredientePiatto(preparatore, nome_elementomenu, ingrediente, quantita);
	}

	@DeleteMapping("/eliminaingredientedallapreparazione")
	public void EliminaProdottoDallaPreparazioneDelPiatto(@RequestBody Map<String, Object> payload) {
		ElementoMenuDAO preparazionepiattoDAO = new ElementoMenuImplementazionePostgresDAO();
		String nome = (String) payload.get("nomeelementomenu");
		String ingrediente = (String) payload.get("ingrediente");
		preparazionepiattoDAO.eliminaIngredienteAssociato(nome, ingrediente);
		return;
	}

	@PostMapping("/ingredientiassociati")
	public void getIngredientiAssociatiAlPiatto(@RequestBody Map<String, Object> payload,
			HttpServletResponse response) {
		ElementoMenuDAO preparazionepiattoDAO = new ElementoMenuImplementazionePostgresDAO();
		String filtronome = (String) payload.get("ricerca");
		ArrayList<Map<String, Object>> prodottidainviare = preparazionepiattoDAO.getIngredientiElementoMenu(filtronome);
		ObjectMapper mapper = new ObjectMapper();
		try {
			String json = mapper.writeValueAsString(prodottidainviare);
			response.setContentType("applicazion/json");
			response.getWriter().write(json);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@PostMapping("/elementimenu")
	public void get_elementi_menu_selezionabili_per_l_ordine(HttpServletResponse response,
			@RequestBody ArrayList<String> elementiSelezionati) {
		ElementoMenuDAO preparazionepiattoDAO = new ElementoMenuImplementazionePostgresDAO();
		ArrayList<ElementoMenu> piattidainviare = preparazionepiattoDAO
				.getElementiMenuSelezionabili(elementiSelezionati);
		ObjectMapper mapper = new ObjectMapper();
		try {
			String json = mapper.writeValueAsString(piattidainviare);
			response.setContentType("applicazion/json");
			response.getWriter().write(json);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
