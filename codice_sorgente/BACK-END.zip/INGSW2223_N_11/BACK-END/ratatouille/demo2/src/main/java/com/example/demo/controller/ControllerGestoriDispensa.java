package com.example.demo.controller;

import java.util.Map;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletResponse;

@CrossOrigin
@RestController
public class ControllerGestoriDispensa {
	@PutMapping("/aggiungi")
	public void AumentaQuantitaProdottoNellaDispensa(@RequestBody Map<String, Object> payload) {
		ControllerDispensa dispensa = new ControllerDispensa();
		dispensa.AumentaQuantita(payload);

	}

	@PutMapping("/sottrai")
	public void DiminuisciQuantitaProdottoNellaDispensa(@RequestBody Map<String, Object> payload) {
		ControllerDispensa dispensa = new ControllerDispensa();
		dispensa.DiminuisciQuantita(payload);

	}

	@DeleteMapping("/eliminaprodotto")
	public void EliminaProdottoNellaDispensa(@RequestBody Map<String, Object> payload) {
		ControllerDispensa dispensa = new ControllerDispensa();
		dispensa.EliminaProdotto(payload);
	}

	@PutMapping("/inseriscidispensa")
	public boolean InserisciNuovoProdottoNellaDispensa(@RequestBody Map<String, Object> payload,
			HttpServletResponse response) {
		ControllerDispensa dispensa = new ControllerDispensa();
		return dispensa.insertDispensa(payload, response);

	}

}
