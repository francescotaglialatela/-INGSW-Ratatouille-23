package com.example.demo.controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.Model.Avviso;
import com.example.demo.Model.CategoriaMenu;
import com.example.demo.Model.ElementoMenu;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@CrossOrigin
@RestController
public class ControllerGestoriMenu {
	@RequestMapping(value = "/inserimento_piatto", method = RequestMethod.POST)
	public boolean inserisci_piatto(@RequestBody Map<String, Object> payload, HttpServletRequest request) {
		String nome = (String) payload.get("Nome");
		String descrizione = (String) payload.get("Descrizione");
		String allergeni = (String) payload.get("Allergeni");
		String nome_categoria = (String) payload.get("Categoria");
		String costoString = (String) payload.get("Costo");
		Float costo = Float.parseFloat(costoString);
		System.out.println(" " + nome + " " + descrizione + " " + allergeni + " " + nome_categoria + " " + costo);
		ElementoMenu nuovoelemento = new ElementoMenu(nome, descrizione, costo, allergeni);
		ControllerElementoMenu controller_elemento = new ControllerElementoMenu();
		return controller_elemento.inserisci_piatto(nome_categoria, nuovoelemento);

	}

	@RequestMapping("/eliminazione_piatto_dalla_categoria/{nomelementomenu}")
	public void rimozione_piatto(@PathVariable String nomelementomenu) {
		ControllerCategoriaMenu controllermenu = new ControllerCategoriaMenu();
		controllermenu.rimozione_elemento_dalla_categoria(nomelementomenu);
	}

	@RequestMapping("/settaggiocategorie/{nome}/{posizione}")
	public void settaggio_posizione_categoria(@PathVariable String nome, @PathVariable String posizione) {
		ControllerCategoriaMenu controllermenu = new ControllerCategoriaMenu();
		controllermenu.settaggioposizionecategorie(nome, posizione);
	}

	@RequestMapping("/settaggio_posizione_elementi_senza_categoria/{nome_piatto}/{posizione}")
	public void settaggio_posizioni_elementi_menu_senza_categoria(@PathVariable String nome_piatto,
			@PathVariable int posizione) {
		ControllerCategoriaMenu controllermenu = new ControllerCategoriaMenu();
		controllermenu.settaggio_posizione_elementi_senza_categoria(nome_piatto, posizione);
	}

	@RequestMapping("/settaggioposizionielemnti_con_categoria/{nome_piatto}/{posizione}")
	public void settaggio_posizioni_elementi_menu_con_categoria(@PathVariable String nome_piatto,
			@PathVariable int posizione) {
		ControllerElementoMenu controllerelemento = new ControllerElementoMenu();
		controllerelemento.settaggio_posizioni_piatto(nome_piatto, posizione);
	}

	@RequestMapping("/eliminazione_macrocategoria/{nomeCategoria}")
	public void eliminazionemacroCategoria_e_sottocategorie(@PathVariable String nomeCategoria) {
		ControllerCategoriaMenu controllermenu = new ControllerCategoriaMenu();
		controllermenu.eliminazionemacroCategoria_e_sottocategorie(nomeCategoria);
	}

	@RequestMapping("/eliminazione_sottocategoria/{nomesottoCategoria}")
	public void eliminazionesottoCategoria(@PathVariable String nomesottoCategoria) {
		ControllerCategoriaMenu controllermenu = new ControllerCategoriaMenu();
		controllermenu.eliminazionesottoCategoria(nomesottoCategoria);
	}

	@RequestMapping(value = "/inserimento_nuova_categoria", method = RequestMethod.POST)
	public void inserimento_nuova_categoria(@RequestBody Map<String, Object> payload) {
		String Nome_Categoria_Principale = (String) payload.get("Nome_Categoria_Principale");
		String Nome = (String) payload.get("Nome");
		ArrayList<ElementoMenu> elementimenu_della_Categoria = (ArrayList<ElementoMenu>) payload
				.get("elementimenu_della_Categoria");
		ArrayList<ElementoMenu> mappedElements = new ArrayList<>();
		for (Object obj : elementimenu_della_Categoria) {
			LinkedHashMap<String, Object> map = (LinkedHashMap<String, Object>) obj;
			String nome = (String) map.get("Nome");
			String descrizione = (String) map.get("Descrizione");
			String costoString = map.get("Costo").toString();
			float costo = Float.parseFloat(costoString);
			String allergeni = (String) map.get("Allergeni");
			ElementoMenu element = new ElementoMenu(nome, descrizione, costo, allergeni);
			mappedElements.add(element);
		}

		int Posizione_nel_menu = (Integer) payload.get("Posizione_nel_menu");
		CategoriaMenu categoria = new CategoriaMenu(Nome_Categoria_Principale, Nome, mappedElements,
				Posizione_nel_menu);
		ControllerCategoriaMenu controllermenu = new ControllerCategoriaMenu();
		controllermenu.inserimentocategoria(categoria);
	}

	@RequestMapping(value = "/admin/service/sendMessage", method = RequestMethod.POST)
	public boolean inserisci_avviso(@RequestBody Map<String, Object> payload, HttpServletResponse response) {
		String destinatario = (String) payload.get("destinatario");
		String mittente = (String) payload.get("mittente");
		String oggetto = (String) payload.get("Oggetto_del_messaggio");
		String testo = (String) payload.get("testo_del_messaggio");
		Avviso avviso = new Avviso(oggetto, testo, destinatario, mittente);
		ControllerAvviso controlleravviso = new ControllerAvviso();
		return controlleravviso.inserimento_avviso(avviso);
	}

	@PutMapping("/inseisciingredientepreparazionepiatto")
	public void InserisciIngredienteNellaPreparazionePiatto(@RequestBody Map<String, Object> payload,
			HttpServletResponse response) {
		String preparatore = (String) payload.get("email");
		String nome_elementomenu = (String) payload.get("nomeelementomenu");
		String ingrediente = (String) payload.get("ingrediente");
		String quantitaString = (String) payload.get("quantita");
		float quantita = Float.parseFloat(quantitaString);
		ControllerElementoMenu controllerelemento = new ControllerElementoMenu();
		controllerelemento.Inserimento_Ingrediente_Nella_Preparazione_di_un_Piatto(preparatore, nome_elementomenu,
				ingrediente, quantita);

	}
}
