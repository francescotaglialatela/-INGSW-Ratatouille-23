package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertEquals;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.DAO.AvvisoDAO;
import com.example.demo.DAO.ElementoMenuDAO;
import com.example.demo.ImplementazioniPostgresDAO.AvvisoImplementazionePostgresDAO;
import com.example.demo.ImplementazioniPostgresDAO.ElementoMenuImplementazionePostgresDAO;

@SpringBootTest
class Demo2ApplicationTests {
	String emailPresente = "example@email.com";
	String emailNonPresente = "email@";
	int idPresente = 1;
	int idNonPresenteMaggioreDiZero = 50;
	int idMinoreDiZero = -1;
	
	String ingredientePresente = "ingredientetest";
	String ingredienteNonPresente = "ingnonpresente";
	String elementoPresente = "elementotest";
	String elementoNonPresente = "elementononpresentetest";
	
	

	@Test
	public void testSetAvvisoVisualizzatoIdInvalidoEMailPresente() {
		//Caso ID <=0 e indirizzo email presente:
	    int idAvviso = idMinoreDiZero;
	    String myEmail = emailPresente;
    	AvvisoDAO Avviso = new  AvvisoImplementazionePostgresDAO();
	    boolean result = Avviso.setAvvisoVisualizzato(myEmail, idAvviso);
	    assertFalse(result);
	}
	@Test
	public void testSetAvvisoVisualizzatoIdInvalidoEMailNonPresente() {
		//Caso ID <=0 e indirizzo email non presente:
	    int idAvviso = idMinoreDiZero;
	    String myEmail = emailNonPresente;
    	AvvisoDAO Avviso = new  AvvisoImplementazionePostgresDAO();
	    boolean result = Avviso.setAvvisoVisualizzato(myEmail, idAvviso);
	    assertFalse(result);
	}
	@Test
	public void testSetAvvisoVisualizzatoIdInvalidoEMailLunghezzaInvalida() {
		//Caso ID <=0 e lunghezza dell'indirizzo email <=0
	    int idAvviso = idMinoreDiZero;
	    String myEmail = "";
    	AvvisoDAO Avviso = new  AvvisoImplementazionePostgresDAO();
	    boolean result = Avviso.setAvvisoVisualizzato(myEmail, idAvviso);
	    assertFalse(result);
	}
	@Test
	public void testSetAvvisoVisualizzatoIdPresenteEMailPresente() {
		//Caso ID >0, ID presente nel database, indirizzo email presente
	    int idAvviso = idPresente;
	    String myEmail = emailPresente;
    	AvvisoDAO Avviso = new  AvvisoImplementazionePostgresDAO();
	    boolean result = Avviso.setAvvisoVisualizzato(myEmail, idAvviso);
	    assertTrue(result);
	}
	@Test
	public void testSetAvvisoVisualizzatoIdPresenteEMailNonPresente() {
		//Caso ID >0, ID presente nel database, indirizzo email non presente:
	    int idAvviso = idPresente;
	    String myEmail = emailNonPresente;
    	AvvisoDAO Avviso = new  AvvisoImplementazionePostgresDAO();
	    boolean result = Avviso.setAvvisoVisualizzato(myEmail, idAvviso);
	    assertFalse(result);
	}
	@Test
	public void testSetAvvisoVisualizzatoIdPresenteEMailLunghezzaInvalida() {
		//Caso ID >0, ID presente nel database, e lunghezza dell'indirizzo email <=0:
	    int idAvviso = idPresente;
	    String myEmail = "";
    	AvvisoDAO Avviso = new  AvvisoImplementazionePostgresDAO();
	    boolean result = Avviso.setAvvisoVisualizzato(myEmail, idAvviso);
	    assertFalse(result);
	}
	@Test
	public void testSetAvvisoVisualizzatoIdNonPresenteMaggioreDiZeroEMailNonPresente() {
		//Caso ID >0, ID non presente nel database, indirizzo email non presente:
	    int idAvviso = idNonPresenteMaggioreDiZero;
	    String myEmail = emailNonPresente;
    	AvvisoDAO Avviso = new  AvvisoImplementazionePostgresDAO();
	    boolean result = Avviso.setAvvisoVisualizzato(myEmail, idAvviso);
	    assertFalse(result);
	}
	@Test
	public void testSetAvvisoVisualizzatoIdNonPresenteMaggioreDiZeroEMailPresente() {
		//Caso ID >0, ID non presente nel database, indirizzo email presente:
	    int idAvviso = idNonPresenteMaggioreDiZero;
	    String myEmail = emailPresente;
    	AvvisoDAO Avviso = new  AvvisoImplementazionePostgresDAO();
	    boolean result = Avviso.setAvvisoVisualizzato(myEmail, idAvviso);
	    assertFalse(result);
	}
	@Test
	public void testSetAvvisoVisualizzatoIdNonPresenteMaggioreDiZeroEMailLunghezzaInvalida() {
	    //Caso ID >0, ID non presente nel database, lunghezza mail<=0
		int idAvviso = idNonPresenteMaggioreDiZero;
	    String myEmail = "";
    	AvvisoDAO Avviso = new  AvvisoImplementazionePostgresDAO();
	    boolean result = Avviso.setAvvisoVisualizzato(myEmail, idAvviso);
	    assertFalse(result);
	}
	@Test
    public void testSetAvvisoVisualizzatoIdPresenteEmailNull() {
		//Caso ID >0, ID presente nel database, mail null
        int idAvviso = idPresente;
        String myEmail = null;
    	AvvisoDAO Avviso = new  AvvisoImplementazionePostgresDAO();
        boolean result = Avviso.setAvvisoVisualizzato(myEmail, idAvviso);
        assertFalse(result);
    }
	@Test
    public void testSetAvvisoVisualizzatoIdInvalidoEmailNull() {
		//Caso ID <=0 , mail null
        int idAvviso = idMinoreDiZero;
        String myEmail = null;
    	AvvisoDAO Avviso = new  AvvisoImplementazionePostgresDAO();
        boolean result = Avviso.setAvvisoVisualizzato(myEmail, idAvviso);
        assertFalse(result);
    }
	@Test
    public void testSetAvvisoVisualizzatoIdNonPresenteMaggioreDiZeroEmailNull() {
		//Caso ID >0, ID non presente nel database, mail null
        int idAvviso = idNonPresenteMaggioreDiZero;
        String myEmail = null;
    	AvvisoDAO Avviso = new  AvvisoImplementazionePostgresDAO();
        boolean result = Avviso.setAvvisoVisualizzato(myEmail, idAvviso);
        assertFalse(result);
    }
	//inizio testing secondo metodo
	@Test
	public void testControlloPresenzaIngredienteInPreparazionePiattoWithNullInput() {
		//Caso elemento null, codice null
		String elementomenu = null;
		String codiceingrediente = null;
		ElementoMenuDAO preparazionepiattoDAO=new ElementoMenuImplementazionePostgresDAO();
		String result = preparazionepiattoDAO.ControlloPresenzaIngredienteInPreparazionePiatto(elementomenu, codiceingrediente);
		assertEquals("nonPresente", result);
	}
	@Test
	public void testControlloPresenzaIngredienteInPreparazionePiattoElementoNullCodiceLunghezzaInvalida() {
		//Caso elemento null, lunghezza codice <=0
		String elementomenu = null;
		String codiceingrediente = "";
		ElementoMenuDAO preparazionepiattoDAO=new ElementoMenuImplementazionePostgresDAO();
		String result = preparazionepiattoDAO.ControlloPresenzaIngredienteInPreparazionePiatto(elementomenu, codiceingrediente);
		assertEquals("nonPresente", result);
	}
	@Test
	public void testControlloPresenzaIngredienteInPreparazionePiattoElementoNullCodicePresente() {
		//Caso elemento null, codice presente
		String elementomenu = null;
		String codiceingrediente = ingredientePresente;
		ElementoMenuDAO preparazionepiattoDAO=new ElementoMenuImplementazionePostgresDAO();
		String result = preparazionepiattoDAO.ControlloPresenzaIngredienteInPreparazionePiatto(elementomenu, codiceingrediente);
		assertEquals("nonPresente", result);
	}
	@Test
	public void testControlloPresenzaIngredienteInPreparazionePiattoElementoNullCodiceNonPresente() {
		//Caso elemento null, codice presente
		String elementomenu = null;
		String codiceingrediente =ingredienteNonPresente;
		ElementoMenuDAO preparazionepiattoDAO=new ElementoMenuImplementazionePostgresDAO();
		String result = preparazionepiattoDAO.ControlloPresenzaIngredienteInPreparazionePiatto(elementomenu, codiceingrediente);
		assertEquals("nonPresente", result);
	}
	@Test
	public void testControlloPresenzaIngredienteInPreparazionePiattoElementoPresenteCodiceNull() {
		//Caso elemento presente, codice null
		String elementomenu = elementoPresente;
		String codiceingrediente =null;
		ElementoMenuDAO preparazionepiattoDAO=new ElementoMenuImplementazionePostgresDAO();
		String result = preparazionepiattoDAO.ControlloPresenzaIngredienteInPreparazionePiatto(elementomenu, codiceingrediente);
		assertEquals("nonPresente", result);
	}
	@Test
	public void testControlloPresenzaIngredienteInPreparazionePiattoElementoPresenteCodiceLunghezzaInvalida() {
		//Caso elemento presente, lunghezza codice <=0
		String elementomenu = elementoPresente;
		String codiceingrediente ="";
		ElementoMenuDAO preparazionepiattoDAO=new ElementoMenuImplementazionePostgresDAO();
		String result = preparazionepiattoDAO.ControlloPresenzaIngredienteInPreparazionePiatto(elementomenu, codiceingrediente);
		assertEquals("nonPresente", result);
	}
	@Test
	public void testControlloPresenzaIngredienteInPreparazionePiattoElementoPresenteCodicePresente() {
		//Caso elemento presente, codice presente
		String elementomenu = elementoPresente;
		String codiceingrediente = ingredientePresente;
		ElementoMenuDAO preparazionepiattoDAO=new ElementoMenuImplementazionePostgresDAO();
		String result = preparazionepiattoDAO.ControlloPresenzaIngredienteInPreparazionePiatto(elementomenu, codiceingrediente);
		assertEquals("Presente", result);
	}
	@Test
	public void testControlloPresenzaIngredienteInPreparazionePiattoElementoPresenteCodiceNonPresente() {
		//Caso elemento presente, codice non presente
		String elementomenu = elementoPresente;
		String codiceingrediente =ingredienteNonPresente;
		ElementoMenuDAO preparazionepiattoDAO=new ElementoMenuImplementazionePostgresDAO();
		String result = preparazionepiattoDAO.ControlloPresenzaIngredienteInPreparazionePiatto(elementomenu, codiceingrediente);
		assertEquals("nonPresente", result);
	}
	@Test
	public void testControlloPresenzaIngredienteInPreparazionePiattoElementoNonPresenteCodiceNull() {
		//Caso elemento nonpresente, codice null
		String elementomenu = elementoNonPresente;
		String codiceingrediente =null;
		ElementoMenuDAO preparazionepiattoDAO=new ElementoMenuImplementazionePostgresDAO();
		String result = preparazionepiattoDAO.ControlloPresenzaIngredienteInPreparazionePiatto(elementomenu, codiceingrediente);
		assertEquals("nonPresente", result);
	}
	@Test
	public void testControlloPresenzaIngredienteInPreparazionePiattoElementoNonPresenteCodiceLunghezzaInvalida() {
		//Caso elemento non presente, lunghezza codice <=0
		String elementomenu = elementoNonPresente;
		String codiceingrediente ="";
		ElementoMenuDAO preparazionepiattoDAO=new ElementoMenuImplementazionePostgresDAO();
		String result = preparazionepiattoDAO.ControlloPresenzaIngredienteInPreparazionePiatto(elementomenu, codiceingrediente);
		assertEquals("nonPresente", result);
	}
	@Test
	public void testControlloPresenzaIngredienteInPreparazionePiattoElementoNonPresenteCodicePresente() {
		//Caso elemento non presente, codice presente
		String elementomenu = elementoNonPresente;
		String codiceingrediente = ingredientePresente;
		ElementoMenuDAO preparazionepiattoDAO=new ElementoMenuImplementazionePostgresDAO();
		String result = preparazionepiattoDAO.ControlloPresenzaIngredienteInPreparazionePiatto(elementomenu, codiceingrediente);
		assertEquals("nonPresente", result);
	}
	@Test
	public void testControlloPresenzaIngredienteInPreparazionePiattoElementoNonPresenteCodiceNonPresente() {
		//Caso elemento non presente, codice non presente
		String elementomenu = elementoNonPresente;
		String codiceingrediente = ingredienteNonPresente;
		ElementoMenuDAO preparazionepiattoDAO=new ElementoMenuImplementazionePostgresDAO();
		String result = preparazionepiattoDAO.ControlloPresenzaIngredienteInPreparazionePiatto(elementomenu, codiceingrediente);
		assertEquals("nonPresente", result);
	}
	@Test
	public void testControlloPresenzaIngredienteInPreparazionePiattoElementoLunghezzaInvalidaCodiceNull() {
		//Caso lunghezza elemento <=0, codice null
		String elementomenu = "";
		String codiceingrediente =null;
		ElementoMenuDAO preparazionepiattoDAO=new ElementoMenuImplementazionePostgresDAO();
		String result = preparazionepiattoDAO.ControlloPresenzaIngredienteInPreparazionePiatto(elementomenu, codiceingrediente);
		assertEquals("nonPresente", result);
	}
	@Test
	public void testControlloPresenzaIngredienteInPreparazionePiattoElementoLunghezzaInvalidaCodiceLunghezzaInvalida() {
		//Caso lunghezza elemento <=0, lunghezza codice <=0
		String elementomenu = "";
		String codiceingrediente ="";
		ElementoMenuDAO preparazionepiattoDAO=new ElementoMenuImplementazionePostgresDAO();
		String result = preparazionepiattoDAO.ControlloPresenzaIngredienteInPreparazionePiatto(elementomenu, codiceingrediente);
		assertEquals("nonPresente", result);
	}
	@Test
	public void testControlloPresenzaIngredienteInPreparazionePiattoElementoLunghezzaInvalidaCodicePresente() {
		//Caso lunghezza elemento <=0, codice presente
		String elementomenu = "";
		String codiceingrediente = ingredientePresente;
		ElementoMenuDAO preparazionepiattoDAO=new ElementoMenuImplementazionePostgresDAO();
		String result = preparazionepiattoDAO.ControlloPresenzaIngredienteInPreparazionePiatto(elementomenu, codiceingrediente);
		assertEquals("nonPresente", result);
	}
	@Test
	public void testControlloPresenzaIngredienteInPreparazionePiattoElementoLunghezzaInvalidaCodiceNonPresente() {
		//Caso lunghezza elemento <=0, codice non presente
		String elementomenu = "";
		String codiceingrediente =ingredienteNonPresente;
		ElementoMenuDAO preparazionepiattoDAO=new ElementoMenuImplementazionePostgresDAO();
		String result = preparazionepiattoDAO.ControlloPresenzaIngredienteInPreparazionePiatto(elementomenu, codiceingrediente);
		assertEquals("nonPresente", result);
	}


	
	
	
}
