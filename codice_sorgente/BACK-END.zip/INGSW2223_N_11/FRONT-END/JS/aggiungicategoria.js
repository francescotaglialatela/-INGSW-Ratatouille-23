document.getElementById('annulla').onclick = function () {

  mostraPopup();
}
let sottocategorie_visualizzate=0;
let trovata_sottocategoria=0;
//selezione elementi macro-categ
var select = document.getElementById("categories-list");
var options = select.getElementsByTagName("option");

for (var i = 0; i < options.length; i++) {
    options[i].onclick = function() {
      this.style.backgroundColor = "red";
  };
}

let menuVisible = false;

document.getElementById("search-input").addEventListener("focus", function(){
  menuVisible = true;
  document.getElementById("categories-list").style.display = "block";
});
document.getElementById("categories-list").addEventListener("mousedown", function(){
  menuVisible = true;
});

document.addEventListener("click", function(event){
  if (!menuVisible) return;
  if (!event.target.closest("#categories-list") && event.target !== document.getElementById("search-input")) {
    menuVisible = false;
    document.getElementById("categories-list").style.display = "none";
  }
});

document.getElementById("categories-list").addEventListener("change", function(){
  document.getElementById("search-input").value = this.value;
});
document.getElementById("search-input").addEventListener("input", filterOptions);

function filterOptions() {
  var input, filter, select, option;
  input = document.getElementById("search-input");
  filter = input.value.toUpperCase();
  select = document.getElementById("categories-list");
  option = select.getElementsByTagName("option");
  for (var i = 0; i < option.length; i++) {
    var txtValue = option[i].textContent || option[i].innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      option[i].style.display = "";
    } else {
      option[i].style.display = "none";
    }
  }
}
function presenza_sottocategorie2(nomecategoria,elementi,index){
  presenza_sottocategorie(nomecategoria,elementi,index);
  return;
}
function presenza_sottocategorie(nomecategoria,arr,index) {
  return new Promise((resolve, reject) => {
      if (index >= arr.length||trovata_sottocategoria==1) {
          
         
          resolve();
          return;
      }
      $.ajax({
          url:  'http://87.3.142.174:8085/getsottocategorie/'+arr[index],
          type: 'GET',
          dataType: 'json',
          success:function(sottocategorie) {
              for (let i = 0; i < sottocategorie.length; i++) {
                 
                  if(sottocategorie[i]==nomecategoria){
                      
                      trovata_sottocategoria=1;
                      resolve();
                      return;
                  }
              }
              presenza_sottocategorie(nomecategoria,arr,index+1);
              
          resolve();
          return;
            }})})}
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
function mostraPopup_campi_vuoti_o_nonvalidi(avviso){
  const modal = document.createElement('div');
  modal.classList.add('modal', 'fade');
  modal.setAttribute('id', 'staticBackdrop');
  modal.setAttribute('data-bs-backdrop', 'static');
  modal.setAttribute('data-bs-keyboard', 'false');
  modal.setAttribute('tabindex', '-1');
  modal.setAttribute('aria-labelledby', 'staticBackdropLabel');
  modal.setAttribute('aria-hidden', 'true');
  const dialog = document.createElement('div');
  dialog.classList.add('modal-dialog', 'modal-dialog-centered');
  const content = document.createElement('div');
  content.classList.add('modal-content');
  content.setAttribute('style', 'border-radius: 41px;');
  const header = document.createElement('div');
  header.classList.add('modal-header');
  const title = document.createElement('h1');
  title.classList.add('modal-title', 'fs-5');
  title.setAttribute('id', 'staticBackdropLabel');
  title.innerHTML = 'Avviso';
  const body = document.createElement('div');
  body.classList.add('modal-body');
  const text = document.createElement('p');
  text.setAttribute('id', 'testo-pop-up');
  text.innerHTML = avviso;
  const footer = document.createElement('div');
  footer.classList.add('modal-footer');
  modal.appendChild(dialog);
  dialog.appendChild(content);
  content.appendChild(header);
  header.appendChild(title);
  content.appendChild(body);
  body.appendChild(text);
  content.appendChild(footer);
  document.body.appendChild(modal);
  $(modal).modal('show');
  setTimeout(function(){
    $(modal).modal('hide');
  }, 4000);
}
async function mostraPopupConferma(nomecategoria){
 
  const modal = document.createElement('div');
  modal.classList.add('modal', 'fade');
  modal.setAttribute('id', 'staticBackdrop');
  modal.setAttribute('data-bs-backdrop', 'static');
  modal.setAttribute('data-bs-keyboard', 'false');
  modal.setAttribute('tabindex', '-1');
  modal.setAttribute('aria-labelledby', 'staticBackdropLabel');
  modal.setAttribute('aria-hidden', 'true');
  const dialog = document.createElement('div');
  dialog.classList.add('modal-dialog', 'modal-dialog-centered');
  const content = document.createElement('div');
  content.classList.add('modal-content');
  content.setAttribute('style', 'border-radius: 41px;');
  const header = document.createElement('div');
  header.classList.add('modal-header');
  const title = document.createElement('h1');
  title.classList.add('modal-title', 'fs-5');
  title.setAttribute('id', 'staticBackdropLabel');
  title.innerHTML = 'Avviso';
  const body = document.createElement('div');
  body.classList.add('modal-body');
  const text = document.createElement('p');
  text.setAttribute('id', 'testo-pop-up');
  text.innerHTML = 'Sei sicuro di voler aggiungere la categoria '+nomecategoria+' con i relativi piatti:';
var checkboxes = document.querySelectorAll("input[type='checkbox']");
for (var i = 0; i < checkboxes.length; i++) {
  if (checkboxes[i].checked) {
    text.innerHTML=text.innerHTML+checkboxes[i].value+',';
  }
}
text.innerHTML = text.innerHTML.substring(0,text.innerHTML.length - 1) + ".";

  const button_ann = document.createElement('button');
  button_ann.type = 'button';
  button_ann.classList.add('btn', 'btnannullapopup');

  button_ann.innerHTML = 'NO';
  const button_conferma = document.createElement('button');
  button_conferma.type = 'button';
  button_conferma.classList.add('btn', 'btnconfermapopup');
  // button_conferma.setAttribute('style', 'border-radius: 61px;');
  button_conferma.innerHTML = 'SI';
  button_ann.style.marginLeft = '9px';
  button_ann.style.marginRight = '148px';

  const footer = document.createElement('div');
  footer.classList.add('modal-footer');
  button_ann.addEventListener('click', function () {
    // Codice per rimuovere il mock-up qui
    $(modal).modal('hide');


  });

  button_conferma.addEventListener('click', async function () {
       for (let i = 0; i < elementi.length; i++) {
        //inserimento_lista_Categorie(data[i]);
        if(elementi[i]==nomecategoria){
          
          
          text.innerHTML='Categoria già presente.Non è stato possibile effettuare l inserimento';
          button_conferma.style.display = "none";
          button_ann.style.display = "none";
          await sleep(4000);
          $(modal).modal('hide');
          return;
        }
        
      }
      
      await presenza_sottocategorie(nomecategoria,elementi,0);
      
     
      if(trovata_sottocategoria==1){
        text.innerHTML='Categoria già presente.Non è stato possibile effettuare l inserimento';
          button_conferma.style.display = "none";
          button_ann.style.display = "none";
          await sleep(4000);
          trovata_sottocategoria=0;
          $(modal).modal('hide');
          
          return;
      }else{
        var categoria_principale = document.getElementById("search-input");
        var categoria_principale = categoria_principale.value;
        
        text.innerHTML='Categoria '+nomecategoria+' inserita con successo.';
        
        for (var i = 0; i < checkboxes.length; i++) {
          if (checkboxes[i].checked) {
            
          }
        }
        let response;
        let request = new XMLHttpRequest();
        request.open("POST", "http://87.3.142.174:8085/inserimento_nuova_categoria");
        request.setRequestHeader('Content-Type', 'application/json');
        var data = {};
        data.Nome_Categoria_Principale=categoria_principale;
       
        data.Nome=nomecategoria;
       
        data.elementimenu_della_Categoria=[];
        data.Posizione_nel_menu=10;
       
        for (var i = 0; i < checkboxes.length; i++) {
          if (checkboxes[i].checked) {
            var piatto={Nome:checkboxes[i].value,Costo:0,Descrizione:"",Allergeni:""};
            data.elementimenu_della_Categoria.push(piatto);
          }
        }
        
        for (var i = 0; i < data.elementimenu_della_Categoria.length; i++) {
         
      }
     
        request.send(JSON.stringify(data));
        button_conferma.style.display = "none";
        button_ann.style.display = "none";
        await sleep(4000);
        $(modal).modal('hide');
        window.location.replace("categoriemenu.html");
        return;
      } 
    $(modal).modal('hide');
  });


  // Appendi gli elementi l'uno all'altro
  modal.appendChild(dialog);
  dialog.appendChild(content);
  content.appendChild(header);
  header.appendChild(title);
  content.appendChild(body);
  body.appendChild(text);
  content.appendChild(footer);
  footer.appendChild(button_ann);
  footer.appendChild(button_conferma);

  document.body.appendChild(modal);
  $(modal).modal('show');

}

function funzione_clicked(){
  //piatti selezionati
  let piatti_selezionati=0;
  var checkboxes = document.querySelectorAll("input[type='checkbox']");
  for (var i = 0; i < checkboxes.length; i++) {
    if (checkboxes[i].checked) {
      piatti_selezionati=piatti_selezionati+1;
      
    }
  }
 
  //piatti selezionati
//macro-categoria e controllo validità
let valido_macrocategoria=0;
var input = document.getElementById("search-input");
var inputValue = input.value;

var select = document.getElementById("categories-list");
var options = select.options;
for (var i = 0; i < options.length; i++) {
  if(options[i].text==inputValue)
  valido_macrocategoria=1;
 
}
if(inputValue=="")
valido_macrocategoria=1;

 //macro-categoria e controllo validità
 //categoria e controllo validità
let valido_categoria=0;
var nomecategoria = document.getElementById("nome-categoria");
var nomecategoriaValue = nomecategoria.value;
var pattern = /^[a-zA-Z0-9\s!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~]+$/;
if(nomecategoriaValue.trim().length > 0 && nomecategoriaValue.match(pattern))
valido_categoria=1;


//categoria e controllo validità
if(piatti_selezionati>0&&valido_categoria==1&&valido_macrocategoria==1){
  
  mostraPopupConferma(nomecategoriaValue);
}else{
  if(valido_categoria==0&&piatti_selezionati==0){
  mostraPopup_campi_vuoti_o_nonvalidi("Non hai selezionato i piatti e non hai inserito il nome della categoria che si desidera creare");
  }else{
    if(piatti_selezionati==0){
      mostraPopup_campi_vuoti_o_nonvalidi("Non hai selezionato i piatti.Non è consentito la creazione di categorie senza piatti.");
    }else{
      if(valido_categoria==0)
      mostraPopup_campi_vuoti_o_nonvalidi("Non hai inserito il nome della categoria che si desidera creare");
    }
  }
}
}

document.getElementById('conferma').onclick = function () {
 
  
  funzione_clicked();
}
document.getElementById('back').onclick = function () {
 
  mostraPopup()
}
document.getElementById('home').onclick = function () {
 
  mostraPopupgotoHome()
}
function mostraPopupgotoHome() {
  const modal = document.createElement('div');
  modal.classList.add('modal', 'fade');
  modal.setAttribute('id', 'staticBackdrop');
  modal.setAttribute('data-bs-backdrop', 'static');
  modal.setAttribute('data-bs-keyboard', 'false');
  modal.setAttribute('tabindex', '-1');
  modal.setAttribute('aria-labelledby', 'staticBackdropLabel');
  modal.setAttribute('aria-hidden', 'true');

  const dialog = document.createElement('div');
  dialog.classList.add('modal-dialog', 'modal-dialog-centered');

  const content = document.createElement('div');
  content.classList.add('modal-content');
  content.setAttribute('style', 'border-radius: 41px;');

  const header = document.createElement('div');
  header.classList.add('modal-header');

  const title = document.createElement('h1');
  title.classList.add('modal-title', 'fs-5');
  title.setAttribute('id', 'staticBackdropLabel');
  title.innerHTML = 'Avviso';

  const body = document.createElement('div');
  body.classList.add('modal-body');

  const text = document.createElement('p');
  text.setAttribute('id', 'testo-pop-up');
  text.innerHTML = 'Sei sicuro di voler tornare alla Home?';
  const button_ann = document.createElement('button');
  button_ann.type = 'button';
  button_ann.classList.add('btn', 'btnannullapopup');

  button_ann.innerHTML = 'NO';
  const button_conferma = document.createElement('button');
  button_conferma.type = 'button';
  button_conferma.classList.add('btn', 'btnconfermapopup');
  // button_conferma.setAttribute('style', 'border-radius: 61px;');
  button_conferma.innerHTML = 'SI';
  button_ann.style.marginLeft = '9px';
  button_ann.style.marginRight = '148px';

  const footer = document.createElement('div');
  footer.classList.add('modal-footer');
  button_ann.addEventListener('click', function () {
    // Codice per rimuovere il mock-up qui
    $(modal).modal('hide');


  });

  button_conferma.addEventListener('click', function () {

    $(modal).modal('hide');
    var ruolo=getCookie("ruolo");
    ruolo = ruolo.substring(1,ruolo.length -1);
    
    
      if(ruolo=="amministratore")
      window.location.replace("home-admin.html");
        if(ruolo=="supervisore")
        window.location.replace("home-supervisore.html");
        if(ruolo=="addetto cucina")
        window.location.replace("home-AddettoCucina.html");
        if(ruolo=="addetto sala")
        window.location.replace("home-AddettoSala.html");

  });


  // Appendi gli elementi l'uno all'altro
  modal.appendChild(dialog);
  dialog.appendChild(content);
  content.appendChild(header);
  header.appendChild(title);
  content.appendChild(body);
  body.appendChild(text);
  content.appendChild(footer);
  footer.appendChild(button_ann);
  footer.appendChild(button_conferma);

  document.body.appendChild(modal);
  $(modal).modal('show');

}
function getCookie(nomeCookie) {
  var name = nomeCookie + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(';');
  for (var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}
function mostraPopup() {
  const modal = document.createElement('div');
  modal.classList.add('modal', 'fade');
  modal.setAttribute('id', 'staticBackdrop');
  modal.setAttribute('data-bs-backdrop', 'static');
  modal.setAttribute('data-bs-keyboard', 'false');
  modal.setAttribute('tabindex', '-1');
  modal.setAttribute('aria-labelledby', 'staticBackdropLabel');
  modal.setAttribute('aria-hidden', 'true');

  const dialog = document.createElement('div');
  dialog.classList.add('modal-dialog', 'modal-dialog-centered');

  const content = document.createElement('div');
  content.classList.add('modal-content');
  content.setAttribute('style', 'border-radius: 41px;');

  const header = document.createElement('div');
  header.classList.add('modal-header');

  const title = document.createElement('h1');
  title.classList.add('modal-title', 'fs-5');
  title.setAttribute('id', 'staticBackdropLabel');
  title.innerHTML = 'Avviso';

  const body = document.createElement('div');
  body.classList.add('modal-body');

  const text = document.createElement('p');
  text.setAttribute('id', 'testo-pop-up');
  text.innerHTML = 'Sei sicuro di voler terminare l aggiunta della categoria ?';
  const button_ann = document.createElement('button');
  button_ann.type = 'button';
  button_ann.classList.add('btn', 'btnannullapopup');

  button_ann.innerHTML = 'NO';
  const button_conferma = document.createElement('button');
  button_conferma.type = 'button';
  button_conferma.classList.add('btn', 'btnconfermapopup');
  // button_conferma.setAttribute('style', 'border-radius: 61px;');
  button_conferma.innerHTML = 'SI';
  button_ann.style.marginLeft = '9px';
  button_ann.style.marginRight = '148px';

  const footer = document.createElement('div');
  footer.classList.add('modal-footer');
  button_ann.addEventListener('click', function () {
    // Codice per rimuovere il mock-up qui
    $(modal).modal('hide');


  });

  button_conferma.addEventListener('click', function () {

    $(modal).modal('hide');
    window.location.replace('categoriemenu.html');

  });


  // Appendi gli elementi l'uno all'altro
  modal.appendChild(dialog);
  dialog.appendChild(content);
  content.appendChild(header);
  header.appendChild(title);
  content.appendChild(body);
  body.appendChild(text);
  content.appendChild(footer);
  footer.appendChild(button_ann);
  footer.appendChild(button_conferma);

  document.body.appendChild(modal);
  $(modal).modal('show');

}
function inserimento_categoria(arr, index){
  if (index >= arr.length) {
   
    return;
  }
  if(arr[index]=='None'){
    inserimento_categoria(arr, index+1);
    return;
  }
  const categoriesList = document.getElementById("categories-list");
  const newOption = document.createElement("option");
  newOption.value = arr[index];
  newOption.text = arr[index];
  categoriesList.appendChild(newOption);
  inserimento_categoria(arr, index+1);
}
function inserimento_piatto(arr, index){
  if (index >= arr.length) {
    
    return;
  }
  if(arr[index]=='None'){
    inserimento_categoria(arr, index+1);
    return;
  }
 
  const dropdown = document.getElementById("dropdown");
  const option = document.createElement("div");
  option.innerHTML = `
  <input type="checkbox" id="option${arr[index]}" value="${arr[index]}">
  <label for="option${arr[index]}">${arr[index]}</label>
`;
  dropdown.appendChild(option);
  inserimento_piatto(arr, index+1);
}

const searchbar = document.getElementById("searchbar");
searchbar.addEventListener("input", function() {
const filter = searchbar.value.toUpperCase();
const options = dropdown.getElementsByTagName("div");
for (let i = 0; i < options.length; i++) {
  let option = options[i];
  if (option.textContent.toUpperCase().indexOf(filter) > -1) {
    option.style.display = "block";
  } else {
    option.style.display = "none";
  }
}
});
setTimeout(function () {
  //il bottone della lista categorie,se nessuna viene selezionata,rimane col
  //contenuto 'Categoria di appartenenza'
  //lista categorie
  $.ajax({
    url: 'http://87.3.142.174:8085/getCategorie',
    type: 'GET',
    dataType: 'json',
    success:function(data) {
     
     for (let i = 0; i < data.length; i++) {
      //inserimento_lista_Categorie(data[i]);
     
    }
  
    elementi=data;
    let currentIndex = 0;
    
    inserimento_categoria(elementi,currentIndex);
   
    //inserimento_categoria(elementi, currentIndex);}
    $.ajax({
      url:  'http://87.3.142.174:8085/elementi_senza_categoria',
      type: 'GET',
      dataType: 'json',
      success:function(piatti) {
       for (let i = 0; i < piatti.length; i++) {
        //inserimento_lista_Categorie(data[i]);
        
      }
      elementi_menu=piatti;
      
      let currentIndex = 0;
     
      inserimento_piatto(elementi_menu, currentIndex);
    
    }})
    

  }})

//FINE LISTA CATEGORIE
},300);
window.onbeforeunload = function(event) {
  event.preventDefault();
};