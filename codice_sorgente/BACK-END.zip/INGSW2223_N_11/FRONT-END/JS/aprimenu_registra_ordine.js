const button = document.getElementById("add");
const popup = document.getElementById("popup_menu");
const close = document.getElementById("closemenu");

idContatore = 0;
lastId = 0;
var piattiSelezionati = new Array();
var lista = document.getElementById("lista");

button.addEventListener("click", () => {
  //popup.style.display = "block";
  //button.style.pointerEvents = "none";
  rimuoviTuttiGliElementi();
  $('#modal-menu').modal('show');
});

close.addEventListener("click", () => {
  popup.style.display = "none";
  button.style.pointerEvents = "auto";
  const popupinputnonvuoto = document.getElementById("risultatoricercamenu");
  popupinputnonvuoto.style.display = "none";
});


//window.addEventListener("load", caricaMenu);


function caricaMenu() {
  let request = new XMLHttpRequest();

  var arrayListJSON = JSON.stringify(piattiSelezionati);
  request.open("POST", "http://87.3.142.174:8085/elementimenuselezionabili");
  request.setRequestHeader("Content-Type", "application/json");
  request.send(arrayListJSON);
  request.onload = function () {
    // Controlla che la richiesta sia stata completata con successo
    // Ottieni il riferimento al contenitore
    //nomelemento,descrizione,costo,allergeni
    if (request.status === 200) {
      var prodotti = JSON.parse(request.responseText);

      var contenitore = document.getElementById("listaelementimenu");
      contenitore.innerHTML = "";
      for (var oggetto of prodotti) {

        
        var div = document.createElement("div");
        //cambiare codice_a_barre con un identificativo per i piatti
        div.id = "elemento" + oggetto.nome;
        div.style.marginTop = "30px";
        div.style.marginLeft = "50px";

        var table = document.createElement("table");
        table.setAttribute("style", "border-collapse: collapse; width: 100%; height: 100px; border=0;");

        var tbody = document.createElement("tbody");
        table.appendChild(tbody);

        // Crea la prima riga
        var tr1 = document.createElement("tr");
        tr1.setAttribute("style", "height: 88px;");
        tbody.appendChild(tr1);

        // Crea la prima cella della prima riga
        var td1 = document.createElement("td");
        td1.setAttribute("style", "width: 33.5203%; height: 88px; text-align: left;");
        td1.innerHTML = "<p>" + "<b style='font-size:20px'>" + oggetto.nome.toUpperCase() + "</b>" + "</p>" +
          "<p>" + "<b style='font-size: 20px;'>Descrizione</b>" + "</p>" +
          "<p>" + "<i style='font-size: 20px;'>" + oggetto.descrizione + "</i>" + "<br>" + "<b>Prezzo: " + oggetto.costo + "€</b>" + "</p>";
        tr1.appendChild(td1);

        // Crea la seconda cella della prima riga
        var td2 = document.createElement("td");
        td2.setAttribute("style", "width: 33.0996%; height: 88px;");

        var button = document.createElement("button");
        button.setAttribute("type", "button");
        button.setAttribute("class", "btn btn-outline-primary btn-lg");
        button.setAttribute("style", "margin-top:30px");

        button.innerHTML = "<b>SELEZIONA</b>";
        button.id = "button" + idContatore;



        td2.appendChild(button);

        tr1.appendChild(td2);


        
        lista.appendChild(table);
        //contenitore.appendChild(table)

        
        button.addEventListener("click", function (event) {
          //aggiungiOrdine(td1.innerHTML.split('Descrizione')[0], 1, 1);
          var bottoneCliccato = event.target;
          var tabellaMadre = bottoneCliccato.closest("table");
          var td1Corrispondente = tabellaMadre.querySelector("td");
          var costo = parseInt(td1Corrispondente.innerHTML.split("Prezzo: ")[1]);


          var stringa = td1Corrispondente.innerHTML.split('Descrizione')[0];
          var array = stringa.split("<b");
          var nome = (array[1].split(">")[1].split("<")[0].trim());
         
          aggiungiOrdine(nome, costo, 1);
          
          piattiSelezionati.push(nome.toLowerCase());
          
          rimuoviTuttiGliElementi();
          //aggiornaMenu(piattiSelezionati);
          
        })
        

        idContatore = idContatore + 6;
      }
    } else {
      var contenitore = document.getElementById("listaelementimenu");
      // Mostra un messaggio di errore
      var div = document.createElement("div");
      //div.className = "prodottodispensa";
      div.innerHTML =
        "<b>Perfavore ricarica la pagina, Errore nel caricamento della dispensa!</b>";
      contenitore.appendChild(div);
    }
  };
}



function rimuoviTuttiGliElementi() {
  var lista = document.getElementById("lista");
  while (lista.firstChild) {
      lista.removeChild(lista.firstChild);
  }

  caricaMenu();
}