const buttonconfermapiu = document.getElementById("confermapiu");

function piuProdotto(element) {
  const elementId = element.id;
  var strid = `${elementId}`;
  strid = strid.replace("bottonepiu", "");
  const popup = document.getElementById("popup_piu_prodotto");
  popup.style.display = "block";
  const close = document.getElementById("closepiu");
  close.addEventListener("click", () => {
    popup.style.display = "none";
  });
  buttonconfermapiu.dataset.strid = strid;
}

buttonconfermapiu.addEventListener("click", () => {
  var strid = buttonconfermapiu.dataset.strid;
  clickAumenta(strid);
  
});

function clickAumenta(strid) {
  var quantita = document.getElementById("quantitapiu").value;
  if (quantita=="" || quantita<0 ){
    const popupinputvuoto = document.getElementById("inputVuotopiu");///////////////////////
        popupinputvuoto.style.display="block";
        setTimeout(function(){
            popupinputvuoto.style.display="none";
          }, 3000);
  }else{
    var data = { id: strid, value: quantita };
    let request = new XMLHttpRequest();
    request.open("PUT", "http://87.3.142.174:8085/aggiungi");
    request.setRequestHeader("Content-Type", "application/json");
    request.onload = () => console.log(request.responseText);
    request.send(JSON.stringify(data));
    var disponibilita = document.getElementById("disponibilita" + strid);
    disponibilita.innerHTML = disponibilita.innerHTML.replace(
      "disponibilita: ",
      ""
    );
    var nuovaquantità = Number.parseFloat(disponibilita.innerHTML);
    nuovaquantità = nuovaquantità + Number.parseFloat(quantita);
    disponibilita.innerHTML = "disponibilita: " + nuovaquantità;
    const popup = document.getElementById("popup_piu_prodotto");
    popup.style.display = "none";
    const popupmessaggioconferma = document.getElementById("messaggioconferma");
    popupmessaggioconferma.style.display = "block";
    setTimeout(function(){
      popupmessaggioconferma.style.display="none";
    }, 3000);
    var quantita = document.getElementById("quantitapiu");
    quantita.value="";
  }

}
