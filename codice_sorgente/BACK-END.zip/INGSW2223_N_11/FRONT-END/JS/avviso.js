window.onload = function loadPage() {

    let urlParams = new URLSearchParams(window.location.search);
    let valore1 = urlParams.get("val");
    var myEmail = getCookie("email");
    myEmail = myEmail.substring(1, myEmail.length - 1);
    var nascosto = "";
    var visualizzato = "";


    let request = new XMLHttpRequest();
    request.open("GET", "http://87.3.142.174:8085/admin/service/openMessage/" + valore1 + "/" + myEmail);
    request.send();
    request.onload = () => {

        if (request.status == 200) {
            var json = JSON.parse(request.responseText);

            let oggettoHTML = document.getElementById("oggetto");
            let testoHTML = document.getElementById("testo");
            let mittenteHTML = document.getElementById("ruolo");
            let dataHTML = document.getElementById("data");
            let visualizzatoHTML = document.getElementById("flexSwitchCheckDefault");
            let nascostoHTML = document.getElementById("flexSwitchCheckDefault2");

            var testoModal = document.getElementById('text-modal');
            var avantiModal = document.getElementById('btn-conf');
            var annullaModal = document.getElementById('btn-ann');
            var annullaConClose = document.getElementById('close');

            oggettoHTML.innerHTML = json[0];
            testoHTML.innerHTML = json[1];
            mittenteHTML.innerHTML = json[2];
            // visualizzatoHTML.innerHTML = json[3];
            visualizzato = json[3];
            nascosto = json[4];
            dataHTML.innerHTML = json[5].substring(0, json[5].length - 12);

            
           

            if (visualizzato == "true") {
                visualizzatoHTML.disabled = true;
                nascostoHTML.disabled = false;
                visualizzatoHTML.checked = true;
            }

            if(visualizzato == "false") {
                nascostoHTML.disabled = true;
            }
            
            if (nascosto == "true") {
                nascostoHTML.checked = true;
            }

            if (nascosto == 'false') {
                nascostoHTML.checked = false;
                //nascostoHTML.disabled = true;
            }

            visualizzatoHTML.onclick = function mostraPopUpVisualizzazioneAvviso() {
              
                $('#staticBackdrop').modal();
                $('#staticBackdrop').modal('show');

                testoModal.innerHTML = "Vuoi segnare questo avviso come visualizzato?";
                avantiModal.innerHTML = "Conferma";

                annullaModal.onclick = function () {
                    visualizzatoHTML.checked = false;
                }

                annullaConClose.onclick = function () {
                    visualizzatoHTML.checked = false;
                }

                //FUNZIONE SET VISUALIZZATO;
                avantiModal.onclick = function setVisualizzato() {
                    let request = new XMLHttpRequest();
                    request.open("PUT", "http://87.3.142.174:8085/admin/service/visualizza/" + myEmail + "/" + valore1);
                    request.send();
                    request.onload = () => {

                        if (request.status == 200) {

                            if (request.responseText == "true") {
                                $('#staticBackdrop').modal('hide');
                                visualizzatoHTML.disabled = true;
                                nascostoHTML.disabled = false;
                                nascostoHTML.checked = false;
                            }
                        }
                        else
                            console.log("si è verificato un problema!");
                    }
                }
            }

            nascostoHTML.onclick = function nascondiAvviso () {
                $('#staticBackdrop').modal('show');

                //funzione per lo switch nascondi
                if (nascosto == "false") {
                    testoModal.innerHTML = "Vuoi spostare questo avviso nella casella degli avvisi nascosti?";
                    avantiModal.innerHTML = "Conferma";
                }
                else if (nascosto == "true") {
                    //cambia gli inner di titolo 
                    testoModal.innerHTML = "Vuoi rimuovere questo avviso nella casella degli avvisi nascosti?";
                    avantiModal.innerHTML = "Conferma";
                }

                //regola che ci permette di andare a settare gli switch come erano prima di cliccare su annulla o sulla X
                if (nascosto == 'true') {
                    annullaModal.onclick = function () {
                     
                        nascostoHTML.checked = true;
                    }
                } else if (nascosto == 'false')
                    annullaModal.onclick = function () {
                        nascostoHTML.checked = false;
                    }

                if (nascosto == 'true') {
                    annullaConClose.onclick = function () {
                        nascostoHTML.checked = true;
                        
                    }
                }
                else if (nascosto == 'false') {
                    annullaConClose.onclick = function () {
                        nascostoHTML.checked = false;
                    }
                }

                //FUNZIONE SET NASCOSTO ON E OFF

                
                avantiModal.onclick = function nascondi() {

                    if(nascosto =="true")
                    {
                       
                        nascostoHTML.checked = false;
                        nascosto ="false";
                    }else {
                        if(nascosto =="false"){
                        nascostoHTML.checked = true;
                        nascosto ="true";}
                    }

                    let request = new XMLHttpRequest();
                    request.open("PUT", "http://87.3.142.174:8085/message/service/nascondi/" + myEmail + "/" + valore1);
                    request.send();
                    request.onload = () => {

                        if (request.status == 200) {
                            if (request.responseText == "true") {

                                $('#staticBackdrop').modal('hide');

                            }

                        }
                    }

                }
            }
        }

    }
}
function getCookie(nomeCookie) {
    var name = nomeCookie + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }

}

document.getElementById("freccia-back").onclick = function () {
    location.href = 'casella-avvisi.html';
}


/*METODO PER L'HOVER DI TASTO HOME*/
const element = document.querySelector('#home');

element.addEventListener('mouseenter', () => {
    element.classList.add('hover');
    const image = document.querySelector('#home');
    image.src = './img/home-hovered.png';
})


element.addEventListener('mouseleave', () => {
    const image = document.querySelector('#home');
    image.src = './img/home-basic.png';
    element.classList.remove('hover');
})

element.onclick = function backHome() {
    location.href = "home-admin.html";
}


