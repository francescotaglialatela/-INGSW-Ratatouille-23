let elementi;
document.getElementById('home').onmouseover =  function () {  
  this.style.backgroundImage="url('./img/home-hovered.png')";}

document.getElementById('home').onmouseout =  function () {
  this.style.backgroundImage="url('./img/home-basic.png')";

}
document.getElementById('home').onclick =  function () {
  var ruolo=getCookie("ruolo");
  ruolo = ruolo.substring(1,ruolo.length -1);
  
  
    if(ruolo=="amministratore")
      window.location.replace("home-admin.html");
      if(ruolo=="supervisore")
      window.location.replace("home-supervisore.html");
      if(ruolo=="addetto cucina")
      window.location.replace("home-AddettoCucina.html");
      if(ruolo=="addetto sala")
      window.location.replace("home-AddettoSala.html");
  
  
}
document.getElementById('aggiungi').onmouseover =  function () {  
  this.style.backgroundColor = "rgba(57, 113, 255, 0.677)";}

document.getElementById('aggiungi').onmouseout =  function () {
 
  this.style.backgroundColor = "#3970ff";
}
const buttonindietro = document.getElementById("freccia-indietro");
buttonindietro.addEventListener("click", function() {
  window.location.replace('personalizzazione.html');
});
document.getElementById('aggiungi').onclick =  function () {
window.location.replace("aggiungicategoria.html");}
function elimina_categoria(modal,nome){
  const listaPrincipale = document.getElementById('ListaCategorie');
  const elementi = listaPrincipale.getElementsByTagName('li');
  for (let i = 0; i < elementi.length; i++) {
    
    const bottone = elementi[i].querySelector(".button_visualizza")
    if(bottone){
      const divs = bottone.parentNode;
      
      const figlio = divs.children[0];
     
      if(divs){
      for (let i = 0; i < divs.length; i++) {
       
        if (divs[i].textContent === nome) {
          
          divs[i].remove();
        }
      }
    }
    
    }
    
  }
  listaPrincipale.innerHTML='';
  
  let request = new XMLHttpRequest();
   
    request.open("POST","http://87.3.142.174:8085/eliminazione_macrocategoria/"+nome);
      request.send();
      request.onload = () =>  {
       
        if(request.status == 200)
        {
          
          array=[];
          result = request.responseText;   
          $.ajax({
            url: 'http://87.3.142.174:8085/getCategorie',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
             for (let i = 0; i < data.length; i++) {
             
          }
           elementi_nuovi=data;
      
      let currentIndex = 0;
      
      processArray(elementi_nuovi, currentIndex);

        
        }})
        $(modal).modal('hide');
          
        }
        
        }
    
}
function elimina_sottocategoria(modal,nome){
  const listaPrincipale = document.getElementById('ListaCategorie');
  const elementi = listaPrincipale.getElementsByTagName('li');
  for (let i = 0; i < elementi.length; i++) {
    
    const bottone = elementi[i].querySelector(".button_visualizza")
    if(bottone){
      const divs = bottone.parentNode;
      
      const figlio = divs.children[0];
      
      if(divs){
      for (let i = 0; i < divs.length; i++) {
        
        if (divs[i].textContent === nome) {
          
          divs[i].remove();
        }
      }
    }
    
    }
    
  }
  listaPrincipale.innerHTML='';
  
  let request = new XMLHttpRequest();
    
    request.open("POST","http://87.3.142.174:8085/eliminazione_sottocategoria/"+nome);
      request.send();
      request.onload = () =>  {
      
        if(request.status == 200)
        {
          array=[];
          result = request.responseText;   
          $.ajax({
            url: 'http://87.3.142.174:8085/getCategorie',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
             for (let i = 0; i < data.length; i++) {
             
          }
           elementi_nuovi=data;
      
      let currentIndex = 0;
      
      processArray(elementi_nuovi, currentIndex);

        
        }})
        $(modal).modal('hide');
          
        }
        
        }
    
}

function mostraPopupSottoCategoria(nome){
  const modal = document.createElement('div');
  modal.classList.add('modal', 'fade');
  modal.setAttribute('id', 'staticBackdrop');
  modal.setAttribute('data-bs-backdrop', 'static');
  modal.setAttribute('data-bs-keyboard', 'false');
  modal.setAttribute('tabindex', '-1');
  modal.setAttribute('aria-labelledby', 'staticBackdropLabel');
  modal.setAttribute('aria-hidden', 'true');
  
  const dialog = document.createElement('div');
  dialog.classList.add('modal-dialog', 'modal-dialog-centered');
  
  const content = document.createElement('div');
  content.classList.add('modal-content');
  content.setAttribute('style', 'border-radius: 41px;');
  
  const header = document.createElement('div');
  header.classList.add('modal-header');
  
  const title = document.createElement('h1');
  title.classList.add('modal-title', 'fs-5');
  title.setAttribute('id', 'staticBackdropLabel');
  title.innerHTML = 'Avviso';
  
  const body = document.createElement('div');
  body.classList.add('modal-body');
  
  const text = document.createElement('p');
  text.setAttribute('id', 'testo-pop-up');
  text.innerHTML = 'Sei sicuro di voler eliminare la sottocategoria '+nome+' ?';
  const button_ann = document.createElement('button');
  button_ann.type = 'button';
  button_ann.classList.add('btn', 'btnannulla');
  button_ann.setAttribute('style', 'border-radius: 61px;');
  button_ann.innerHTML = 'NO';
  const button_conferma = document.createElement('button');
  button_conferma.type = 'button';
  button_conferma.classList.add('btn', 'btnconferma');
  button_conferma.setAttribute('style', 'border-radius: 61px; color:white;');
  button_conferma.innerHTML = 'SI';
  button_ann.style.marginRight = '166px';
  
  const footer = document.createElement('div');
  footer.classList.add('modal-footer');
  button_ann.addEventListener('click', function() {
    // Codice per rimuovere il mock-up qui
    $(modal).modal('hide');
      
  
  });
  
  button_conferma.addEventListener('click', function(){
    button_ann.style.display = "none";
    button_conferma.style.display = "none";
    title.innerHTML = 'Aggiornamento';
    text.innerHTML = 'Aggiornamento in corso..';
    elimina_sottocategoria(modal,nome);
   
    
  });
  
  
  // Appendi gli elementi l'uno all'altro
  modal.appendChild(dialog);
  dialog.appendChild(content);
  content.appendChild(header);
  header.appendChild(title);
  content.appendChild(body);
  body.appendChild(text);
  content.appendChild(footer);
  footer.appendChild(button_ann);
  footer.appendChild(button_conferma);
  
  document.body.appendChild(modal);
  $(modal).modal('show');
  
  }
  function mostraPopupCategoriaconSottocategorie(nome){
    const modal = document.createElement('div');
    modal.classList.add('modal', 'fade');
    modal.setAttribute('id', 'staticBackdrop');
    modal.setAttribute('data-bs-backdrop', 'static');
    modal.setAttribute('data-bs-keyboard', 'false');
    modal.setAttribute('tabindex', '-1');
    modal.setAttribute('aria-labelledby', 'staticBackdropLabel');
    modal.setAttribute('aria-hidden', 'true');
    
    const dialog = document.createElement('div');
    dialog.classList.add('modal-dialog', 'modal-dialog-centered');
    
    const content = document.createElement('div');
    content.classList.add('modal-content');
    content.setAttribute('style', 'border-radius: 41px;');
    
    const header = document.createElement('div');
    header.classList.add('modal-header');
    
    const title = document.createElement('h1');
    title.classList.add('modal-title', 'fs-5');
    title.setAttribute('id', 'staticBackdropLabel');
    title.innerHTML = 'Avviso';
    
    const body = document.createElement('div');
    body.classList.add('modal-body');
    
    const text = document.createElement('p');
    text.setAttribute('id', 'testo-pop-up');
    text.innerHTML = 'Sei sicuro di voler eliminare la Categoria '+nome+' con le relative sottocategorie ?';
    const button_ann = document.createElement('button');
    button_ann.type = 'button';
    button_ann.classList.add('btn', 'btnannulla');
    button_ann.setAttribute('style', 'border-radius: 61px;');
    button_ann.innerHTML = 'NO';
    const button_conferma = document.createElement('button');
    button_conferma.type = 'button';
    button_conferma.classList.add('btn', 'btnconferma');
    button_conferma.setAttribute('style', 'border-radius: 61px;color:white');
    button_conferma.innerHTML = 'SI';
    button_ann.style.marginRight = '166px';
    
    const footer = document.createElement('div');
    footer.classList.add('modal-footer');
    button_ann.addEventListener('click', function() {
      // Codice per rimuovere il mock-up qui
      $(modal).modal('hide');
        
    
    });
    
    button_conferma.addEventListener('click', function(){
      button_ann.style.display = "none";
      button_conferma.style.display = "none";
      title.innerHTML = 'Aggiornamento';
      text.innerHTML = 'Aggiornamento in corso..';
      elimina_categoria(modal,nome);
     
      
    });
    
    
    // Appendi gli elementi l'uno all'altro
    modal.appendChild(dialog);
    dialog.appendChild(content);
    content.appendChild(header);
    header.appendChild(title);
    content.appendChild(body);
    body.appendChild(text);
    content.appendChild(footer);
    footer.appendChild(button_ann);
    footer.appendChild(button_conferma);
    
    document.body.appendChild(modal);
    $(modal).modal('show');
    
    }
    function mostraPopupCategoriasenzaSottocategorie(nome){
      const modal = document.createElement('div');
      modal.classList.add('modal', 'fade');
      modal.setAttribute('id', 'staticBackdrop');
      modal.setAttribute('data-bs-backdrop', 'static');
      modal.setAttribute('data-bs-keyboard', 'false');
      modal.setAttribute('tabindex', '-1');
      modal.setAttribute('aria-labelledby', 'staticBackdropLabel');
      modal.setAttribute('aria-hidden', 'true');
      
      const dialog = document.createElement('div');
      dialog.classList.add('modal-dialog', 'modal-dialog-centered');
      
      const content = document.createElement('div');
      content.classList.add('modal-content');
      content.setAttribute('style', 'border-radius: 41px;');
      
      const header = document.createElement('div');
      header.classList.add('modal-header');
      
      const title = document.createElement('h1');
      title.classList.add('modal-title', 'fs-5');
      title.setAttribute('id', 'staticBackdropLabel');
      title.innerHTML = 'Avviso';
      
      const body = document.createElement('div');
      body.classList.add('modal-body');
      
      const text = document.createElement('p');
      text.setAttribute('id', 'testo-pop-up');
      text.innerHTML = 'Sei sicuro di voler eliminare la Categoria '+nome+'?';
      const button_ann = document.createElement('button');
      button_ann.type = 'button';
      button_ann.classList.add('btn', 'btnannulla');
      button_ann.setAttribute('style', 'border-radius: 61px;');
      button_ann.innerHTML = 'NO';
      const button_conferma = document.createElement('button');
      button_conferma.type = 'button';
      button_conferma.classList.add('btn', 'btnconferma');
      button_conferma.setAttribute('style', 'border-radius: 61px;color:white');
      button_conferma.innerHTML = 'SI';
      button_ann.style.marginRight = '166px';
      
      const footer = document.createElement('div');
      footer.classList.add('modal-footer');
      button_ann.addEventListener('click', function() {
        // Codice per rimuovere il mock-up qui
        $(modal).modal('hide');
          
      
      });
      
      button_conferma.addEventListener('click', function(){
        button_ann.style.display = "none";
        button_conferma.style.display = "none";
        title.innerHTML = 'Aggiornamento';
        text.innerHTML = 'Aggiornamento in corso..';
        elimina_categoria(modal,nome);
       
        
      });
      
      
      // Appendi gli elementi l'uno all'altro
      modal.appendChild(dialog);
      dialog.appendChild(content);
      content.appendChild(header);
      header.appendChild(title);
      content.appendChild(body);
      body.appendChild(text);
      content.appendChild(footer);
      footer.appendChild(button_ann);
      footer.appendChild(button_conferma);
      
      document.body.appendChild(modal);
      $(modal).modal('show');
      
      }
function processArray(arr,index){
  if (index >= arr.length) {
    return;
  }
 
  if(arr[index]=='None'){
    
    processArray(arr,index+1);
    return;
  }

    const listaPrincipale = document.getElementById('ListaCategorie');

    let request = new XMLHttpRequest();
      request.open("GET","http://87.3.142.174:8085/numsottocategorie/"+arr[index]);
      request.send();
      request.onload = () =>  {
        if(request.status == 200)
          {
            
            result = request.responseText; 
            const intero = parseInt(result);
            
            if(intero!=0)
            { 
            
                const elemento_padre = document.createElement('li');
                elemento_padre.style.borderBottom = '2px solid black';
                elemento_padre.style.width = '430px';
                elemento_padre.style.position = "relative";
                const lista = document.createElement('ul');
                lista.style.setProperty('list-style-type', 'none');
                const bottone_bidone = document.createElement('button');
            bottone_bidone.className="button_cancellazione2";
            const bottone_contenuto=document.createElement('button');
            bottone_contenuto.className="button_contenuto";
            bottone_contenuto.textContent=arr[index];
            bottone_bidone.style.position = "absolute";
            bottone_bidone.style.right = "0";
            elemento_padre.appendChild(bottone_bidone);
            elemento_padre.appendChild(bottone_contenuto);
                
                $.ajax({
 
                  url: 'http://87.3.142.174:8085/getsottocategorie/'+arr[index],
                  type: 'GET',
                  dataType: 'json',
                  success: function(data) {
                   for (let i = 0; i < data.length; i++) {
                  
                   
                    listaPrincipale.appendChild(elemento_padre);
                   
                    
                    const elemento = document.createElement('li');
                    
                    const bottone = document.createElement('button');
                    const bottone_nome=document.createElement('button');
                    bottone_nome.className="button_contenuto";
                    bottone_nome.textContent="-"+data[i];
                    bottone.className="button_cancellazione";
                   
                    bottone.style.float = 'right';
                    bottone.addEventListener('mouseover', function(event) {
                      bottone_nome.style.border="2px solid rgb(70, 154, 227)"
                      bottone_nome.style.borderRadius = '30px';
                    });
                    let mouseoutHandler = function(event) {
                      bottone_nome.style.border = "none";
                    };
                    bottone.addEventListener('mouseout', mouseoutHandler);
                    bottone.addEventListener('click', function(event) {
                      bottone_nome.style.border="2px solid rgb(70, 154, 227)"
                      bottone_nome.style.borderRadius = '30px';
                      mostraPopupSottoCategoria(data[i]);
                  
                    });
                    bottone_bidone.addEventListener('mouseover', function(event) {
                      bottone_nome.style.border="2px solid rgb(70, 154, 227)"
                      bottone_nome.style.borderRadius = '30px';
                     
                      bottone_contenuto.style.border="2px solid rgb(70, 154, 227)"
                      bottone_contenuto.style.borderRadius = '30px';
                    });
                    let mouseoutHandler2 = function(event) {
                      bottone_contenuto.style.border = "none";
                      bottone_nome.style.border = "none";
                    };
                    
                    bottone_bidone.addEventListener('mouseout', mouseoutHandler2);
                    elemento.appendChild(bottone_nome);
                    elemento.appendChild(bottone);
                    lista.appendChild(elemento);
                    lista.style.marginBottom='29px';
                    listaPrincipale.appendChild(lista);

                }
                bottone_bidone.addEventListener('click', function(event) {
                  
                  mostraPopupCategoriaconSottocategorie( arr[index]);
              
                });
                processArray(arr,index+1);
              }
            }
            )
              
              
          }else{
            const elemento_padre = document.createElement('li');
            elemento_padre.style.borderBottom = '2px solid black';
            elemento_padre.style.width = '430px';
            elemento_padre.style.position = "relative";
            //elemento_padre.textContent=arr[index];  
            const bottone = document.createElement('button');
            bottone.className="button_cancellazione2";
            const bottone_nome=document.createElement('button');
            bottone_nome.className="button_contenuto";
            bottone_nome.textContent=arr[index];
            bottone.style.position = "absolute";
            bottone.style.right = "0";
            elemento_padre.appendChild(bottone);
            elemento_padre.appendChild(bottone_nome);
            listaPrincipale.appendChild(elemento_padre);
            bottone.addEventListener('mouseover', function(event) {
              bottone_nome.style.border="2px solid rgb(70, 154, 227)"
              bottone_nome.style.borderRadius = '30px';
            });
            let mouseoutHandler = function(event) {
              bottone_nome.style.border = "none";
            };
            bottone.addEventListener('mouseout', mouseoutHandler);
            bottone.addEventListener('click', function(event) {
              bottone_nome.style.border="2px solid rgb(70, 154, 227)"
              bottone_nome.style.borderRadius = '30px';
              mostraPopupCategoriasenzaSottocategorie( arr[index]);
            });
            processArray(arr,index+1);
          }
      }
        
    
    }
   


}

setTimeout(function() {
    $.ajax({
      url: 'http://87.3.142.174:8085/getCategorie',
      type: 'GET',
      dataType: 'json',
      success: function(data) {
       for (let i = 0; i < data.length; i++) {
        
       
       
    }
    elementi=data;
    let currentIndex = 0;
    
    processArray(elementi, currentIndex);
  }})
  },2000);
  window.onbeforeunload = function(event) {
    event.preventDefault();
  };
  function getCookie(nomeCookie) {
    var name = nomeCookie + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }