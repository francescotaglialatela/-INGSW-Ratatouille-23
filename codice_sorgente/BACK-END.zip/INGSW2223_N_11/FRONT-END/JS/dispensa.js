let request = new XMLHttpRequest();
request.open("GET","http://87.3.142.174:8085/dispensa");
request.send();

request.onload = function() {
    // Controlla che la richiesta sia stata completata con successo
        // Ottieni il riferimento al contenitore
    
    if (request.status === 200) {
      var i=0;
      var prodotti=JSON.parse(request.responseText);
      var contenitore = document.getElementById('listadispensa');
      for (var oggetto of prodotti) {
        var div = document.createElement('div');
        div.id=('elemento'+oggetto.codice_a_barre)
       
        if(oggetto.urlfoto=="")
        oggetto.urlfoto='./img/Image_not_available.png'
        div.innerHTML='<table style="border-collapse: collapse; width: 100%; height: 100px; margin-top:26px" border="0"><tbody><tr style="height: 150px;"><td style="width: 16.5498%;"><img src="./img/bidone.jpg" style="width:30px;height:30px;" class="imgbutton" id="bottoneelimina'+oggetto.codice_a_barre+'" onclick="eliminaProdotto(this)"></td><td style="width: 16.5498%; height: 150px;"><img src="'+oggetto.urlfoto+'" style="width:150px;height:150px;margin:20px"></td><td style="width: 33.5203%; height: 88px; text-align: left;"><p><strong style="font-size: 24px;">'+oggetto.nome+'</strong></p><p><strong style="font-size: 20px;">Descrizione</strong></p><p><em style="font-size: 20px;">'+oggetto.descrizione+'</em></p><p><em style="font-size: 20px;">prezzo unitario: '+oggetto.prezzo+'</em></p><p><em style="font-size: 20px;" id="disponibilita'+oggetto.codice_a_barre+'">disponibilita: '+oggetto.quantita+'</em></p><p><b>Unita di misura: </b>'+oggetto.unita+'</p></td><td style="width: 33.0996%; height: 88px;"><ul style="list-style-type: none;"><li style="margin-bottom: 25px;margin-top: 50px"><button type="button" class="btn btn-outline-primary btn-lg"style="border-radius:50%;height: 49px;width: 49px;" id="bottonepiu'+oggetto.codice_a_barre+'" onclick="piuProdotto(this)"><b>+</b></button></li><li><button type="button" class="btn btn-outline-primary btn-lg" style="border-radius:50%; height: 49px;width: 49px;" id="bottonemeno'+oggetto.codice_a_barre+'" onclick="menoProdotto(this)"><b>-</b></button></li></ul></td></tr></tbody></table>'
        contenitore.appendChild(div);
        i++;
    }
    } else {
        var contenitore = document.getElementById('listadispensa');
            // Mostra un messaggio di errore
            var div = document.createElement('div');
            div.className = 'prodottodispensa';
            div.innerHTML="<b>Perfavore ricarica la pagina, Errore nel caricamento della dispensa!</b>";
           contenitore.appendChild(div);
    }
  };
  document.getElementById("back").onclick = function() {
    var ruolo=getCookie("ruolo");
    ruolo = ruolo.substring(1,ruolo.length -1);
    
        if(ruolo=="supervisore")
        window.location.replace("home-supervisore.html");
        if(ruolo=="addetto cucina")
        window.location.replace("home-AddettoCucina.html");
  }
  function getCookie(nomeCookie) {
    var name = nomeCookie + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }
  document.getElementById("ricercadispensa").addEventListener("input", filterChildrenDispensa);

  function filterChildrenDispensa() {
    var input, filter, contenitore, child;
    input = document.getElementById("ricercadispensa");
    filter = input.value.toUpperCase();
    contenitore = document.getElementById("listadispensa");
    child = contenitore.children;
    for (var i = 0; i < child.length; i++) {
      var txtValue = child[i].textContent || child[i].innerText;
      let pos = txtValue.indexOf("Descrizione");
      txtValue = txtValue.substring(0, pos);
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        child[i].style.display = "";
      } else {
        child[i].style.display = "none";
      }
    }
  }