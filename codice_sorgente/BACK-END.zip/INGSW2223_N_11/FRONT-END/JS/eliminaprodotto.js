function eliminaProdotto(element) {
    const elementId = element.id;
    var strid = `${elementId}`;
    strid = strid.replace("bottoneelimina", "");
    const popup = document.getElementById("popup_elimina_prodotto");
    popup.style.display = "block";
    button.style.pointerEvents = "none";
    const close = document.getElementById("closeelimina");
    close.onclick = () => {
        popup.style.display = "none";
        button.style.pointerEvents = "auto";
    };
    const buttonconfermaelimina = document.getElementById("confermaelimina");
    buttonconfermaelimina.onclick = () => {
        const data = { id: strid };
        let request = new XMLHttpRequest();
        request.open("DELETE", "http://87.3.142.174:8085/eliminaprodotto");
        request.setRequestHeader("Content-Type", "application/json");
        request.onload = function () {
            if (request.status === 200) {
                
            } else {
                console.log("Error: " + request.status);
            }
        };
        request.send(JSON.stringify(data));
        var divdaeliminare=document.getElementById("elemento"+strid);
        divdaeliminare.remove();
        const popup = document.getElementById("popup_elimina_prodotto");
        popup.style.display = "none";
        button.style.pointerEvents = "auto";
        const popupmessaggioconferma = document.getElementById("messaggioconferma");
        popupmessaggioconferma.style.display = "block";
        setTimeout(function () {
          popupmessaggioconferma.style.display = "none";
        }, 750);
        
    };
}

