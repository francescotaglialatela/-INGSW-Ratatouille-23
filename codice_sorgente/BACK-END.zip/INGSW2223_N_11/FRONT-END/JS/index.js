var accettazione=getCookie("permessi");
let modal2=document.getElementById("scrollModal");

    if(accettazione.substring(1,accettazione.length-1)==""){
    modal2.classList.add("show");
    modal2.classList.add("d-block");
    document.getElementById("sig-in").disabled = true;
}else{
    document.getElementById("sig-in").disabled = false;
    var email=getCookie("email");
    var ruolo=getCookie("ruolo");
    ruolo = ruolo.substring(1,ruolo.length -1);
   
    if(email.substring(1,email.length-1)!=""){
      if(ruolo=="amministratore")
      window.location.replace("home-admin.html");
        if(ruolo=="supervisore")
        window.location.replace("home-supervisore.html");
        if(ruolo=="addetto cucina")
        window.location.replace("home-AddettoCucina.html");
        if(ruolo=="addetto sala")
        window.location.replace("home-AddettoSala.html");
    }
}
    document.getElementById("annulla").onclick = function() {
        // il codice da eseguire al click del bottone annulla
        modal2.classList.remove("show");
        modal2.classList.remove("d-block");
    };
    document.getElementById("accetta").onclick = function() {
        // il codice da eseguire al click del bottone accetta
        modal2.classList.remove("show");
        modal2.classList.remove("d-block");
        var accept="SI";
        
        var date = new Date();
        var minutes = 60*24*365; // 1 hour
        date.setTime(date.getTime() + (minutes * 60 * 1000));
        document.cookie = "permessi=\""+accept+"\"; expires=" + date.toUTCString();
        var accettazione=getCookie("permessi");
       
        var accettazione2=getCookie("permessi2");
        if(accettazione2.substring(1,accettazione2.length-1)=="")
       
        document.getElementById("sig-in").disabled = false;
        
    };
    document.getElementById("sig-in").onclick = function() {
      window.location.replace("login.html");
        
    };
    function getCookie(nomeCookie) {
        var name = nomeCookie + "=";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for(var i = 0; i <ca.length; i++) {
          var c = ca[i];
          while (c.charAt(0) == ' ') {
            c = c.substring(1);
          }
          if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
          }
        }
        return "";
      }
      window.onbeforeunload = function(event) {
        event.preventDefault();
      };