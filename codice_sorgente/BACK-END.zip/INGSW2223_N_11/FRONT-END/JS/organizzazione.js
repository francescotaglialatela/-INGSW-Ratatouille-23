document.getElementById('home').onmouseover =  function () {
       
    this.setAttribute("src", "./img/home-hovered.png")
}
document.getElementById('home').onmouseout =  function () {
  this.setAttribute("src", "./img/home-basic.png")
}
document.getElementById('button_conferma').addEventListener('mouseover', function() {
  if (this.disabled) return;
  this.style.fontWeight = 'bold';

});
function mostraPopupAnnulla(){
  const modal = document.createElement('div');
  modal.classList.add('modal', 'fade');
  modal.setAttribute('id', 'staticBackdrop');
  modal.setAttribute('data-bs-backdrop', 'static');
  modal.setAttribute('data-bs-keyboard', 'false');
  modal.setAttribute('tabindex', '-1');
  modal.setAttribute('aria-labelledby', 'staticBackdropLabel');
  modal.setAttribute('aria-hidden', 'true');
  
  const dialog = document.createElement('div');
  dialog.classList.add('modal-dialog', 'modal-dialog-centered');
  
  const content = document.createElement('div');
  content.classList.add('modal-content');
  content.setAttribute('style', 'border-radius: 41px;');
  
  const header = document.createElement('div');
  header.classList.add('modal-header');
  
  const title = document.createElement('h1');
  title.classList.add('modal-title', 'fs-5');
  title.setAttribute('id', 'staticBackdropLabel');
  title.innerHTML = 'Avviso';
  
  const body = document.createElement('div');
  body.classList.add('modal-body');
  
  const text = document.createElement('p');
  text.setAttribute('id', 'testo-pop-up');
  text.innerHTML = 'Le modifiche correnti verranno annullate.Sei sicuro di voler annullare l operazione?';
  const button_ann = document.createElement('button');
  button_ann.type = 'button';
  button_ann.classList.add('btn', 'btnannullaPopUp');
  button_ann.setAttribute('style', 'border-radius: 61px;');
  button_ann.innerHTML = 'NO';
  const button_conferma = document.createElement('button');
  button_conferma.type = 'button';
  button_conferma.classList.add('btn', 'btnconfermaPopUp');
  button_conferma.setAttribute('style', 'border-radius: 61px;');
  button_conferma.innerHTML = 'SI';
  button_ann.style.marginRight = '166px';
  
  const footer = document.createElement('div');
  footer.classList.add('modal-footer');
  button_ann.addEventListener('click', function() {
    // Codice per rimuovere il mock-up qui
    $(modal).modal('hide');
      
  
  });
  
  button_conferma.addEventListener('click', function(){
    //aggiunge che ritona alla home html
    window.location.assign("personalizzazione.html");
    
  });
  
  
  // Appendi gli elementi l'uno all'altro
  modal.appendChild(dialog);
  dialog.appendChild(content);
  content.appendChild(header);
  header.appendChild(title);
  content.appendChild(body);
  body.appendChild(text);
  content.appendChild(footer);
  footer.appendChild(button_ann);
  footer.appendChild(button_conferma);
  
  document.body.appendChild(modal);
  $(modal).modal('show');
  
  }
  function mostraPopupHome(){
    const modal = document.createElement('div');
    modal.classList.add('modal', 'fade');
    modal.setAttribute('id', 'staticBackdrop');
    modal.setAttribute('data-bs-backdrop', 'static');
    modal.setAttribute('data-bs-keyboard', 'false');
    modal.setAttribute('tabindex', '-1');
    modal.setAttribute('aria-labelledby', 'staticBackdropLabel');
    modal.setAttribute('aria-hidden', 'true');
    
    const dialog = document.createElement('div');
    dialog.classList.add('modal-dialog', 'modal-dialog-centered');
    
    const content = document.createElement('div');
    content.classList.add('modal-content');
    content.setAttribute('style', 'border-radius: 41px;');
    
    const header = document.createElement('div');
    header.classList.add('modal-header');
    
    const title = document.createElement('h1');
    title.classList.add('modal-title', 'fs-5');
    title.setAttribute('id', 'staticBackdropLabel');
    title.innerHTML = 'Avviso';
    
    const body = document.createElement('div');
    body.classList.add('modal-body');
    
    const text = document.createElement('p');
    text.setAttribute('id', 'testo-pop-up');
    text.innerHTML = 'Le modifiche correnti verranno annullate.Sei sicuro di voler tornare alla Home?';
    const button_ann = document.createElement('button');
    button_ann.type = 'button';
    button_ann.classList.add('btn', 'btnannullaPopUp');
    button_ann.setAttribute('style', 'border-radius: 61px;');
    button_ann.innerHTML = 'NO';
    const button_conferma = document.createElement('button');
    button_conferma.type = 'button';
    button_conferma.classList.add('btn', 'btnconfermaPopUp');
    button_conferma.setAttribute('style', 'border-radius: 61px;');
    button_conferma.innerHTML = 'SI';
    button_ann.style.marginRight = '166px';
    
    const footer = document.createElement('div');
    footer.classList.add('modal-footer');
    button_ann.addEventListener('click', function() {
      // Codice per rimuovere il mock-up qui
      $(modal).modal('hide');
        
    
    });
    
    button_conferma.addEventListener('click', function(){
      //aggiunge che ritona alla home html
      // a seconda dell utente deve tornare alla home

      var ruolo=getCookie("ruolo");
      ruolo = ruolo.substring(1,ruolo.length -1);
      
      
        if(ruolo=="amministratore")
        window.location.replace("home-admin.html");
          if(ruolo=="supervisore")
          window.location.replace("home-supervisore.html");
      
      
    });
    
    
    // Appendi gli elementi l'uno all'altro
    modal.appendChild(dialog);
    dialog.appendChild(content);
    content.appendChild(header);
    header.appendChild(title);
    content.appendChild(body);
    body.appendChild(text);
    content.appendChild(footer);
    footer.appendChild(button_ann);
    footer.appendChild(button_conferma);
    
    document.body.appendChild(modal);
    $(modal).modal('show');
    
    }
    document.getElementById('home').onclick =  function () {
      mostraPopupHome();
    }
document.getElementById('freccia-indietro').addEventListener('click', function() {
  mostraPopupAnnulla();

});
document.getElementById('annullamento').addEventListener('click', function() {
  mostraPopupAnnulla();

});
document.getElementById('button_conferma').addEventListener('click', function() {
  if (this.disabled) return;
  
  $.ajax({
    url: 'http://87.3.142.174:8085/getCategorie',
    type: 'GET',
    dataType: 'json',
    success: function(data) {
     for (let i = 0; i < data.length; i++) {
      if(data[i]!='None'){
      
      const listElements = document.querySelectorAll('#ListaCategorieSelezionate li');
      
      var j=0;
      listElements.forEach(function(li) {
        j++;
      let request = new XMLHttpRequest();
      var stringaDb=data[i];
      var stringa_app=li.innerText;
      if(stringa_app.includes('Ordina Sottocategorie')){
        stringa_app=stringa_app.replace('Ordina Sottocategorie','');}
        stringa_app=stringa_app.replace(/\s/g, '');
        stringaDb=stringaDb.replace(/\s/g, '');
        
        if(stringaDb ===  stringa_app){
         
      request.open("POST","http://87.3.142.174:8085/settaggiocategorie/"+data[i]+"/"+j);
      request.send();
      request.onload = () =>  {
       
        if(request.status == 200)
        {
         
          result = request.responseText;   
        }
        
        }

      }
      });
    }
  }
  window.location.replace("personalizzazione.html");
}});});

function premi_ordina(nomeCategoria) {
  //var valore = "qualcosa";
  //var link = 'sottocategorie.html?nomeCategoria=' + nomeCategoria;
  //window.location.href = link;
  window.open("sottocategorie.html?nomeCategoria=" + nomeCategoria,"_blank");
}
function premi(nome) {
const listElements = document.querySelectorAll('#ListaCategorieSelezionate li');
listElements.forEach(function(li) {
  const list = document.getElementById('ListaCategorieSelezionate');
  // Fai qualcosa con ogni elemento li della lista
  var nomeCateg=nome;
  var stringaprincipale=li.innerText;
  var stringa_modificata; 
  var stringa;
  if(stringaprincipale.includes('Ordina Sottocategorie')){
  var stringa=stringaprincipale.replace('Ordina Sottocategorie','');
  stringa_modificata=stringa.replace(/\s/g, '');
  nomeCateg=nomeCateg.replace(/\s/g, '');
 
  if(stringa_modificata === nomeCateg){
    
    list.removeChild(li);
    inseriment_lista_sx(nome);
  }
  //stringa=stringa.replace("","");
}else{
  stringa=stringaprincipale.replace(/\s/g, '');
  nomeCateg=nomeCateg.replace(/\s/g, '');
 
  if(stringa === nomeCateg){
    
    list.removeChild(li);
    inseriment_lista_sx(nome);
  }
}
  
});

}

// Rimuovi l'elemento dalla lista
//list.removeChild(elementToRemove);
//inseriment_lista_sx(nome);
//}
document.getElementById('button_conferma').addEventListener('mouseout', function() {
  if (this.disabled) return;
  this.style.fontWeight = 'normal';
});
document.getElementById('button_conferma').addEventListener('mouseout', function() {
  if (this.disabled) return;
  this.style.fontWeight = 'normal';
});
function showButton(button) {
  button.style.display = 'inline';
}
function premirimuovi(nome) {
}
function inseriment_lista_sx(nome){
  const list = document.getElementById('ListaCategorie');
  const button = document.createElement('button');
    button.textContent = nome;
    button.setAttribute('style', 'height: 50px; width:100px; color:rgb(70, 154, 227) ; background-color: white; border:2px solid rgb(70, 154, 227); border-radius: 30px;  margin: 10px; margin-left:25px; font-size: 16px; display: block;');
    button.addEventListener('click', function() {
      this.setAttribute('style', 'display: none;');
      const targetList = document.getElementById('ListaCategorieSelezionate');
      const emptyListItem = targetList.querySelector('li:empty');
      //content=this.textContent; 
      const content=nome;
      
      emptyListItem.innerHTML = `
      ${content}
        <button onclick="premi('${content}')" id="bottonerimuovi"></button>
        
        
      `;
      let request = new XMLHttpRequest();
      request.open("GET","http://87.3.142.174:8085/numsottocategorie/"+this.textContent);
      request.send();
      request.onload = () =>  {
        if(request.status == 200)
          {
            
            result = request.responseText; 
            const intero = parseInt(result);
            if(intero!=0&&intero!=1)
            { 
              emptyListItem.innerHTML = `
              ${content}
              <button  onclick="premi('${content}')" id="bottonerimuovi" style="margin-right:30px"></button>
              <button onclick="premi_ordina('${content}')" id="btn-sottocategorie" style="margin-left:70px" >Ordina Sottocategorie  <img src="./img/freccia-dx-blu.png" alt="Immagine" style="height:15px; width:20px;"></button>
            `;
              
          }
      }
  
    }
    });
    button.addEventListener('mouseover', function() {
      button.style.borderWidth = "4px";


    });
    button.addEventListener('mouseout', function() {
      button.style.borderWidth = "2px";


    });
      const targetList = document.getElementById('ListaCategorieSelezionate');
      const listItem = document.createElement('li');
      listItem.setAttribute('style', 'height:30px; width:400px; color:rgb(70, 154, 227) ; background-color: white; border-bottom:1px solid rgb(70, 154, 227);margin-top:10px;margin-left:250px;font-size: 16px; display: block;');
    
      
      targetList.appendChild(listItem);
      
      list.appendChild(button);
}

function abilitazione_conferma() {
const targetList = document.getElementById('ListaCategorieSelezionate');
const listItems = targetList.querySelectorAll('li');
const hasEmptyText = [...listItems].some(item => item.textContent === '');
const targetButton = document.getElementById('button_conferma');

if (hasEmptyText) {
  targetButton.disabled = true;
  targetButton.style.color = 'gray';
  targetButton.style.borderColor = 'gray'
} else {
  targetButton.disabled = false;
  targetButton.style.borderColor = 'rgb(70, 154, 227)';
  targetButton.style.color='rgb(70, 154, 227)';
 
  

}}
setInterval(abilitazione_conferma,1000);
setTimeout(function() {
$.ajax({
  url: 'http://87.3.142.174:8085/getCategorie',
  type: 'GET',
  dataType: 'json',
  success: function(data) {
   for (let i = 0; i < data.length; i++) {
    if(data[i]!='None')
    inseriment_lista_sx(data[i]);
   
}}})},2000);
window.onbeforeunload = function(event) {
  event.preventDefault();
};
function getCookie(nomeCookie) {
  var name = nomeCookie + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(';');
  for(var i = 0; i <ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}
