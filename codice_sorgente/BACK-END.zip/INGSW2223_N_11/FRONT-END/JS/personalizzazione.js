

const buttonorganizzazione = document.querySelector(".btnorganizzazione");
buttonorganizzazione.addEventListener("click", function() {
  window.location.replace('categoriemenu.html');
});
const buttondefinizione = document.querySelector(".btndefinizione");
buttondefinizione.addEventListener("click", function() {
  window.location.replace('organizzazionemenu.html');
});
const buttonaggiunta = document.querySelector(".btnaggiunta");
buttonaggiunta.addEventListener("click", function() {
  window.location.replace('aggiungipiatto.html');
});
const buttonrimozione = document.querySelector(".btnrimuovi");
buttonrimozione.addEventListener("click", function() {
  window.location.replace('rimozione_piatto.html');
});
const buttondefinizionepiatti = document.getElementById("btn-def");
buttondefinizionepiatti.addEventListener("click", function() {
  window.location.replace('definizione_piatti.html');
});
const buttonindietro = document.getElementById("indietro");
buttonindietro.addEventListener("click", function() {
  var ruolo=getCookie("ruolo");
  ruolo = ruolo.substring(1,ruolo.length -1);
  if(ruolo=="amministratore")
  window.location.replace('home-admin.html');
  if(ruolo=="supervisore")
  window.location.replace("home-supervisore.html");
});
window.addEventListener('popstate', function(event) {
  event.preventDefault();
});
function getCookie(nomeCookie) {
  var name = nomeCookie + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(';');
  for(var i = 0; i <ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}