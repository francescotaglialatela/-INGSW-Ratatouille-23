function selezionaElementoMenu(element) {
  const elementId = element.id;
  var strid = `${elementId}`;
  strid = strid.replace("seleziona", "");
  
  const popup = document.getElementById("popup_menu");
  popup.style.display = "none";
  button.style.pointerEvents = "auto";
  const data = { ricerca: strid };
 
  var request = new XMLHttpRequest();
  request.open("POST", "http://87.3.142.174:8085/elementomenubyname", true); //cambiare per associa
  request.setRequestHeader("Content-Type", "application/json");
  request.onreadystatechange = function () {
    if (request.readyState === 4 && request.status === 200) {
      var prodotti = JSON.parse(request.responseText);
      var div = document.getElementById("divelementodaassociare");
      div.innerHTML =
        '<div class="elementoselezionato" id="elementoselezionato"><div class="listaprodotti" style="text-align:left"><p style="margin-top:50px"><b id="nomeelementomenu" style="font-size:25px">' +
        prodotti.nome +
        '</b></p><br><p><b style="font-size:20px">Descrizione</b></p><br><p><i style="font-size:20px">' +
        prodotti.descrizione +
        '</i></p><br></div><div class="ingredientiassociati" id="ingredientiassociati" style="margin-bottom:10%"></div>        </div><div class="aggiungielementomenu" style="margin-top:2%"><button type="button" class="btn btn-primary" style="border-radius: 61px; text-align: center" id="associaingredienti">ASSOCIA INGREDIENTI</button></div></div>';
     
      const dataingredienti = { ricerca: prodotti.nome };
      let request2 = new XMLHttpRequest();
      request2.open("POST", "http://87.3.142.174:8085/ingredientiassociati", true);
      request2.setRequestHeader("Content-Type", "application/json");
      request2.onreadystatechange = function () {
        if (request2.readyState === 4 && request2.status === 200) {
          var ingredientiassociatiallelementomenu = JSON.parse(
            request2.responseText
          );
          var contenitoreingredienti = document.getElementById(
            "ingredientiassociati"
          );
          contenitoreingredienti.innerHTML = "<b>Ingredienti associati:</b>";
          for (var ingr of ingredientiassociatiallelementomenu) {
         
            var divingr = document.createElement("div");
            //cambiare codice_a_barre con un identificativo per i piatti
            divingr.innerHTML =
              "<i>" +
              ingr.nomeingrediente +
              " " +
              ingr.quantitaIngrediente +
              " " +
              ingr.unita +
              "</i>";
            contenitoreingredienti.appendChild(divingr);
          }
        } //else
      };
      request2.send(JSON.stringify(dataingredienti));

      buttontermina = document.getElementById("aggiungielementomenu");
      buttontermina.outerHTML =
        '<button type="button" class="btn btn-primary" style="border-radius: 61px; text-align: center; pointer-events: auto;margin-top:-20%;" id="annullaassociazione">TERMINA PREPARAZIONE PIATTO</button>';
      buttontermina = document.getElementById("annullaassociazione");
      buttontermina.addEventListener("click", () => {
       
        location.reload();
      });

      buttonassocia = document.getElementById("associaingredienti");
      buttonassocia.addEventListener("click", () => {
        const popup2 = document.getElementById("popup_elementoselezionato");
        popup2.style.display = "block";
        buttonassocia.style.pointerEvents = "none";
        const closedispensa = document.getElementById("closemenudoposelezione");
        closedispensa.addEventListener("click", () => {
          popup2.style.display = "none";
          buttonassocia.style.pointerEvents = "auto";
          const popupinputnonvuoto = document.getElementById("risultatoricerca");
          popupinputnonvuoto.style.display="none";
        });
        const closedispensa2 = document.getElementById("xpopupingredienti");
        closedispensa2.addEventListener("click", () => {
          popup2.style.display = "none";
          buttonassocia.style.pointerEvents = "auto";
          const popupinputnonvuoto = document.getElementById("risultatoricerca");
          popupinputnonvuoto.style.display="none";
        });

        let request = new XMLHttpRequest();
        request.open("GET", "http://87.3.142.174:8085/dispensa");
        request.send();

      
        request.onload = function () {
          // Controlla che la richiesta sia stata completata con successo
          // Ottieni il riferimento al contenitore

          if (request.status === 200) {
            var prodotti2 = JSON.parse(request.responseText);
            var contenitore = document.getElementById("listaingredienti");
            contenitore.innerHTML = "";
            for (var oggetto of prodotti2) {
              var strnome = oggetto.nome;
              strnome = strnome.substring(0, 30);
              var stringredienti = oggetto.ingredienti;
              stringredienti = stringredienti.substring(0, 50);
              if (oggetto.nome.length > 30) {
                strnome = strnome + "...";
              }
              if (oggetto.ingredienti.length > 50) {
                stringredienti = stringredienti + "...";
              }
              creaDivSelDes(
                contenitore,
                oggetto,
                strnome,
                stringredienti
              );
            }
          } else {
            var contenitore = document.getElementById("listaingredienti");
            // Mostra un messaggio di errore
            div.innerHTML =
              "<b>Perfavore ricarica la pagina, Errore nel caricamento della dispensa!</b>";
            contenitore.appendChild(div);
          }
        };
      });
    }
  };
  request.send(JSON.stringify(data));
}

function creaDivSelDes(
  contenitore,
  oggetto,
  strnome,
  stringredienti
) {
  var div = document.createElement("div");
  div.id = "elemento" + oggetto.codice_a_barre;
  div.className = "elemento";
  
  var nomeelementomenu=document.getElementById("nomeelementomenu");
  const data2 = {
    elementomenu: nomeelementomenu.innerHTML,
    codice_a_barre_ingrediente: oggetto.codice_a_barre,
  };
  
  var request2 = new XMLHttpRequest();
  request2.open(
    "POST",
    "http://87.3.142.174:8085/ingredientebybarcodeinelemento",
    true
  );
  request2.setRequestHeader("Content-Type", "application/json");
  request2.onreadystatechange = function () {
    if (request2.readyState === 4 && request2.status === 200) {
    
      if (request2.responseText === "nonPresente") {
        if(oggetto.urlfoto=="")
        oggetto.urlfoto='./img/Image_not_available.png'
        div.innerHTML =
        '<table style="border-collapse: collapse; width: 100%; height: 100px;margin-top:36px" border="0"><tbody>'
        +'<tr style="height: 88px;"><td style="width: 33.0996%; height: 150px;"><img src="'+oggetto.urlfoto+'" alt="" width="120" height="120" /></td><td style="width: 33.5203%; height: 88px; text-align: left;"><p><b style="font-size:24px" id="nomeingrediente' +
        oggetto.codice_a_barre +
        '">'+oggetto.nome+'</b></p><p><b style="font-size: 20px;">Descrizione</b></p><p><i style="font-size: 20px;">'+oggetto.descrizione+'</i></p><p><b>Unita di misura: </b>'+oggetto.unita+'</p></td><td style="width: 33.0996%; height: 88px;"><button type="button" class="btn btn-outline-primary btn-lg"; id="selezionaingrediente' +
        oggetto.codice_a_barre +
        '", onclick="selezionaQuantitaIngediente(this)"><b>SELEZIONA</b></button></td></tr></tbody></table>';

        contenitore.appendChild(div);
      } else {
        if(oggetto.urlfoto=="")
        oggetto.urlfoto='./img/Image_not_available.png'
        div.innerHTML =
        '<table style="border-collapse: collapse; width: 100%; height: 100px;margin-top:36px" border="0"><tbody>'
        +'<tr style="height: 88px;"><td style="width: 33.0996%; height: 150px;"><img src="'+oggetto.urlfoto+'" alt="" width="120" height="120" /></td><td style="width: 33.5203%; height: 88px; text-align: left;"><p><b style="font-size:24px" id="nomeingrediente' +
        oggetto.codice_a_barre +
        '">'+oggetto.nome+'</b></p><p><b style="font-size: 20px;">Descrizione</b></p><p><i style="font-size: 20px;">'+oggetto.descrizione+'</i></p><p><b>Unita di misura: </b>'+oggetto.unita+'</p</td><td style="width: 33.0996%; height: 88px;"><button type="button" class="btn btn-outline-primary btn-lg"; id="selezionaingrediente' +
        oggetto.codice_a_barre +
        '", onclick="deselezionaIngrediente(this)"><b>DESELEZIONA</b></button></td></tr></tbody></table>';
        contenitore.appendChild(div);
      }
    }
  };
  request2.send(JSON.stringify(data2));
}
document.getElementById('back').onclick =  function () {
  var ruolo=getCookie("ruolo");
  ruolo = ruolo.substring(1,ruolo.length -1);
 
  
    if(ruolo=="amministratore")
    window.location.replace("home-admin.html");
      if(ruolo=="supervisore")
      window.location.replace("home-supervisore.html");
      if(ruolo=="addetto cucina")
      window.location.replace("home-AddettoCucina.html");
     
  //window.location.replace('../home-admin.html');
}
document.getElementById("ricercaingredientedaaggiungere").addEventListener("input", filterChildrenINGREDIENTI);

function filterChildrenINGREDIENTI() {
  var input, filter, contenitore, child;
  input = document.getElementById("ricercaingredientedaaggiungere");
  filter = input.value.toUpperCase();
  contenitore = document.getElementById("listaingredienti");
  child = contenitore.children;
  for (var i = 0; i < child.length; i++) {
    var txtValue = child[i].textContent || child[i].innerText;
    let pos = txtValue.indexOf("Descrizione");
    txtValue = txtValue.substring(0, pos);
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      child[i].style.display = "";
    } else {
      child[i].style.display = "none";
    }
  }
}


