let container = document.getElementById('listadispensa');
let personalizzati=[];
for (let i = 0; i < container.children.length; i++) {
  let child = container.children[i];
  if (child.tagName === "DIV") {
    if(child.id.indexOf("personalizzato")!=-1){
      let lastLetter = child.id[child.id.length-1];
  let lastLetterAsInt = parseInt(lastLetter)
  personalizzati.push(lastLetterAsInt);
  personalizzati.sort(function(a, b) {
    return b - a;
  });

    }
  }
}
var controllotipoinsert=0;
var prodotti;
const buttonconfermaaggiungi = document.getElementById("confermaaggiungi");
buttonconfermaaggiungi.addEventListener("click", () => {
  if(controllotipoinsert==0){
    inseriscidispensanoopenfood();
    controllotipoinsert=0;
    
  }else{
    inseriscidispensaDAopenfood()
    controllotipoinsert=0;
  }

});
const button1 = document.getElementById('aggiunginuovoprodotto');
const popup2 = document.getElementById('popup_aggiungi_prodotto');
const close3 = document.getElementById('closeaggiungi');
button1.addEventListener('click', () => {
  popup.style.display = 'block';
});

close3.addEventListener('click', () => {
  popup.style.display = 'none';
  
  var descrizioneaggiungi=document.getElementById("descrizioneaggiungi");
  var prezzoaggiungi=document.getElementById("prezzoaggiungi");
  var quantitaaggiungiprodotto=document.getElementById("quantitaaggiungiprodotto");
  var barra=document.getElementById("ricercaopenfood");
  var barraallergeni = document.getElementById("allergeniaggiungi");
  var barraingredienti = document.getElementById("ingredientiaggiungi");
  barra.value="";
  barraingredienti.value="";
  barraallergeni.value="";
  quantitaaggiungiprodotto.value="";
  descrizioneaggiungi.value="";
  prezzoaggiungi.value="";
  controllotipoinsert=0;
});
function selezionaProdotto(element) {
  const elementId = element.id;
  var strid = `${elementId}`;
  strid = strid.replace("seleziona", "");
  const popup = document.getElementById("popup_openfood_prodotto");
  popup.style.display = "none";
  button.style.pointerEvents = "auto";
  var barra=document.getElementById("ricercaopenfood");
  var barraallergeni = document.getElementById("allergeniaggiungi");
  var barraingredienti = document.getElementById("ingredientiaggiungi");
  const data = { ricerca: strid };
 
  var request = new XMLHttpRequest();
  request.open("POST", "http://87.3.142.174:8085/openfoodbybarcode", true);
  request.setRequestHeader('Content-Type', 'application/json');
  request.onreadystatechange = function () {
      if (request.readyState === 4 && request.status === 200) {  
          prodotti = JSON.parse(request.responseText);
       
          barra.value=prodotti.nome;
         
          barraallergeni.value=prodotti.allergeni;
          barraingredienti.value=prodotti.ingredienti;
          controllotipoinsert=1;
      }
  };
  request.send(JSON.stringify(data));
}
function inseriscidispensaDAopenfood(){
  const popup = document.getElementById("popup_openfood_prodotto");
  popup.style.display = "none";
  button.style.pointerEvents = "auto";
  var descrizioneaggiungi=document.getElementById("descrizioneaggiungi");
  var prezzoaggiungi=document.getElementById("prezzoaggiungi");
  var quantitaaggiungiprodotto=document.getElementById("quantitaaggiungiprodotto");
  var barra=document.getElementById("ricercaopenfood");
  const KGButton = document.querySelector('#KG-outlined');
  const LITERSButton = document.querySelector('#LITERS-outlined');
  const UNITButton = document.querySelector('#UNITS-outlined');
  var unitadimisura="";
  var barraallergeni = document.getElementById("allergeniaggiungi");
  var barraingredienti = document.getElementById("ingredientiaggiungi");
  if (KGButton.checked) {
    
    unitadimisura="Kg";
  } else if (LITERSButton.checked) {
    
    unitadimisura="Litri";
  } else if (UNITButton.checked) {
    unitadimisura="Unita";
  }

  const data2 = { codiceabarre: prodotti.codice_a_barre,//funzionepercambiare
  nome: barra.value,
   ingredienti: barraingredienti.value,
   allergeni: barraallergeni.value,
    urlfoto: prodotti.urlfoto,
    quantita:quantitaaggiungiprodotto.value,
    descrizione:descrizioneaggiungi.value,
    prezzo:prezzoaggiungi.value,
 unita: unitadimisura};
  if(barra.value.trim() === ""){
    const popoup_aggiungiprodotto=document.getElementById("popup_aggiungi_prodotto");
    popoup_aggiungiprodotto.style.display = "none";
    const popupmessaggioconferma = document.getElementById("messaggioerroreinputnome");
              popupmessaggioconferma.style.display = "block";
              document.body.scrollTop = 0;
              setTimeout(function () {
                popupmessaggioconferma.style.display = "none";
              }, 2500);
          barra.value="";
          barraingredienti.value="";
            barraallergeni.value="";
            quantitaaggiungiprodotto.value="";
            descrizioneaggiungi.value="";
            prezzoaggiungi.value="";

  }else if(quantitaaggiungiprodotto.value<=0 || prezzoaggiungi.value<=0){
    //mettere messaggio errore
    const popoup_aggiungiprodotto=document.getElementById("popup_aggiungi_prodotto");
    popoup_aggiungiprodotto.style.display = "none";
    const popupmessaggioconferma = document.getElementById("messaggioerroreinput");
              popupmessaggioconferma.style.display = "block";
              document.body.scrollTop = 0;
              setTimeout(function () {
                popupmessaggioconferma.style.display = "none";
              }, 2500);
          barra.value="";
          barraingredienti.value="";
            barraallergeni.value="";
            quantitaaggiungiprodotto.value="";
            descrizioneaggiungi.value="";
            prezzoaggiungi.value="";
  }else{
    let request = new XMLHttpRequest();
    request.open("PUT", "http://87.3.142.174:8085/inseriscidispensa");
    request.setRequestHeader("Content-Type", "application/json");
    request.onload = function () {
        if (request.status === 200) {
          
            if (request.responseText=="false"){
              const popoup_aggiungiprodotto=document.getElementById("popup_aggiungi_prodotto");
              popoup_aggiungiprodotto.style.display = "none";
              const popupmessaggioconferma = document.getElementById("messaggioerrore");
              popupmessaggioconferma.style.display = "block";
              document.body.scrollTop = 0;
              setTimeout(function () {
                popupmessaggioconferma.style.display = "none";
              }, 2500);
            }else{
              const popoup_aggiungiprodotto=document.getElementById("popup_aggiungi_prodotto");
              popoup_aggiungiprodotto.style.display = "none";
              const popupmessaggioconferma = document.getElementById("messaggioconferma");
              popupmessaggioconferma.style.display = "block";
              document.body.scrollTop = 0;
              setTimeout(function () {
                popupmessaggioconferma.style.display = "none";
                location.reload();
              }, 2500);
            }
            barra.value="";
            barraingredienti.value="";
            barraallergeni.value="";
            quantitaaggiungiprodotto.value="";
            descrizioneaggiungi.value="";
            prezzoaggiungi.value="";
        } else {
           
            const popoup_aggiungiprodotto=document.getElementById("popup_aggiungi_prodotto");
              popoup_aggiungiprodotto.style.display = "none";
              const popupmessaggioconferma = document.getElementById("");
              popupmessaggioconferma.style.display = "block";
              setTimeout(function () {
                popupmessaggioconferma.style.display = "none";
              }, 2500);
              barra.value="";
              barraingredienti.value="";
              barraallergeni.value="";
              quantitaaggiungiprodotto.value="";
              descrizioneaggiungi.value="";
              prezzoaggiungi.value="";
        }
    };
    request.send(JSON.stringify(data2));
    //mostra pop up aggiunto con successo
  }




}
function inseriscidispensanoopenfood(){

  for (let i = 0; i < container.children.length; i++) {
    let child = container.children[i];
    if (child.tagName === "DIV") {
      if(child.id.indexOf("personalizzato")!=-1){
        let lastLetter = child.id[child.id.length-1];
    let lastLetterAsInt = parseInt(lastLetter)
    personalizzati.push(lastLetterAsInt);
    personalizzati.sort(function(a, b) {
      return b - a;
    });
  
      }
    }
  }



  const popup = document.getElementById("popup_openfood_prodotto");
  popup.style.display = "none";
  button.style.pointerEvents = "auto";
  var descrizioneaggiungi=document.getElementById("descrizioneaggiungi");
  var prezzoaggiungi=document.getElementById("prezzoaggiungi");
  var quantitaaggiungiprodotto=document.getElementById("quantitaaggiungiprodotto");
  var barra=document.getElementById("ricercaopenfood");
  const KGButton = document.querySelector('#KG-outlined');
  const LITERSButton = document.querySelector('#LITERS-outlined');
  const UNITButton = document.querySelector('#UNITS-outlined');
  var unitadimisura="";
  var barraallergeni = document.getElementById("allergeniaggiungi");
  var barraingredienti = document.getElementById("ingredientiaggiungi");
  if (KGButton.checked) {
    unitadimisura="Kg";
  } else if (LITERSButton.checked) {
    unitadimisura="Litri";
  } else if (UNITButton.checked) {
    unitadimisura="Unita";
  }

  var codice;

  if(personalizzati.length===0){
    codice="0";
  }else{
    codice=personalizzati[0]+1;
  }


  const data2 = { codiceabarre:"personalizzato"+String(codice),//funzionepercambiare
    nome: barra.value,
     ingredienti: barraingredienti.value,
     allergeni: barraallergeni.value,
      urlfoto: './img/Image_not_available.png',
      quantita:quantitaaggiungiprodotto.value,
      descrizione:descrizioneaggiungi.value,
      prezzo:prezzoaggiungi.value,
   unita: unitadimisura};
   if(barra.value.trim() === ""){
    const popoup_aggiungiprodotto=document.getElementById("popup_aggiungi_prodotto");
    popoup_aggiungiprodotto.style.display = "none";
    const popupmessaggioconferma = document.getElementById("messaggioerroreinputnome");
              popupmessaggioconferma.style.display = "block";
              document.body.scrollTop = 0;
              setTimeout(function () {
                popupmessaggioconferma.style.display = "none";
              }, 2500);
          barra.value="";
          barraingredienti.value="";
            barraallergeni.value="";
            quantitaaggiungiprodotto.value="";
            descrizioneaggiungi.value="";
            prezzoaggiungi.value="";

  }else if(quantitaaggiungiprodotto.value<=0 || prezzoaggiungi.value<=0){
    //mettere messaggio errore
    const popoup_aggiungiprodotto=document.getElementById("popup_aggiungi_prodotto");
    popoup_aggiungiprodotto.style.display = "none";
    const popupmessaggioconferma = document.getElementById("messaggioerroreinput");
              popupmessaggioconferma.style.display = "block";
              document.body.scrollTop = 0;
              setTimeout(function () {
                popupmessaggioconferma.style.display = "none";
              }, 2500);
          barra.value="";
          barraingredienti.value="";
            barraallergeni.value="";
            quantitaaggiungiprodotto.value="";
            descrizioneaggiungi.value="";
            prezzoaggiungi.value="";
  }else{
    let request = new XMLHttpRequest();
    request.open("PUT", "http://87.3.142.174:8085/inseriscidispensa");
    request.setRequestHeader("Content-Type", "application/json");
   
    request.onload = function () {
        if (request.status === 200) {
         
            if (request.responseText=="false"){
              const popoup_aggiungiprodotto=document.getElementById("popup_aggiungi_prodotto");
              popoup_aggiungiprodotto.style.display = "none";
              const popupmessaggioconferma = document.getElementById("messaggioerrore");
              popupmessaggioconferma.style.display = "block";
              document.body.scrollTop = 0;
              setTimeout(function () {
                popupmessaggioconferma.style.display = "none";
              }, 2500);
            }else{
              const popoup_aggiungiprodotto=document.getElementById("popup_aggiungi_prodotto");
              popoup_aggiungiprodotto.style.display = "none";
              const popupmessaggioconferma = document.getElementById("messaggioconferma");
              popupmessaggioconferma.style.display = "block";
              document.body.scrollTop = 0;
              setTimeout(function () {
                popupmessaggioconferma.style.display = "none";
                location.reload();
              }, 2500);
            }
          
            barra.value="";
            barraingredienti.value="";
            barraallergeni.value="";
            quantitaaggiungiprodotto.value="";
            descrizioneaggiungi.value="";
            prezzoaggiungi.value="";

        } else {
           
            const popoup_aggiungiprodotto=document.getElementById("popup_aggiungi_prodotto");
              popoup_aggiungiprodotto.style.display = "none";
              const popupmessaggioconferma = document.getElementById("");
              popupmessaggioconferma.style.display = "block";
              setTimeout(function () {
                popupmessaggioconferma.style.display = "none";
              }, 2500);
             
              barra.value="";
              barraingredienti.value="";
              barraallergeni.value="";
              quantitaaggiungiprodotto.value="";
              descrizioneaggiungi.value="";
              prezzoaggiungi.value="";
        }
    };
    request.send(JSON.stringify(data2));
  }




}
