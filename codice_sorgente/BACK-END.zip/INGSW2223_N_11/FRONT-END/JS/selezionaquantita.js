function getCookie(nomeCookie) {
  var name = nomeCookie + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(';');
  for(var i = 0; i <ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

const conferma = document.getElementById("confermaselezioneingrediente");

function selezionaQuantitaIngediente(element) {
  const elementId = element.id;
  var strid = `${elementId}`;
  strid = strid.replace("selezionaingrediente", "");

  const popupdoposeleziona = document.getElementById("popup_digitaquantita");
  popupdoposeleziona.style.display = "block";

  const close = document.getElementById("closeselezionaquantita");
  close.addEventListener("click", () => {
    popupdoposeleziona.style.display = "none";
  });
  conferma.dataset.strid = strid;
}

conferma.addEventListener("click", () => {
  var strid = conferma.dataset.strid;
  clickConfermaSelezione(strid);
  
  
});

function postassociati() {
  var nomeelementomenu = document.getElementById("nomeelementomenu");
  const dataingredienti = { ricerca: nomeelementomenu.innerHTML };
 
  var request = new XMLHttpRequest();
  request.open("POST", "http://87.3.142.174:8085/ingredientiassociati", true);
  request.setRequestHeader("Content-Type", "application/json");
  request.onreadystatechange = function () {
    if (request.readyState === 4 && request.status === 200) {
      var ingredientiassociatiallelementomenu = JSON.parse(
        request.responseText
      );
      var contenitoreingredienti = document.getElementById(
        "ingredientiassociati"
      );
      contenitoreingredienti.innerHTML = "<b>Ingredienti associati:</b>";
      for (var ingr of ingredientiassociatiallelementomenu) {
      
        var divingr = document.createElement("div");
        //cambiare codice_a_barre con un identificativo per i piatti
        divingr.innerHTML =
          "<i>" +
          ingr.nomeingrediente +
          " " +
          ingr.quantitaIngrediente +
          " " +
          ingr.unita +
          "</i>";
      
        contenitoreingredienti.appendChild(divingr);
      }
    }
  };
  request.send(JSON.stringify(dataingredienti));
}

function clickConfermaSelezione(strid) {
  const popupdoposeleziona = document.getElementById("popup_digitaquantita");
  var nomeingrediente = document.getElementById("nomeingrediente" + strid);
  nomeingrediente = nomeingrediente.innerHTML;
  var quantita = document.getElementById("quantitaselezionata").value;
  if (quantita=="" || quantita<0 ) {
    const popupinputvuoto = document.getElementById("inputVuotoquantita");///////////////////////
        popupinputvuoto.style.display="block";
        setTimeout(function(){
            popupinputvuoto.style.display="none";
          }, 3000);
  }else{
    const nomeelementomenu = document.getElementById("nomeelementomenu");
    //email ="gianfranxo";
    //document.cookie = 'nomeCookie='+email+'';
    var myEmail = getCookie("email");
    myEmail = myEmail.substring(1, myEmail.length - 1);
    const data = {
      email: myEmail,
      nomeelementomenu: nomeelementomenu.innerHTML,
      ingrediente: strid,
      quantita: quantita,
    };
  
    var request = new XMLHttpRequest();
    request.open(
      "PUT",
      "http://87.3.142.174:8085/inseisciingredientepreparazionepiatto"
    );
    request.setRequestHeader("Content-Type", "application/json");
    request.onload = function () {
      if (request.status === 200) {
        
        postassociati();
        popupdoposeleziona.style.display = "none";
        var selDes = document.getElementById("selezionaingrediente" + strid);
        selDes.outerHTML =
          '<button type="button" class="btn btn-outline-primary btn-lg" style="margin-top:30px;" id="selezionaingrediente' +
          strid +
          '" ,="" onclick="deselezionaIngrediente(this)"><b>DESELEZIONA</b></button>';
      } else {
        console.log("Error: " + request.status);
      }
    };
    request.send(JSON.stringify(data));
    const popup = document.getElementById("popup_digitaquantita");
  popup.style.display = "none";
  const popupmessaggioconferma = document.getElementById("messaggioconfermaassocia");
    popupmessaggioconferma.style.display = "block";
    setTimeout(function(){
      popupmessaggioconferma.style.display="none";
    }, 3000);
  }
}
