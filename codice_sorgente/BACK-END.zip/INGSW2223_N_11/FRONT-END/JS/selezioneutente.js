document.getElementById('addetto_sala').onclick =  function () {
    window.location.replace('creazioneutente.html?ruolo=addetto sala');
}
document.getElementById('addetto_cucina').onclick =  function () {
    window.location.replace('creazioneutente.html?ruolo=addetto cucina');
}
document.getElementById('supervisore').onclick =  function () {
    window.location.replace('creazioneutente.html?ruolo=supervisore');
}
document.getElementById('back').onclick =  function () {
    var ruolo=getCookie("ruolo");
    ruolo = ruolo.substring(1,ruolo.length -1);
   
   
      if(ruolo=="amministratore")
      window.location.replace("home-admin.html");
        if(ruolo=="supervisore")
        window.location.replace("home-supervisore.html");
        if(ruolo=="addetto cucina")
        window.location.replace("home-AddettoCucina.html");
        if(ruolo=="addetto sala")
        window.location.replace("home-AddettoSala.html");
    
}
function getCookie(nomeCookie) {
    var name = nomeCookie + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }
window.onbeforeunload = function(event) {
    event.preventDefault();
  };