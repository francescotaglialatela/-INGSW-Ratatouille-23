const buttonconfermameno = document.getElementById("confermameno");

function menoProdotto(element) {
  const elementId = element.id;
  var strid = `${elementId}`;
  strid = strid.replace("bottonemeno", "");
  const popup = document.getElementById("popup_meno_prodotto");
  popup.style.display = "block";
  const close = document.getElementById("closemeno");
  close.addEventListener("click", () => {
    popup.style.display = "none";
  });
  buttonconfermameno.dataset.strid = strid;
}

buttonconfermameno.addEventListener("click", () => {
  var strid = buttonconfermameno.dataset.strid;
  clickSottrai(strid);
  
});

function clickSottrai(strid) {
  var quantita = document.getElementById("quantitameno").value;
  if (quantita=="" || quantita<0 ) {
    const popupinputvuoto = document.getElementById("inputVuotomeno");///////////////////////
        popupinputvuoto.style.display="block";
        setTimeout(function(){
            popupinputvuoto.style.display="none";
          }, 3000);
  }else{
    var data = { id: strid, value: quantita };
    let request = new XMLHttpRequest();
    request.open("PUT", "http://87.3.142.174:8085/sottrai");
    request.setRequestHeader("Content-Type", "application/json");
    request.onload = () => console.log(request.responseText);
    request.send(JSON.stringify(data));
    var disponibilita = document.getElementById("disponibilita" + strid);
    disponibilita.innerHTML = disponibilita.innerHTML.replace(
      "disponibilita: ",
      ""
    );
    var nuovaquantità = Number.parseFloat(disponibilita.innerHTML);
    nuovaquantità = nuovaquantità - Number.parseFloat(quantita);
    if(nuovaquantità<=0){
      var divdaeliminare=document.getElementById("elemento"+strid);
        divdaeliminare.remove();
    }else{
    disponibilita.innerHTML = "disponibilita: " + nuovaquantità;}
    const popup = document.getElementById("popup_meno_prodotto");
    popup.style.display = "none";
    const popupmessaggioconferma = document.getElementById("messaggioconferma");
    popupmessaggioconferma.style.display = "block";
    setTimeout(function(){
      popupmessaggioconferma.style.display="none";
    }, 3000);
    var quantita = document.getElementById("quantitameno");
    quantita.value="";
  }

}
