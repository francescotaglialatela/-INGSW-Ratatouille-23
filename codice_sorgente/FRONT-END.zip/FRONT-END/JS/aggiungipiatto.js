let menuVisible = false;
//metodo onclick sulla X
const img = document.getElementById("xpopupaggiungi");
img.addEventListener("click", function() {
  const div = document.getElementById("popup_elementoselezionato");
  div.style.display = "none";
 
});
document.getElementById('back').onclick =  function () {
  mostraPopupAnnulla();
  }
//metodo click sulla x
const listaDiv = document.querySelector("#lista-div");
listaDiv.style.listStyleType = "none";
//modal annulla
function mostraPopupAnnulla(){
  const modal = document.createElement('div');
  modal.classList.add('modal', 'fade');
  modal.setAttribute('id', 'staticBackdrop');
  modal.setAttribute('data-bs-backdrop', 'static');
  modal.setAttribute('data-bs-keyboard', 'false');
  modal.setAttribute('tabindex', '-1');
  modal.setAttribute('aria-labelledby', 'staticBackdropLabel');
  modal.setAttribute('aria-hidden', 'true');
  
  const dialog = document.createElement('div');
  dialog.classList.add('modal-dialog', 'modal-dialog-centered');
  
  const content = document.createElement('div');
  content.classList.add('modal-content');
  content.setAttribute('style', 'border-radius: 41px;');
  
  const header = document.createElement('div');
  header.classList.add('modal-header');
  
  const title = document.createElement('h1');
  title.classList.add('modal-title', 'fs-5');
  title.setAttribute('id', 'staticBackdropLabel');
  title.innerHTML = 'Avviso';
  
  const body = document.createElement('div');
  body.classList.add('modal-body');
  
  const text = document.createElement('p');
  text.setAttribute('id', 'testo-pop-up');
  text.innerHTML = 'Le modifiche correnti verranno annullate.Sei sicuro di voler annullare l operazione?';
  const button_ann = document.createElement('button');
  button_ann.type = 'button';
  button_ann.classList.add('btn', 'btnannullaPopUp');
  button_ann.setAttribute('style', 'border-radius: 61px; border-color: black;');
  button_ann.innerHTML = 'NO';
  
  
  const button_conferma = document.createElement('button');
  button_conferma.type = 'button';
  button_conferma.classList.add('btn', 'btnconfermaPopUp');
  button_conferma.setAttribute('style', 'border-radius: 61px;');
  button_conferma.innerHTML = 'SI';
  button_ann.style.marginRight = '166px';
  
  const footer = document.createElement('div');
  footer.classList.add('modal-footer');
  button_ann.addEventListener('click', function() {
    // Codice per rimuovere il mock-up qui
    $(modal).modal('hide');
      
  
  });
  button_ann.addEventListener('mouseover', function() {
    button_ann.style.borderColor = ' #3970ff';
  });
  
  button_ann.addEventListener('mouseout', function() {
    button_ann.style.borderColor = 'black';
  });
  
  button_conferma.addEventListener('click', function(){
    //aggiunge che ritona alla home html
    window.location.assign("personalizzazione.html");
    
  });
  
  
  // Appendi gli elementi l'uno all'altro
  modal.appendChild(dialog);
  dialog.appendChild(content);
  content.appendChild(header);
  header.appendChild(title);
  content.appendChild(body);
  body.appendChild(text);
  content.appendChild(footer);
  footer.appendChild(button_ann);
  footer.appendChild(button_conferma);
  
  document.body.appendChild(modal);
  $(modal).modal('show');
  
  }
//modal annulla
//modal home
function mostraPopupHome(){
  const modal = document.createElement('div');
  modal.classList.add('modal', 'fade');
  modal.setAttribute('id', 'staticBackdrop');
  modal.setAttribute('data-bs-backdrop', 'static');
  modal.setAttribute('data-bs-keyboard', 'false');
  modal.setAttribute('tabindex', '-1');
  modal.setAttribute('aria-labelledby', 'staticBackdropLabel');
  modal.setAttribute('aria-hidden', 'true');
  
  const dialog = document.createElement('div');
  dialog.classList.add('modal-dialog', 'modal-dialog-centered');
  
  const content = document.createElement('div');
  content.classList.add('modal-content');
  content.setAttribute('style', 'border-radius: 41px;');
  
  const header = document.createElement('div');
  header.classList.add('modal-header');
  
  const title = document.createElement('h1');
  title.classList.add('modal-title', 'fs-5');
  title.setAttribute('id', 'staticBackdropLabel');
  title.innerHTML = 'Avviso';
  
  const body = document.createElement('div');
  body.classList.add('modal-body');
  
  const text = document.createElement('p');
  text.setAttribute('id', 'testo-pop-up');
  text.innerHTML = 'Le modifiche correnti verranno annullate.Sei sicuro di voler tornare alla Home?';
  const button_ann = document.createElement('button');
  button_ann.type = 'button';
  button_ann.classList.add('btn', 'btnannullaPopUp');
  button_ann.setAttribute('style', 'border-radius: 61px;');
  button_ann.innerHTML = 'NO';
  const button_conferma = document.createElement('button');
  button_conferma.type = 'button';
  button_conferma.classList.add('btn', 'btnconfermaPopUp');
  button_conferma.setAttribute('style', 'border-radius: 61px;');
  button_conferma.innerHTML = 'SI';
  button_ann.style.marginRight = '166px';
  
  const footer = document.createElement('div');
  footer.classList.add('modal-footer');
  button_ann.addEventListener('click', function() {
    // Codice per rimuovere il mock-up qui
    $(modal).modal('hide');
      
  
  });
  
  button_conferma.addEventListener('click', function(){
    //aggiunge che ritona alla home html
    // a seconda dell utente deve tornare alla home
    //window.location.assign("personalizzazione.html");
    var ruolo=getCookie("ruolo");
      ruolo = ruolo.substring(1,ruolo.length -1);
      
        if(ruolo=="amministratore")
        window.location.replace("home-admin.html");
          if(ruolo=="supervisore")
          window.location.replace("home-supervisore.html");
    
  });
  
  
  // Appendi gli elementi l'uno all'altro
  modal.appendChild(dialog);
  dialog.appendChild(content);
  content.appendChild(header);
  header.appendChild(title);
  content.appendChild(body);
  body.appendChild(text);
  content.appendChild(footer);
  footer.appendChild(button_ann);
  footer.appendChild(button_conferma);
  
  document.body.appendChild(modal);
  $(modal).modal('show');
  
  }
//modal home
document.getElementById('annulla').onclick =  function () {
mostraPopupAnnulla();
}
var home = document.getElementById("home");
home.style.setProperty("outline","none","important");
document.getElementById('home').onclick =  function () {
 
  mostraPopupHome();
  }
//bottoneconferma
document.getElementById('buttonconferma').onclick =  function () {
  this.style.setProperty("outline","none","important");
    var descrizione=document.getElementById('Descrizione').value;
    var allergeni=document.getElementById('Allergeni').value;
    var costo=document.getElementById('costo').value;
    var ricerca_dispensa=document.getElementById('ricercadispensa').value;
    if(ricerca_dispensa==""){
        
        document.getElementById("ricercadispensa").style.borderColor = "red";
    }else{
        document.getElementById("ricercadispensa").style.borderColor = "black";
    }
    if(descrizione==" "){
        
        document.getElementById("Descrizione").style.borderColor = "red";
    }else{
        document.getElementById("Descrizione").style.borderColor = "black";
    }
   
    
    if(allergeni==" "){
        
        document.getElementById("Allergeni").style.borderColor = "red";
    }else{
        document.getElementById("Allergeni").style.borderColor = "black";
    }
    
    if(costo==""||!/^\d+(\.\d+)?$/.test(costo)){
        
        document.getElementById("costo").style.borderColor = "red";
    }else{
        document.getElementById("costo").style.borderColor = "black";
    }
    if(ricerca_dispensa==""||descrizione==" "||allergeni==" "||costo==""||!/^\d+(\.\d+)?$/.test(costo)){
      let alert = document.getElementById('alertobbligatori');
      alert.style.display = "block";
          $("#alertobbligatori").fadeOut(9500);
    }else{
      let categoria = document.getElementById("search-input");
     categoria = categoria.value;
     
      let piatto={
        Nome:ricerca_dispensa,
        Descrizione:descrizione,
        Allergeni:allergeni,
        Costo:costo,
        Categoria:categoria
      };
     
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "http://localhost:8080/inserimento_piatto", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(piatto));
    xhr.onreadystatechange = function() {
      if (xhr.readyState === 4 && xhr.status === 200) {
          var response = xhr.responseText;
          if (response === "true") {
            let avviso = document.getElementById('avviso-rec');
            avviso.style.display = "block";
            $("#avviso-rec").fadeOut(3500);
            setTimeout(function () {
              window.location.replace("personalizzazione.html");
            },3500);
          } else {
            let alert = document.getElementById('alertred');

            alert.style.display = "block";
            
            $("#alertred").fadeOut(3500);
          }
      }
  };

    }
 
 }
 //bottoneconferma
 document.getElementById("search-input").addEventListener("input", filterOptions);
 document.getElementById("search-input").addEventListener("focus", function(){
    menuVisible = true;
    document.getElementById("category").style.display = "block";
  });
  document.getElementById("category").addEventListener("mousedown", function(){
    menuVisible = true;
  });
  
  document.addEventListener("click", function(event){
    if (!menuVisible) return;
    if (!event.target.closest("#category") && event.target !== document.getElementById("search-input")) {
      menuVisible = false;
      document.getElementById("category").style.display = "none";
    }
  });
  
  document.getElementById("category").addEventListener("change", function(){
    document.getElementById("search-input").value = this.value;
  });
  const div = document.getElementById("popup_elementoselezionato");
  document.getElementById('bottone_ricerca').onclick =  function () {
    div.style.display = "block";
    let nome_elemento = document.getElementById("ricercadispensa").value;
    const dati = { ricerca: nome_elemento };
    var request = new XMLHttpRequest();
    request.open("POST", "http://87.3.142.174:8085/srcopenfood", true);
    
    request.setRequestHeader('Content-Type', 'application/json');
   
  
    request.onreadystatechange = function () {
        if (request.readyState === 4 && request.status === 200) {
          var data = JSON.parse(request.responseText);
          
          for (let i = 0; i < data.length; i++) {
            
            const newLi = document.createElement("li");
            var descrizione=data[i].ingredienti;
            if(descrizione.length>30){
            descrizione=descrizione.substring(0,30);
            descrizione=descrizione+"...";}
            var nome=data[i].nome;
            if(nome.length>30){
            nome=nome.substring(0,30);
            nome=nome+"...";}
            var allergeni=data[i].allergeni;
            if(allergeni.length>30){
            allergeni=allergeni.substring(0,30);
            allergeni=allergeni+"...";}
      
        newLi.innerHTML = `
          <div id="contenitorelementi" style="margin-left:3px">
            <p id="nome" style="margin-right:500px"><strong>Nome:</strong>${nome} </p>
            <p id="descrizione" style="margin-right:500px"><strong>Descrizione:</strong>${descrizione}</p>
            <p id="allergeni" style="margin-right:500px"><strong>Allergeni:</strong>${allergeni}</p>
            <button id="bottoneseleziona" style="margin-right:20px;">Seleziona</button>
          </div>
        `;
       
          listaDiv.appendChild(newLi);
           }
           const bottoniSeleziona = document.querySelectorAll("#bottoneseleziona");
           for (let i = 0; i < bottoniSeleziona.length; i++) {
          bottoniSeleziona[i].style.outline="none";
          bottoniSeleziona[i].addEventListener("click", function() {
         
          const div = this.closest("#contenitorelementi");
          
          const nome = data[i].nome;
          const descrizione = data[i].ingredienti;
          const allergeni = data[i].allergeni;
         
          let nome_elemento = document.getElementById("ricercadispensa");
          nome_elemento.value=nome;
          let descrizione_elemento = document.getElementById("Descrizione");
          descrizione_elemento.value=descrizione;
          let allergeni_elemento = document.getElementById("Allergeni");
          allergeni_elemento.value=allergeni;
          const divpopup = document.getElementById("popup_elementoselezionato");
          divpopup.style.display = "none";
         
          
          });
          bottoniSeleziona[i].addEventListener("mouseover", function() {
            this.style.border = "4px solid rgb(70, 154, 227)";
          });
          bottoniSeleziona[i].addEventListener("mouseout", function() {
            this.style.border = "2px solid rgb(70, 154, 227)";
          });
      }
         
        }
    };
    request.send(JSON.stringify(dati));
  }


  function filterOptions() {
    var input, filter, select, option;
    input = document.getElementById("search-input");
    filter = input.value.toUpperCase();
    select = document.getElementById("category");
    option = select.getElementsByTagName("option");
   
    for (var i = 0; i < option.length; i++) {
      var txtValue = option[i].textContent || option[i].innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        option[i].style.display = "";
      } else {
        option[i].style.display = "none";
      }
    }
  }

 function inserimento_lista(arr,index){
    if(index>=arr.length||arr[index]=='None'){
        return;
    }
    let select = document.getElementById("category");
    let option = document.createElement("option");
    option.value = arr[index];
    option.textContent = arr[index];
    select.appendChild(option);
    inserimento_lista(arr,index+1);

 }
 setTimeout(function () {
  const div = document.getElementById("popup_elementoselezionato");
  div.style.display = "none";
      $.ajax({
        url: 'http://87.3.142.174:8085/getCategorie_e_SottoCategorie',
      type: 'GET',
      dataType: 'json',
      success: function(data) {
       for (let i = 0; i < data.length; i++) {
         
       }
       inserimento_lista(data,0);
      
    




      }})
      
  
    
  
  //FINE LISTA CATEGORIE
  },300);
  window.onbeforeunload = function(event) {
    event.preventDefault();
  };
  function getCookie(nomeCookie) {
    var name = nomeCookie + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }