const button = document.getElementById('aggiunginuovoprodotto');
const popup = document.getElementById('popup_aggiungi_prodotto');
const close = document.getElementById('closeaggiungi');

button.addEventListener('click', () => {
  popup.style.display = 'block';
});

close.addEventListener('click', () => {
  popup.style.display = 'none';
 
});