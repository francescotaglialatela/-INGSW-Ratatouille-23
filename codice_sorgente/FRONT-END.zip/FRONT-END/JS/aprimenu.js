const button = document.getElementById("aggiungielementomenu");
const popup = document.getElementById("popup_menu");
const close = document.getElementById("closemenu");
const close2 = document.getElementById("xpopupaggiungi");

button.addEventListener("click", () => {
  popup.style.display = "block";
  button.style.pointerEvents = "none";
  let request = new XMLHttpRequest();
  request.open("GET", "http://87.3.142.174:8085/elementimenu");
  request.send();
  request.onload = function () {
    // Controlla che la richiesta sia stata completata con successo
    // Ottieni il riferimento al contenitore
    //nomelemento,descrizione,costo,allergeni
    if (request.status === 200) {
      var prodotti = JSON.parse(request.responseText);

      var contenitore = document.getElementById("listaelementimenu");
      contenitore.innerHTML = "";
      for (var oggetto of prodotti) {
        var div = document.createElement("div");
        //cambiare codice_a_barre con un identificativo per i piatti
        div.id = "elemento" + oggetto.nome;
        div.style.marginTop="30px";
        div.style.marginLeft="50px";
        div.innerHTML =
          '<table style="border-collapse: collapse; width: 100%; height: 100px;" border="0"><tbody>'
          +'<tr style="height: 88px;"><td style="width: 33.5203%; height: 88px; text-align: left;"><p><b style="font-size:24px">'+oggetto.nome+'</b></p><p><b style="font-size: 20px;">Descrizione</b></p><p><i style="font-size: 20px;">'+oggetto.descrizione+'</i></p></td><td style="width: 33.0996%; height: 88px;"><button type="button" class="btn btn-outline-primary btn-lg" style="margin-top:30px"; id="seleziona' +
          oggetto.nome +
          '", onclick="selezionaElementoMenu(this)"><b>SELEZIONA</b></button></td></tr></tbody></table>'

        contenitore.appendChild(div);
      }
    } else {
      var contenitore = document.getElementById("listaelementimenu");
      // Mostra un messaggio di errore
      var div = document.createElement("div");
      //div.className = "prodottodispensa";
      div.innerHTML =
        "<b>Perfavore ricarica la pagina, Errore nel caricamento della dispensa!</b>";
      contenitore.appendChild(div);
    }
  };
});
close2.addEventListener("click", () => {
  popup.style.display = "none";
  button.style.pointerEvents = "auto";
  const popupinputnonvuoto = document.getElementById("risultatoricercamenu");
  popupinputnonvuoto.style.display="none";
});
close.addEventListener("click", () => {
  popup.style.display = "none";
  button.style.pointerEvents = "auto";
  const popupinputnonvuoto = document.getElementById("risultatoricercamenu");
  popupinputnonvuoto.style.display="none";
});
