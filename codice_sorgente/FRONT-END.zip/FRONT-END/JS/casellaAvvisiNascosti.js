setTimeout(function () {

    searchMessage();
  
    2000
  });

  //FUNZIONE PER UN TEMPLATE DI AVVISO
function creaTemplateAvviso(ruolo,testo, idAvviso) {
    //creazione del contatore per id
  
    // Creazione della nuova voce della lista
    var newLi = document.createElement("li");
  
    // Creazione del div
    var newDiv = document.createElement("div");
  
    // Assegnazione id ad un div
    newDiv.id = idAvviso;
  
    //Genera un colore random per il background immagine
    var randomColor = 'rgb(' + (Math.floor(Math.random() * 200)) + ',' + (Math.floor(Math.random() * 200)) + ',' + (Math.floor(Math.random() * 200)) + ')';
  
    //Effetto hover per i div
    newDiv.onmouseover = function() {
      //this.style.backgroundColor = "#f5f5f0";
      this.style.backgroundColor = "#e6f0ff";
      this.style.cursor = "pointer";
    }
  
  
    newDiv.onmouseleave = function() {
      this.style.backgroundColor = "white";
    }
  
    // Creazione della funzione che porta all'apertura di un avviso
    newDiv.addEventListener("click", function() {
      openMessage(this.id)
    })
  
    // Creazione dell'immagine
    var newImg = document.createElement("img");
    newImg.style.borderRadius = "50%";
    newImg.style.objectFit = "center";
    newImg.style.backgroundColor = randomColor;
    newImg.src = "./img/iconaUtente.png";
    newImg.alt = "Immagine";
  
    // Creazione del primo paragrafo
    var newP1 = document.createElement("p");
  newP1.innerHTML = ruolo;
  
  // Creazione dell'elemento strong
  var strong = document.createElement("strong");
  
  // Aggiunta del testo del paragrafo all'interno dell'elemento strong
  strong.appendChild(document.createTextNode(newP1.innerHTML));
  
  // Sostituzione del testo del paragrafo con l'elemento strong
  newP1.innerHTML = "";
  newP1.appendChild(strong);
  
    // Creazione del secondo paragrafo
    var newP2 = document.createElement("p");
    newP2.innerHTML = testo;
  
    newImg.style.cssFloat = "left";
    newImg.style.marginRight = "10px";
    newP1.style.display = "inline-block";
  
    var newLine = document.createElement("hr");
    newLine.style.width = "100%";
    newLine.style.border = "0";
    newLine.style.borderTop = "2px solid #000000";
  
    // Aggiunta dell'immagine e dei paragrafi al div
    newDiv.appendChild(newImg);
    newDiv.appendChild(newP1);
    newDiv.appendChild(newP2);
    newDiv.appendChild(newLine);
  
  
    // Aggiunta del div alla voce della lista
    newLi.appendChild(newDiv);
  
    // Aggiunta della nuova voce alla lista
    document.getElementById("lista-mail").appendChild(newLi);
  
  }
  
  function searchMessage() {
    var myEmail = getCookie("email");
    var ruolo;
    var testo;
    var idAvviso;
    myEmail = myEmail.substring(1, myEmail.length -1);
   
    let request = new XMLHttpRequest();
    request.open("GET", "http://87.3.142.174:8085/admin/service/searchMessage/" + myEmail+"/"+ true);
    request.send();
    request.onload = () => {
  
      if (request.status == 200) {
        
        var json = JSON.parse(request.responseText);
        
        const elementsPerIteration = 3;
  
        for(let i=0; i<(json.length);i+= elementsPerIteration){
  
              testo = json[i];
              idAvviso = json[i+1];
              ruolo = json[i+2];
              
              creaTemplateAvviso(ruolo,testo,idAvviso);
            }
        }
      }
    }
  
  //funzione che preso un bottone con di avviso ti riporta ad una pagina
  function openMessage(idAvviso) {
  
    //apre una pagina html che contiene l'avviso.
    location.href = "avviso.html?val="+idAvviso;
  
  }

  function getCookie(nomeCookie) {
    var name = nomeCookie + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
  
  }
  
  document.getElementById('freccia-back').onclick = function() {
    location.href = 'casella-avvisi.html';   
  }