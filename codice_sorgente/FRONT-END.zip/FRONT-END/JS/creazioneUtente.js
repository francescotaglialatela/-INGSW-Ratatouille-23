function mostraPopupAnnulla(){
  const modal = document.createElement('div');
  modal.classList.add('modal', 'fade');
  modal.setAttribute('id', 'staticBackdrop');
  modal.setAttribute('data-bs-backdrop', 'static');
  modal.setAttribute('data-bs-keyboard', 'false');
  modal.setAttribute('tabindex', '-1');
  modal.setAttribute('aria-labelledby', 'staticBackdropLabel');
  modal.setAttribute('aria-hidden', 'true');
  
  const dialog = document.createElement('div');
  dialog.classList.add('modal-dialog', 'modal-dialog-centered');
  
  const content = document.createElement('div');
  content.classList.add('modal-content');
  content.setAttribute('style', 'border-radius: 41px;');
  
  const header = document.createElement('div');
  header.classList.add('modal-header');
  
  const title = document.createElement('h1');
  title.classList.add('modal-title', 'fs-5');
  title.setAttribute('id', 'staticBackdropLabel');
  title.innerHTML = 'Avviso';
  
  const body = document.createElement('div');
  body.classList.add('modal-body');
  
  const text = document.createElement('p');
  text.setAttribute('id', 'testo-pop-up');
  text.innerHTML = 'Le modifiche correnti verranno annullate.Sei sicuro di voler annullare l operazione?';
  const button_ann = document.createElement('button');
  button_ann.type = 'button';
  button_ann.classList.add('btn', 'btnannullaPopUp');
  button_ann.setAttribute('style', 'border-radius: 61px;');
  button_ann.innerHTML = 'NO';
  const button_conferma = document.createElement('button');
  button_conferma.type = 'button';
  button_conferma.classList.add('btn', 'btnconfermaPopUp');
  button_conferma.setAttribute('style', 'border-radius: 61px;color:white');
  button_conferma.innerHTML = 'SI';
  button_ann.style.marginRight = '166px';
  
  const footer = document.createElement('div');
  footer.classList.add('modal-footer');
  button_ann.addEventListener('click', function() {
    // Codice per rimuovere il mock-up qui
    $(modal).modal('hide');
      
  
  });
  
  button_conferma.addEventListener('click', function(){
    //aggiunge che ritona alla home html
    window.location.replace('selezioneutente.html');
    
  });
  
  
  // Appendi gli elementi l'uno all'altro
  modal.appendChild(dialog);
  dialog.appendChild(content);
  content.appendChild(header);
  header.appendChild(title);
  content.appendChild(body);
  body.appendChild(text);
  content.appendChild(footer);
  footer.appendChild(button_ann);
  footer.appendChild(button_conferma);
  
  document.body.appendChild(modal);
  $(modal).modal('show');
  
  }
document.getElementById('annulla').onclick =  function () {
   
mostraPopupAnnulla();
}
function getParameterByName(name, url) {
   if (!url) url = window.location.href;
   name = name.replace(/[\[\]]/g, '\\$&');
   var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
       results = regex.exec(url);
   if (!results) return null;
   if (!results[2]) return '';
   return decodeURIComponent(results[2].replace(/\+/g, ' '));
 }
document.getElementById('ButtonConferma').onclick =  function () {
    //var url = "http://87.3.142.174:8080/admin/api/login?email=kek";
    var ruolo = getParameterByName("ruolo");
   
    var nome=document.getElementById('Nome').value;
    var cognome=document.getElementById('Cognome').value;
    var sesso=document.getElementById('Sesso').value;
    var email=document.getElementById('Email').value;
    var password=document.getElementById('Password').value;
    
    const regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (email == "" || password == "" || nome=="" || cognome==""||!nome.match(/^[a-zA-Z]+$/)|| 
    !cognome.match(/^[a-zA-Z]+$/)||!email.match(/[a-zA-Z]+/)||!password.match( /^(?=.*[A-Za-z]|[\d]|[@$!%*#?&]).{5,}$/)||password.length < 5) {
      
        var text = document.getElementById('testo-pop-up');
        var avanti = document.getElementById('btn-ok');
        text.innerHTML="Per favore, inserisci correttamente:";
        avanti.innerHTML="Riprova";
        
        avanti.onclick = function() {
            $('#staticBackdrop').modal('hide');
        }
        if(nome=="" ||!nome.match(/^[a-zA-Z]+$/)){
        let doc1 = document.getElementById("Nome");
        text.innerHTML=text.innerHTML+"Nome,";
        doc1.style.borderBottomColor = "red";}
        else{
         let doc1 = document.getElementById("Nome");
         doc1.style.borderBottomColor = "black";
        }
        if(cognome=="" || !cognome.match(/^[a-zA-Z]+$/)){
        let doc1 = document.getElementById("Cognome");
        text.innerHTML=text.innerHTML+"Cognome,";
        doc1.style.borderBottomColor = "red";}
        else{
         let doc1 = document.getElementById("Cognome");
         doc1.style.borderBottomColor = "black";}
         if(email==""||!email.match(/[a-zA-Z]+/)||!email.match(regex)){
         let doc1 = document.getElementById("Email");
         text.innerHTML=text.innerHTML+"Email,";
         doc1.style.borderBottomColor = "red";}
         else{
            let doc1 = document.getElementById("Email");
            doc1.style.borderBottomColor = "black";}
         if(password==""||!password.match( /^(?=.*[A-Za-z]|[\d]|[@$!%*#?&]).{5,}$/)||password.length < 5){
         let doc1 = document.getElementById("Password");
         text.innerHTML=text.innerHTML+"Password.";
         doc1.style.borderBottomColor = "red";}
         else{
            let doc1 = document.getElementById("Password");
            doc1.style.borderBottomColor = "black";}
           
            window.scrollTo(0, 0);

    }else{
      let doc1 = document.getElementById("Nome");
      doc1.style.borderBottomColor = "black";
      doc1 = document.getElementById("Cognome");
      doc1.style.borderBottomColor = "black";
      doc1 = document.getElementById("Email");
      doc1.style.borderBottomColor = "black";
      doc1 = document.getElementById("Password");
      doc1.style.borderBottomColor = "black";
      let utente={
        Nome:nome,
        Cognome:cognome,
        Password:password,
        Email:email,
        Sesso:sesso,
        Ruolo:ruolo
      };
      let request = new XMLHttpRequest();
        request.open("POST","http://87.3.142.174:8085/admin/creazioneutenze",true);
        request.setRequestHeader("Content-Type", "application/json");
        request.send(JSON.stringify(utente));
        request.onload = () =>  {
         
          if(request.status == 200)
          {
            
            result = request.responseText;   
            
            if(result=="true")
            {
                
                var text = document.getElementById('testo-pop-up');
                var avanti = document.getElementById('btn-ok');

                text.innerHTML="Creazione avvenuta con successo!";
                avanti.innerHTML="OK";
                
                /*TODO METODO CHE PORTA ALLA SCHERMATA HOME ADMIN*/
                avanti.onclick = function() {
                  window.location.replace('selezioneutente.html');
                }
                
            }
            else{
                
                
                var text = document.getElementById('testo-pop-up');
                var avanti = document.getElementById('btn-ok');

                text.innerHTML="Attenzione, utente già presente con quest'email!";
                avanti.innerHTML="Riprova";
                
                
                avanti.onclick = function() {
                    $('#staticBackdrop').modal('hide');
                }


                //let doc1 = document.getElementById("formGroupExampleInput");
                //doc1.style.borderBottomColor = "red";
                //doc1.style.color = "darkred";

                //let doc2 =document.getElementById("formGroupExampleInput2")
                //doc2.style.borderBottomColor = "red";
                //doc2.style.color="darkred"; 
            }
          }
          else
          {
            console.log("ERRORE");
          }

         
        }
       
    }


}
window.onbeforeunload = function(event) {
  event.preventDefault();
};
window.onload = function() {
  var ruolo = getParameterByName("ruolo");
  var titolo_utente = document.getElementById("titoloutente");

  if(ruolo=='supervisore'){
    ruolo=ruolo.toUpperCase();
  titolo_utente.innerHTML = "INSERISCI I DATI DEL " + ruolo;}
  else{
    ruolo=ruolo.toUpperCase();
    titolo_utente.innerHTML = "INSERISCI I DATI DELL " + ruolo;
  }
};