function inserimento_lista(array,index){
    if(index>=array.length){
        return;
    }
    if(array[index]!='None'){
        $.ajax({
            url: 'http://87.3.142.174:8085/getelementi_dellaMacrocategoria/'+array[index],
            type: 'GET',
            dataType: 'json',
            success: function(elementi) {
                if(elementi.length>0){
                    const list = document.getElementById('ListaCategorie');
                    const button = document.createElement('button');
                    button.textContent = array[index];
                    button.classList.add("bottone_blu");
                    button.setAttribute('style', 'cursor:pointer;width: 50%; color:rgb(70, 154, 227) ; background-color: white; border-radius: 30px;  margin: 10px; margin-left:25px; font-size: 16px; display: block;');
                    button.addEventListener("click", function() {
                        window.location.replace("ordinamento_piatti_categ.html?nomeCategoria=" +array[index],"_blank");
                    });
                    list.appendChild(button);
                    //on click change page
                   
                   
                }
                inserimento_lista(array,index+1);
            }
        }
        )


    }else{
        const list = document.getElementById('ListaCategorie');
        const button = document.createElement('button');
        button.textContent = "Elementi senza categoria";
        button.classList.add("bottone_blu");
        button.setAttribute('style', 'cursor:pointer;width: 50%; color:rgb(70, 154, 227) ; background-color: white; border-radius: 30px;  margin: 10px; margin-left:25px; font-size: 16px; display: block;');
        button.addEventListener("click", function() {
            window.location.replace("ordinamento_piatti_categ.html?nomeCategoria=Noname","_blank");
        });
        list.appendChild(button);
        //on click change page
        inserimento_lista(array,index+1);
    }
}
document.getElementById('back').onclick =  function () {
    window.location.assign("personalizzazione.html");
    }
    document.getElementById('home').onclick =  function () {
        var ruolo=getCookie("ruolo");
        ruolo = ruolo.substring(1,ruolo.length -1);
        if(ruolo=="amministratore")
        window.location.replace("home-admin.html");
        if(ruolo=="supervisore")
        window.location.replace("home-supervisore.html");
        }
setTimeout(function() {
    $.ajax({
      url: 'http://87.3.142.174:8085/getCategorie_e_SottoCategorie',
      type: 'GET',
      dataType: 'json',
      success: function(data) {
       for (let i = 0; i < data.length; i++) {
         
    }
    inserimento_lista(data,0);
}
})},2000);;
window.onbeforeunload = function(event) {
    event.preventDefault();
  };
  function getCookie(nomeCookie) {
    var name = nomeCookie + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }