function deselezionaIngrediente(element) {
  const elementId = element.id;
  var strid = `${elementId}`;
  strid = strid.replace("selezionaingrediente", "");
  

  var div = document.createElement("div");
  const nomeelementomenu = document.getElementById("nomeelementomenu");
  const data = {
    nomeelementomenu: nomeelementomenu.innerHTML,
    ingrediente: strid,
  };

  var request = new XMLHttpRequest();
  request.open(
    "DELETE",
    "http://87.3.142.174:8085/eliminaingredientedallapreparazione"
  );
  request.setRequestHeader("Content-Type", "application/json");
  request.onload = function () {
    if (request.status === 200) {
      
      const popupmessaggioconferma = document.getElementById("messaggioconfermaassocia");
      popupmessaggioconferma.style.display = "block";
      setTimeout(function(){
        popupmessaggioconferma.style.display="none";
      }, 3000);
      var selDes = document.getElementById("selezionaingrediente" + strid);
      selDes.outerHTML =
        '<button type="button" class="btn btn-outline-primary btn-lg" style="margin-top:30px;" id="selezionaingrediente' +
        strid +
        '" ,="" onclick="selezionaQuantitaIngediente(this)"><b>SELEZIONA</b></button>';

      var nomeelementomenu = document.getElementById("nomeelementomenu");
      const dataingredienti = { ricerca: nomeelementomenu.innerHTML };
      var request2 = new XMLHttpRequest();
      request2.open("POST", "http://87.3.142.174:8085/ingredientiassociati", true);
      request2.setRequestHeader("Content-Type", "application/json");
      request2.onreadystatechange = function () {
        if (request2.readyState === 4 && request2.status === 200) {
          var ingredientiassociatiallelementomenu = JSON.parse(
            request2.responseText
          );
          var contenitoreingredienti = document.getElementById(
            "ingredientiassociati"
          );
          contenitoreingredienti.innerHTML = "<b>Ingredienti associati:</b>";
          for (var ingr of ingredientiassociatiallelementomenu) {
            var divingr = document.createElement("div");
            //cambiare codice_a_barre con un identificativo per i piatti
            divingr.innerHTML =
              "<i>" +
              ingr.nomeingrediente +
              " " +
              ingr.quantitaIngrediente +
              " " +
              ingr.unita +
              "</i>";
            
            contenitoreingredienti.appendChild(divingr);
          }
        }
      };
      request2.send(JSON.stringify(dataingredienti));
    } else {
      console.log("Error: " + request.status);
    }
  };
  request.send(JSON.stringify(data));
}
