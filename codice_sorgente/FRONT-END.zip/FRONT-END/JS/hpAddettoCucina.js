const element2 = document.querySelector('#icona-gestionedispensa');

element2.addEventListener('mouseenter', () => {
    element2.classList.add('hover'); 
    const image = document.querySelector('#img-gestionedispensa');
    image.src = './img/icons8-prodotto-53.png';
})
element2.addEventListener("click", function(){
    window.open("dispensa.html")
});


element2.addEventListener('mouseleave', () => {
    const image = document.querySelector('#img-gestionedispensa');
    image.src = './img/icons8-prodotto-52.png';
    element2.classList.remove('hover');
})
const element4 = document.querySelector('#icona-notifica');

element4.addEventListener('mouseenter', () => {
    element4.classList.add('hover'); 
    const image = document.querySelector('#img-notifica');
    image.src = './img/icona-campanella-notifica-hovered.png';
})


element4.addEventListener('mouseleave', () => {
    const image = document.querySelector('#img-notifica');
    image.src = './img/icona-campanella-notifica-basic.png';
    element4.classList.remove('hover');
})



const element7 = document.querySelector('#icona-aggiungi-ingrediente');

element7.addEventListener('mouseenter', () => {
    element7.classList.add('hover'); 
    const image = document.querySelector('#img-aggiungi-ingrediente');
    image.src = './img/icona-aggiungi-ingredienti-hovered.png';
})


element7.addEventListener('mouseleave', () => {
    const image = document.querySelector('#img-aggiungi-ingrediente');
    image.src = './img/icona-aggiungi-ingredienti-basic.png';
    element7.classList.remove('hover');
})
element7.addEventListener("click", function VisualizzaStatistiche(){
    window.location.replace("./associaingredienti.html");
});
const element8 = document.querySelector('#icona-logout');

element8.addEventListener('mouseenter', () => {
    element8.classList.add('hover'); 
    const image = document.querySelector('#img-logout');
    image.src = './img/icona-logout-hovered.png';
})


element8.addEventListener('mouseleave', () => {
    const image = document.querySelector('#img-logout');
    image.src = './img/icona-logout-basic.png';
    element8.classList.remove('hover');
})

//**Metodi hovered per la barra delle funzionalita [FINE] */

document.getElementById('icona-logout').onclick = function() {
    $('#staticBackdrop').modal('show');
    
    var avanti = document.getElementById('btn-conf');
    
    avanti.onclick = function() {
        document.cookie = "ruolo=; expires=Thu, 01 Jan 1970 00:00:00 UTC;";
        document.cookie = "email=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;";
        //document.cookie = "permessi=; expires=Thu, 01 Jan 1970 00:00:00 UTC;";

        window.location.replace('index.html');
     }
}



let urlParams = new URLSearchParams(window.location.search);
let valore1 = urlParams.get("val");

if(valore1 == 1) {
    let avviso = document.getElementById('avviso-rec');

    avviso.style.display = "block";
    
    $("#avviso-rec").fadeOut(9500);

   

}
/*METODO CHE CONTA QUANTE NUOVE NOTIFICHE IN ARRIVO CI SONO */
function getCookie(nomeCookie) {
    var name = nomeCookie + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }

}
window.onbeforeunload = function(event) {
    event.preventDefault();
  };
  window.onload = function(){
    let response;
    let request = new XMLHttpRequest();
    var emailUser =getCookie("email");
    
    emailUser = emailUser.substring(1, emailUser.length -1);
    request.open("POST", "http://87.3.142.174:8085/getNomeComponente/"+emailUser);
    request.setRequestHeader('Content-Type', 'application/json');
    request.send();
    request.onload = () => {

        if (request.status == 200) {
            response = request.responseText;
        
        document.getElementById("bentornato").innerHTML = "Bentornato,"+response;
    }
        }
 }