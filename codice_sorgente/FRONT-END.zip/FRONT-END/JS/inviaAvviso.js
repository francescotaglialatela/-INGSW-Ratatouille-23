var emailFound = [];


document.getElementById('back-arrow').onclick = function back() {
    $('#staticBackdrop').modal('show');

    var avanti = document.getElementById('btn-conf');

    avanti.onclick = function () {
      var ruolo=getCookie("ruolo");
      ruolo = ruolo.substring(1,ruolo.length -1);
        if(ruolo=="amministratore")
        window.location.replace("home-admin.html");
          if(ruolo=="supervisore")
          window.location.replace("home-supervisore.html");
     
    }
}

document.getElementById('btn-invia').onclick = function showPopUp() {
    $('#staticBackdrop').modal('show');

    var testo = document.getElementById('text-modal');
    var avanti = document.getElementById('btn-conf');

    var oggetto = document.getElementById('formGroupExampleInput').value;
    var testoBox = document.getElementById('text-box').value;



    if (oggetto == "" || testoBox == "") {

        testo.innerHTML = "Errore! Non è possibile inviare un messaggio senza oggetto o senza testo!"
        avanti.innerHTML = "Riprova"
    }
    else {
        testo.innerHTML = "Vuoi inviare questo messaggio ai membri del tuo staff? "
        avanti.innerHTML = "Conferma";

        /*TODO METODO CHE INVIA IL MESSAGGIO AL DATABASE*/

        avanti.onclick = function invia() {
            let response;
            let request = new XMLHttpRequest();
            request.open("POST", "http://87.3.142.174:8085/admin/service/sendMessage");
            request.setRequestHeader('Content-Type', 'application/json');
            var data = {};

            var emailUser =getCookie("email");
            emailUser = emailUser.substring(1, emailUser.length -1);
            
            
            data.destinatario = "nothing";
            data.mittente = emailUser;
            data.Oggetto_del_messaggio= oggetto;
            data.testo_del_messaggio = testoBox;

            request.send(JSON.stringify(data));

            request.onload = () => {

                if (request.status == 200) {
                    response = request.responseText;
                    

                    if (response == "true") {
                        var ruolo=getCookie("ruolo");
                        ruolo = ruolo.substring(1,ruolo.length -1);
                        
                        
                          if(ruolo=="amministratore")
                          window.location.replace("home-admin.html?val=1");
                            if(ruolo=="supervisore")
                            window.location.replace("home-supervisore.html?val=1");
                    }
                    else
                        console.log("Qualcosa è andato storto!");

                }
                else {
                    console.log("qualcosa è andato storto!")
                }
            }


        }


    }

}
  function getCookie(nomeCookie) {
    var name = nomeCookie + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }