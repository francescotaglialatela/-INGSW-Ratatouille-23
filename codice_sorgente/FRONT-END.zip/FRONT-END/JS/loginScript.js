function annulla() {
  let modal = document.getElementById("modalpassword");
  let modal2 = document.getElementById("modalcambiopassword");
  modal.classList.remove("show");
  modal.classList.remove("d-block");
  modal2.classList.remove("show");
  modal2.classList.remove("d-block");
}
function conferma() {
  let confirmPassword = $("#confirm-password").val();
  let password = $("#password").val();
  if (password != confirmPassword) {
    let alert = document.getElementsByClassName("alert alert-danger")[0];
    alert.style.display = "block";
    alert.innerHTML = "Password diverse";
    $(alert).fadeOut(4500);
  } else {
    if (password == "" || !password.match(/^(?=.*[A-Za-z]|[\d]|[@$!%*#?&]).{5,}$/) || password.length < 5) {
      let alert = document.getElementsByClassName("alert alert-danger")[0];
      alert.style.display = "block";
      alert.innerHTML = "Password non valida";
      $(alert).fadeOut(4500);
    } else {
      let request = new XMLHttpRequest();
      var email = document.getElementById('formGroupExampleInput').value;
      request.open("POST", "http://87.3.142.174:8085/update_password/" + email + "/" + password);
      request.send();
      request.onload = () => {
        
        if (request.status == 200) {
          result = request.responseText;
          $("#btn-annullapopup").hide();
          document.getElementById("btn-conferma").style.display = "none";
          let alert = document.getElementsByClassName("alert alert-success")[0];
          alert.style.display = "block";
          alert.innerHTML = "Password inserita correttamente";
          $(alert).fadeOut(4500);
          /**MODIFICHE NUOVE */
          var date = new Date();
          var minutes = 60 * 24 * 365; // 1 hour
          date.setTime(date.getTime() + (minutes * 60 * 1000));
          document.cookie = "email=\"" + email + "\"; expires=" + date.toUTCString();

          var text = document.getElementById('testo-pop-up');
                var avanti = document.getElementById('btn-avanti');

                text.innerHTML = "Login avvenuto con successo, verrai reinderizzato alla pagina home!";
                avanti.style.display = "none";

                document.getElementById('btn-annulla').style.display = "none";

                let modal = document.getElementById("staticBackdrop");
                
                modal.classList.add("show");
                modal.classList.add("d-block");

        
          getRole(email);

          
        } else {
          let alert = document.getElementsByClassName("alert alert-danger")[0];
          alert.style.display = "block";
          alert.innerHTML = "Errore,ci scusiamo per il disagio.Riprovi";
          $(alert).fadeOut(4500);
        }
      }
    }
   
  }
 
}
function confermaCambioPassowrd() {
  let confirmPassword = $("#confirm-passwordCp").val();
  let password = $("#passwordCp").val();
  if (password != confirmPassword) {
    let alert = document.getElementsByClassName("alert alert-danger")[0];
    alert.style.display = "block";
    alert.innerHTML = "Password diverse";
    $(alert).fadeOut(4500);
  } else {
    
    if (password == "" || !password.match(/^(?=.*[A-Za-z]|[\d]|[@$!%*#?&]).{5,}$/) || password.length < 5) {
      
      let alert = document.getElementsByClassName("alert alert-danger")[1];
      alert.style.display = "block";
      alert.innerHTML = "Password non valida";
      $(alert).fadeOut(4500);
    } else {
      let request = new XMLHttpRequest();
      var email = document.getElementById('formGroupExampleInput').value;
      request.open("POST", "http://87.3.142.174:8085/update_password/" + email + "/" + password);
      request.send();
      request.onload = () => {
       
        if (request.status == 200) {
          result = request.responseText;
          $("#btn-annullapopupCp").hide();
          document.getElementById("btn-confermaCp").style.display = "none";
          let alert = document.getElementsByClassName("alert alert-success")[1];
          alert.style.display = "block";
          alert.innerHTML = "Password inserita correttamente";
          $(alert).fadeOut(4500);
          setTimeout(function () {
            $("#modalcambiopassword").modal("hide");
            window.location.replace('./home-admin.html');
          }, 4500);
        } else {
          let alert = document.getElementsByClassName("alert alert-danger")[0];
          alert.style.display = "block";
          alert.innerHTML = "Errore,ci scusiamo per il disagio.Riprovi";
          $(alert).fadeOut(4500);
        }
      }
    }

  }

}
document.getElementById('btn-login').onclick = function () {
  var email = document.getElementById('formGroupExampleInput').value;
  var password = document.getElementById('formGroupExampleInput2').value;

  if (email == "" || password == "") {
    var text = document.getElementById('testo-pop-up');
    var avanti = document.getElementById('btn-avanti');


    text.innerHTML = "Per favore, inserisci i campi vuoti!";
    avanti.innerHTML = "Riprova";
    let modal = document.getElementById("staticBackdrop");
    modal.classList.add("show");
    modal.classList.add("d-block");
    avanti.onclick = function () {
      modal.classList.remove("show");
      modal.classList.remove("d-block");
    }
    if (email == "") {
      let doc1 = document.getElementById("formGroupExampleInput");
      doc1.style.borderBottomColor = "red";
      doc1.style.color = "red";
    } else {
      let doc1 = document.getElementById("formGroupExampleInput");
      doc1.style.borderBottomColor = "black";
      doc1.style.color = "black";
    }
    if (password == "") {
      let doc1 = document.getElementById("formGroupExampleInput2");
      doc1.style.borderBottomColor = "red";
      doc1.style.color = "red";
    } else {
      let doc1 = document.getElementById("formGroupExampleInput2");
      doc1.style.borderBottomColor = "black";
      doc1.style.color = "black";
    }

  }
  else {

    let request = new XMLHttpRequest();
    request.open("GET", "http://87.3.142.174:8085/login/" + email + "/" + password);
    request.send();
    request.onload = () => {
      
      if (request.status == 200) {
       
        result = request.responseText;

        if (result == "true") {
          request.open("GET", "http://87.3.142.174:8085/primo_accesso/" + email);
          request.send();
          request.onload = () => {
           
            if (request.status == 200) {
              
              result = request.responseText;
            
              if (result == "1") {
                

                var date = new Date();
                var minutes = 60 * 24 * 365; // 1 hour
                date.setTime(date.getTime() + (minutes * 60 * 1000));
                document.cookie = "email=\"" + email + "\"; expires=" + date.toUTCString();

               
                
                var text = document.getElementById('testo-pop-up');
                var avanti = document.getElementById('btn-avanti');

                text.innerHTML = "Login avvenuto con successo, verrai reinderizzato alla pagina home!";
                avanti.style.display = "none";

                document.getElementById('btn-annulla').style.display = "none";

                let modal = document.getElementById("staticBackdrop");
                
                modal.classList.add("show");
                modal.classList.add("d-block");

                getRole(email);

                let doc1 = document.getElementById("formGroupExampleInput");
                doc1.style.borderBottomColor = "green";
                doc1.style.color = "green";

                let doc2 = document.getElementById("formGroupExampleInput2")
                doc2.style.borderBottomColor = "green";
                doc2.style.color = "green";
              } else {
                if (result == "0") {
                  
                  let modal = document.getElementById("modalpassword");
                  modal.classList.add("show");
                  modal.classList.add("d-block");
                } else {
                  let modal = document.getElementById("modalcambiopassword");
                  modal.classList.add("show");
                  modal.classList.add("d-block");
                }
              }

            }

          }



        }
        else {
          request.open("GET", "http://87.3.142.174:8085/verifica_email/" + email);
          request.send();
          request.onload = () => {
            
            if (request.status == 200) {
              result = request.responseText;

              if (result == "false") {
                var text = document.getElementById('testo-pop-up');
                var avanti = document.getElementById('btn-avanti');

                text.innerHTML = "Attenzione, email non corretta!";
                avanti.innerHTML = "Riprova";
                let doc1 = document.getElementById("formGroupExampleInput");
                doc1.style.borderBottomColor = "red";
                doc1.style.color = "darkred";
                let doc2 = document.getElementById("formGroupExampleInput2")
                doc2.style.borderBottomColor = "black";
                doc2.style.color = "black";
              } else {
                let doc1 = document.getElementById("formGroupExampleInput");
                doc1.style.borderBottomColor = "black";
                doc1.style.color = "black";
                var text = document.getElementById('testo-pop-up');
                var avanti = document.getElementById('btn-avanti');

                text.innerHTML = "Attenzione, password non corretta!";
                avanti.innerHTML = "Riprova";
                let doc2 = document.getElementById("formGroupExampleInput2")
                doc2.style.borderBottomColor = "red";
                doc2.style.color = "darkred";
              }
              let modal = document.getElementById("staticBackdrop");
              modal.classList.add("show");
              modal.classList.add("d-block");

              avanti.onclick = function () {
                modal.classList.remove("show");
                modal.classList.remove("d-block");
              }



            } else {
              var text = document.getElementById('testo-pop-up');
              var avanti = document.getElementById('btn-avanti');

              text.innerHTML = "C è stato un errrore ci scusiamo per l inconveniente!";
              avanti.innerHTML = "Riprova";
              let modal = document.getElementById("staticBackdrop");
              modal.classList.add("show");
              modal.classList.add("d-block");

              avanti.onclick = function () {
                modal.classList.remove("show");
                modal.classList.remove("d-block");
              }
            }
          }


        }
      }
      else {
        console.log("ERRORE");
      }


    }

  }

}

function getRole(email) {
 
  let request = new XMLHttpRequest();
  request.open("GET", "http://87.3.142.174:8085/getRuolo/" + email);
  request.send();
  request.onload = () => {
    if (request.status = 200) {
      result = request.responseText;
      var date = new Date();
      var minutes = 60 * 24 * 365; // 1 hour
      date.setTime(date.getTime() + (minutes * 60 * 1000));
      document.cookie = "ruolo=\"" + result + "\"; expires=" + date.toUTCString();

      var ruolo = result;

      if (ruolo == "amministratore")
        window.location.replace("home-admin.html");
      if (ruolo == "supervisore")
        window.location.replace("home-supervisore.html");
      if (ruolo == "addetto cucina")
        window.location.replace("home-AddettoCucina.html");
      if (ruolo == "addetto sala")
        window.location.replace("home-AddettoSala.html");
      //window.location.replace('../home-admin.html');


    }
  }
}


function getCookie(nomeCookie) {
  var name = nomeCookie + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(';');
  for (var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}
window.onbeforeunload = function (event) {
  event.preventDefault();
};