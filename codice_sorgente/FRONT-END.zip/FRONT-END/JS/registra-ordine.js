
var idCount = 0;

function aggiungiOrdine(nomePiatto, costo, quantita) {


    // Creazione della nuova voce della lista
    var list = document.getElementById("lista-mail");

    // Crea la tabella
    var table = document.createElement("table");
    table.setAttribute("style", "border-collapse: collapse; width: 102.778%; height: 38px;");

    //ID TABELLA
    table.id = idCount;
   
    idCount = idCount + 1;

    // Crea il corpo della tabella
    var tbody = document.createElement("tbody");
    table.appendChild(tbody);

    // Crea la prima riga
    var tr1 = document.createElement("tr");
    tr1.setAttribute("style", "height: 22px;");
    tbody.appendChild(tr1);

    // Crea la prima cella della prima riga
    var td1 = document.createElement("td");
    td1.setAttribute("style", "width: 24.8112%; height: 28px;");
    td1.innerHTML = "<b>" + nomePiatto + "<b>";
    tr1.appendChild(td1);

    //[ID NOME PIATTO]
    td1.id = idCount;
    idCount = idCount + 1;

    // Crea la seconda cella della prima riga
    var td2 = document.createElement("td");
    td2.setAttribute("style", "width: 26.2358%; height: 28px;");
    var img = document.createElement("img");
    img.src = "./img/bidone.jpg";
    img.setAttribute("style", "width: 30px; height: 30px;");
    img.style.cursor = "pointer";
    td2.appendChild(img);
    tr1.appendChild(td2);

    //[ID BOTTONE CESTINO]
    img.id = idCount;
    idCount = idCount + 1;

    img.addEventListener("click", function () {
        //prende l'id della tabella e la elimina dalla lista mostrando un avviso prima
        //alert("Ti mostro l'id della tabella dove sto bro:" + table.id);
        var testoModal = document.getElementById('text-modal');
        var avantiModal = document.getElementById('btn-conf');
        var nomePiatto = td1.innerHTML;

        testoModal.innerHTML = "Vuoi rimuovere: " + nomePiatto + " dall'ordinazione corrente?";

        $('#staticBackdrop').modal('show');

        avantiModal.onclick = function () {


           
            if (table.id == 0 && idCount == 6) {
                
                idCount = 0;
            }

            var parser = new DOMParser();
            var htmlDoc = parser.parseFromString(nomePiatto, "text/html");
            var b = htmlDoc.getElementsByTagName("b")[0];
            var testo = b.textContent.trim();

            let index = piattiSelezionati.indexOf(testo.toLowerCase());
            if (index > -1) {
                piattiSelezionati.splice(index, 1);
            }

            //piattiSelezionati.pop("pasta e patate");
            idCount = idCount - table.id;
            
            list.removeChild(table);
            list.removeChild(newLine);


            let i = 0;
            for (i = 0; i < piattiSelezionati.length; i++);

            if (i == 0)
                idCount = 0;


            $('#staticBackdrop').modal('hide');
        }
    })

    // Crea la terza cella della prima riga
    var td3 = document.createElement("td");
    td3.setAttribute("style", "width: 22.3386%; height: 28px;");
    td3.innerHTML = "&nbsp;";
    tr1.appendChild(td3);

    // Crea la quarta cella della prima riga
    var td4 = document.createElement("td");
    td4.setAttribute("style", "width: 5.74369%; height: 28px;");
    td4.innerHTML = "&nbsp;";
    tr1.appendChild(td4);

    // Crea la quinta cella della prima riga
    var td5 = document.createElement("td");
    td5.setAttribute("style", "width: 8.8622%; height: 28px;");
    var button1 = document.createElement("button");
    button1.setAttribute("class", "btn btn-outline-primary");
    button1.setAttribute("style", "border-radius: 100%;");
    button1.innerHTML = "+";
    td5.appendChild(button1);
    tr1.appendChild(td5);

    //[ID BOTTONE AGGIUNGI]
    button1.id = idCount;
    idCount = idCount + 1;


    // Crea la seconda riga
    var tr2 = document.createElement("tr");
    tr2.setAttribute("style", "height: 22px;");
    tbody.appendChild(tr2);

    // Crea la prima cella della seconda riga
    var td6 = document.createElement("td");
    td6.setAttribute("style", "width: 24.8112%; height: 10px;");
    td6.innerHTML = "QUANTITA: " + quantita + " - PREZZO:" + costo + "€";
    tr2.appendChild(td6);

    //[ID QUANTITA E PREZZO]
    td6.id = idCount;
    idCount = idCount + 1;

    /**FUNZIONE PER AGGIUNGERE UNA QUANTITA INIZIO*/
    button1.addEventListener("click", function () {
        var testo = document.getElementById('text');
        var avanti = document.getElementById('bottone-avanti');


        testo.innerHTML = "Inserisci la quantita da aggiungere."
        $('#Modal').modal('show');

        avanti.onclick = function () {
            var quantitaDigitata = document.getElementById('insertQuantita');
            var closeConX = document.getElementById('closeModal');
            var bottoneChiudi = document.getElementById('chiudiModal');

            let duration = "0.5s";
            let iteration = "1";


            var errore = document.getElementById('errore');
            // l'argomento è un numero?
          
            if (isNaN(quantitaDigitata.value)) {

                //quantitaDigitata.style.animation = "vibrate "+duration+" ease-in-out "+iteration;
                quantitaDigitata.style.borderColor = "red";
                errore.innerHTML = "Quello che hai inserito non è un numero, per favore inserisci un numero intero!";
            }
            // se si, è un numero intero?
            
            if (quantitaDigitata.value==""||quantitaDigitata.value<=0) {

                //quantitaDigitata.style.animation = "vibrate "+duration+" ease-in-out "+iteration;
                quantitaDigitata.style.borderColor = "red";
                errore.innerHTML = "Quello che hai inserito non è un numero intero, per favore riprova!";



            }
            // se si, è un naturale maggiore di 0?
            if (quantitaDigitata.value <= 0) {

                //quantitaDigitata.style.animation = "vibrate "+duration+" ease-in-out "+iteration;
                quantitaDigitata.style.borderColor = "red";
                errore.innerHTML = "Quello che hai inserito è un numero minore di zero, per favore digita un numero maggiore di zero!"
            } else {
                quantita = parseInt(quantitaDigitata.value) + parseInt(quantita);
                td6.innerHTML = "QUANTITA: " + quantita + " - PREZZO:" + costo + "€";
                quantitaDigitata.innerText = "";
                quantitaDigitata.style.borderColor = "black";
                errore.innerHTML = "";
                quantitaDigitata.value = "";
                $('#Modal').modal('hide');
            }

            closeConX.onclick = function () {
                quantitaDigitata.innerText = "";
                quantitaDigitata.style.borderColor = "black";
                errore.innerHTML = "";
                quantitaDigitata.value = "";
            }

            bottoneChiudi.onclick = function () {
                quantitaDigitata.innerText = "";
                quantitaDigitata.style.borderColor = "black";
                errore.innerHTML = "";
                quantitaDigitata.value = "";
            }

        }
    })
    /**FUNZIONE PER AGGIUNGERE UNA QUANTITA FINE */


    // Crea la seconda cella della seconda riga
    var td7 = document.createElement("td");
    td7.setAttribute("style", "width: 26.2358%; height: 10px;");
    td7.innerHTML = " ";
    tr2.appendChild(td7);

    // Crea la terza cella della seconda riga
    var td8 = document.createElement("td");
    td8.setAttribute("style", "width: 22.3386%; height: 10px;");
    td8.innerHTML = " ";
    tr2.appendChild(td8);
    // Crea la quarta cella della seconda riga
    var td9 = document.createElement("td");
    td9.setAttribute("style", "width: 5.74369%; height: 10px;");
    td9.innerHTML = " ";
    tr2.appendChild(td9);

    // Crea la quinta cella della seconda riga
    var td10 = document.createElement("td");
    td10.setAttribute("style", "width: 8.8622%; height: 10px;");
    var button2 = document.createElement("button");
    button2.setAttribute("class", "btn btn-outline-primary");
    button2.setAttribute("style", "border-radius: 100%; font-size: 17; height: 37px; width: 37px;");
    button2.innerHTML = "-";
    td10.appendChild(button2);
    tr2.appendChild(td10);

    //[ID BOTTONE RIMUOVI QUANTITA]
    button2.id = idCount;
    idCount = idCount + 1;


    /**FUNZIONE PER RIMUOVERE UNA QUANTITA */
    button2.onclick = function () {
        var testo = document.getElementById('text');
        var avanti = document.getElementById('bottone-avanti');
        var quantitaDigitata = document.getElementById('insertQuantita');
        quantitaDigitata.value="";
        testo.innerHTML = "Inserisci la quantita da rimuovere."
        $('#Modal').modal('show');

        avanti.onclick = function () {
            var quantitaDigitata = document.getElementById('insertQuantita');
            var closeConX = document.getElementById('closeModal');
            var bottoneChiudi = document.getElementById('chiudiModal');

            let duration = "0.5s";
            let iteration = "1";

            var errore = document.getElementById('errore');
            // l'argomento è un numero?
            if (isNaN(quantitaDigitata.value)) {

                //quantitaDigitata.style.animation = "vibrate "+duration+" ease-in-out "+iteration;
                quantitaDigitata.style.borderColor = "red";
                errore.innerHTML = "Quello che hai inserito non è un numero, per favore inserisci un numero intero!";
            }
            // se si, è un numero intero?

            if (parseInt(quantitaDigitata.value) != quantitaDigitata.value) {

                //quantitaDigitata.style.animation = "vibrate "+duration+" ease-in-out "+iteration;
                quantitaDigitata.style.borderColor = "red";
                errore.innerHTML = "Quello che hai inserito non è un numero intero, per favore riprova!";
            }

            // se si, è un naturale maggiore di 0?
            if (quantitaDigitata.value <= 0) {

                //quantitaDigitata.style.animation = "vibrate "+duration+" ease-in-out "+iteration;
                quantitaDigitata.style.borderColor = "red";
                errore.innerHTML = "Quello che hai inserito è un numero minore di zero, per favore digita un numero maggiore di zero!"
            } else {
                quantita = parseInt(quantita) - parseInt(quantitaDigitata.value);
               if (parseInt(quantita) <= 0) {
                    
                var nomePiatto = td1.innerHTML;

               
                if (table.id == 0 && idCount == 6) {
                    
                    idCount = 0;
                }

                var parser = new DOMParser();
                var htmlDoc = parser.parseFromString(nomePiatto, "text/html");
                var b = htmlDoc.getElementsByTagName("b")[0];
                var testo = b.textContent.trim();

                let index = piattiSelezionati.indexOf(testo.toLowerCase());
                if (index > -1) {
                    piattiSelezionati.splice(index, 1);
                }

                //piattiSelezionati.pop("pasta e patate");
                idCount = idCount - table.id;
               
                list.removeChild(table);
                list.removeChild(newLine);


                let i = 0;
                for (i = 0; i < piattiSelezionati.length; i++);

                if (i == 0)
                    idCount = 0;


                $('#Modal').modal('hide');
            } else {
                td6.innerHTML = "QUANTITA: " + quantita + " - PREZZO:" + costo + "€";
                quantitaDigitata.innerText = "";
                quantitaDigitata.style.borderColor = "black";
                errore.innerHTML = "";
                quantitaDigitata.value = "";
                $('#Modal').modal('hide');  
            }
               
            }

            closeConX.onclick = function () {
                quantitaDigitata.innerText = "";
                quantitaDigitata.style.borderColor = "black";
                errore.innerHTML = "";
                quantitaDigitata.value = "";
            }

            bottoneChiudi.onclick = function () {
                quantitaDigitata.innerText = "";
                quantitaDigitata.style.borderColor = "black";
                errore.innerHTML = "";
                quantitaDigitata.value = "";
            }
        }
    }
    /**FINE FUNZIONE*/

    var newLine = document.createElement("hr");
    newLine.style.width = "100%";
    newLine.style.border = "0";
    newLine.style.borderTop = "2px solid #000000";

    // Aggiungi la tabella alla lista

    list.appendChild(table);
    list.appendChild(newLine);
}


function checkNumeroTavolo(numeroTavolo) {

    var alert = document.getElementById('alert-dangerous');

    // l'argomento è un numero?
    if (isNaN(numeroTavolo)) {
        alert.innerHTML = "ATTENZIONE! Non hai inserito un numero come tavolo, per favore inserisci un numero intero.";
        alert.style.display = "block";

        $("#alert-dangerous").fadeOut(8500);
        return false;

    }
    // se si, è un numero intero?

    if (parseInt(numeroTavolo) != numeroTavolo) {
        alert.innerHTML = "ATTENZIONE! Non hai inserito un numero intero, per favore riprova inserendo un numero intero.";
        alert.style.display = "block";

        $("#alert-dangerous").fadeOut(8500);
        return false;
    }

    // se si, è un naturale maggiore di 0?
    if (numeroTavolo <= 0) {
        alert.innerHTML = "ATTENZIONE! Non esiste un tavolo con numero 0 o negativo, per favore inserisci un numero intero maggiore di 0.";
        alert.style.display = "block";

        $("#alert-dangerous").fadeOut(8500);
        return false;

    }
    else
        return true;
}

function confermaOrdine() {

    var prezzo;
    var idOrdine;
    var numeroTavolo;
    var tavoloVerificato;
    var myEmail;
    var tavolo;
    let j = 0;

    for (let i = 0; i < idCount; i = i + 6) {

        const table = document.getElementsByTagName("table")[j]
        const tdElements = table.getElementsByTagName("td");
        elemento1 = tdElements[0];  //nome piatto
        elemento2 = tdElements[5];  //quantita
        const b = elemento1.getElementsByTagName("b")[0];
        var nomepiatto = b.textContent;
        j++;
        quantita = parseInt(elemento2.innerHTML.split("QUANTITA: ")[1].split(" -")[0]);
        var parti = elemento2.innerHTML.split(" - ");
        prezzo = parti[1]
        prezzo = prezzo.replace("€", "")
        prezzo = parseInt(prezzo.split(":")[1])


        idOrdine = document.getElementById('num-ordine');
        idOrdine = parseInt(idOrdine.innerHTML.split("ORDINAZIONE NUMERO: ")[1]);
        numeroTavolo = parseInt(document.getElementById('txt-tavolo').value);
        tavoloVerificato = checkNumeroTavolo(numeroTavolo);


     

        tavolo = parseInt(numeroTavolo);
        myEmail = getCookie("email");

        myEmail = myEmail.substring(1, myEmail.length - 1);

        var numOrdine = document.getElementById('num-ordine');
        var parti = numOrdine.innerHTML.split(": ");
        var numeroOrdinazione = parseInt(parti[1]);



        var data = {};
        data.numeroOrdine = numeroOrdinazione;
        data.numeroTavolo = tavolo;
        data.prezzo = prezzo;
        data.elementoMenu = nomepiatto;
        data.quantita = quantita;
        data.registratore = myEmail;

     

        if (tavoloVerificato == false) {
        } else
            registraOrdine(data);

    }

}

function registraOrdine(data) {
    /**CHIAMATA REST PER INSERIRE L'ORDINE*/
    
    let request = new XMLHttpRequest();
    request.open("POST", "http://87.3.142.174:8085/addettoSala/service/sendOrdine");
    request.setRequestHeader('Content-Type', 'application/json');
    request.send(JSON.stringify(data));

    request.onload = () => {

        if (request.status == 200) {
            if (request.responseText == "true") {
                //da cambiare la location
                window.location.replace("home-AddettoSala.html?val=2");
            }
            else {
                alert = document.getElementById('alert-dangerous');
                alert.innerHTML = "ATTENZIONE! L'invio dell'ordine non è andato a buon fine ricontrolla l'ordinazione!";
                alert.style.display = "block";

                $("#alert-dangerous").fadeOut(8500);
            }
        }
    }
}

window.onload = function assegnaNumeroOrdine() {
    let request = new XMLHttpRequest();
    request.open("GET", "http://87.3.142.174:8085/getNumeroOrdine");
    request.send();
    request.onload = () => {
        if (request.status == 200) {

            var numeroOrdine = document.getElementById('num-ordine');
            numeroOrdine.innerHTML = numeroOrdine.innerHTML + request.responseText;
        }
    }
}


function getCookie(nomeCookie) {
    var name = nomeCookie + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }

}


document.getElementById('conf').onclick = function () {
    var listaMail = document.getElementById("lista-mail");

    if (listaMail.children.length === 0) {
        var testoModal = document.getElementById('text-modal');
        var avantiModal = document.getElementById('btn-conf');
        var chiudiModal = document.getElementById('btn-ann');

        testoModal.innerHTML = "L'ordine che stai cercando di registare non contiene elementi del menù, prova ad aggiungere qualche piatto cliccando sul bottone <b>AGGIUNGI ALL'ORDINE</b>";
        avantiModal.style.display = "none";
        chiudiModal.innerHTML = "Chiudi"

        $('#staticBackdrop').modal('show');
    } else {
        confermaOrdine();
    }
}


/**FUNZIONE DI RICERCA */
function searchTables() {
    // Get the input value
    
    var input = document.getElementById("searchInput").value.toUpperCase();
    // Get the list of tables
    var tables = document.getElementById("lista");
    // Loop through all the tables
   
    for (var i = 0; i < tables.children.length; i++) {

        // Get the current table
        var table = tables.children[i];

        var index = table.textContent.indexOf("Descrizione");
        var sottostringa = table.textContent.substring(0, index); 
       
        // Get the element with id=1 in the current table
       

        // Get the value of the element
        var elementValue =sottostringa.toUpperCase();

        // Check if the element value contains the input value
        if (elementValue.indexOf(input) > -1) {
            // The table matches the search
            table.style.display = "";
        } else {
            // The table does not match the search
            table.style.display = "none";
        }
    }
}

function searchTables2() {
    // Get the input value
    
    var input = document.getElementById("searchInput2").value.toUpperCase();
    // Get the list of tables
    var tables = document.getElementById("lista-mail");
    // Loop through all the tables
    
    for (var i = 0; i < tables.children.length; i++) {

        // Get the current table
        var table = tables.children[i];
      
        
        var index = table.textContent.indexOf("+"); var sottostringa = table.textContent.substring(0, index);
         sottostringa = sottostringa.trim(); 
        

        
        // Get the element with id=1 in the current table
       

        // Get the value of the element
        var elementValue =sottostringa.toUpperCase();

        // Check if the element value contains the input value
        if (elementValue.indexOf(input) > -1) {
            // The table matches the search
            table.style.display = "";
        } else {
            // The table does not match the search
            table.style.display = "none";
        }
    }
}
document.getElementById("freccia-back").onclick = function () {

    var listaMail = document.getElementById("lista-mail");

    if (listaMail.children.length === 0) {
        location.href = 'home-AddettoSala.html';
        
    } else {

        var testoModal = document.getElementById('text-modal');
        var avantiModal = document.getElementById('btn-conf');
        var chiudiModal = document.getElementById('btn-ann');
        chiudiModal.innerHTML = "Annulla";
        avantiModal.style.display = "block";

        testoModal.innerHTML = "Sei sicuro di voler eliminare l'ordine che stai creando e di voler tornare al menu principale?";
        $('#staticBackdrop').modal('show');

        avantiModal.onclick = function() {
            location.href = 'home-AddettoSala.html';
        }
    }

}
