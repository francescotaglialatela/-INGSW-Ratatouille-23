var form = document.getElementById("formricerca");
form.addEventListener("submit", function (event) {
    event.preventDefault();
});





