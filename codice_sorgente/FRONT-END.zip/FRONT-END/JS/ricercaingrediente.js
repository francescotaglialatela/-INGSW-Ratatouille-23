var form = document.getElementById("formricercaingrediente");
form.addEventListener("submit", function (event) {
    event.preventDefault();
    
});


