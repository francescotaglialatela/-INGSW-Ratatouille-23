var form = document.getElementById("formricercamenu");
form.addEventListener("submit", function (event) {
  event.preventDefault();
  
});
document.getElementById("ricercamenu").addEventListener("input", filterChildren);

function filterChildren() {
  var input, filter, contenitore, child;
  input = document.getElementById("ricercamenu");
  filter = input.value.toUpperCase();
  contenitore = document.getElementById("listaelementimenu");
  child = contenitore.children;
  for (var i = 0; i < child.length; i++) {
    var txtValue = child[i].textContent || child[i].innerText;
    let pos = txtValue.indexOf("Descrizione");
    txtValue = txtValue.substring(0, pos);
    console.log(txtValue);
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      child[i].style.display = "";
    } else {
      child[i].style.display = "none";
    }
  }
}
