var form = document.getElementById("formricercaaggiunginuovoprodotto");

form.addEventListener("submit", function (event) {
    // Prevent the default action of the submit event (which is to submit the form)
    event.preventDefault();
    // Get the value of the input field
    var inputValue = document.getElementById("ricercaopenfood").value;
    if(inputValue==""){
        const popupinputvuoto = document.getElementById("inputVuotoricercaopenfood");
        popupinputvuoto.style.display="block";
        setTimeout(function(){
            popupinputvuoto.style.display="none";
          }, 3000);
    }else{
       
        const data = { ricerca: inputValue };
       
    
        const popup = document.getElementById('popup_openfood_prodotto');
        const close2 = document.getElementById('closericercaopenfood');
    
        popup.style.display = 'block';
        button.style.pointerEvents = "none";
        close2.addEventListener('click', () => {
            popup.style.display = 'none';
            button.style.pointerEvents = "auto";
        });
    
    
    
        var request = new XMLHttpRequest();
        request.open("POST", "http://87.3.142.174:8085/srcopenfood", true);
        request.setRequestHeader('Content-Type', 'application/json');
        request.onreadystatechange = function () {
            if (request.readyState === 4 && request.status === 200) {
                var i = 0;
                var prodotti = JSON.parse(request.responseText);
                var contenitore = document.getElementById('listaopenfood');
                contenitore.innerHTML="";
                for (var oggetto of prodotti) {
                    var div = document.createElement('div');
                    div.id = ('elemento' + oggetto.codice_a_barre)
                    
                    var strnome = oggetto.nome;
                    strnome = strnome.substring(0, 30);
                    var stringredienti = oggetto.ingredienti;
                    stringredienti = stringredienti.substring(0, 50);
                    if (oggetto.nome.length > 30) {
                        strnome = strnome + '...';
                    }
                    if (oggetto.ingredienti.length > 50) {
                        stringredienti = stringredienti + '...';
                    }
                    div.innerHTML = '<table style="margin-top:30px;border-collapse: collapse; width: 100%;" border="0"><tbody><tr><td style="width: 30.3152%;"><img src="' + oggetto.urlfoto + '" style="width:150px;height:150px;margin:20px;margin-top:60px"></td><td style="width: 30.3152%;"><p style="text-align: left;"><strong>'+strnome+'</strong></p><p style="text-align: left;"><strong>Ingredienti</strong></p><p style="text-align: left;"><em  style="font-size:20px">' + stringredienti + '</em></p><p style="text-align: left;">Allergeni: '+oggetto.allergeni+'</p></td><td style="width: 30.3218%;"><button type="button" class="btn btn-outline-primary btn-lg" style="margin-top:30px"; id="seleziona' + oggetto.codice_a_barre + '", onclick="selezionaProdotto(this)"><b>SELEZIONA</b></button></td></tbody></table>';
                    contenitore.appendChild(div);
                    i++;
                }
            }
        };
        request.send(JSON.stringify(data));
    }

});
