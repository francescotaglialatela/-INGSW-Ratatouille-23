function mostraPopupback(){
  const modal = document.createElement('div');
  modal.classList.add('modal', 'fade');
  modal.setAttribute('id', 'staticBackdrop');
  modal.setAttribute('data-bs-backdrop', 'static');
  modal.setAttribute('data-bs-keyboard', 'false');
  modal.setAttribute('tabindex', '-1');
  modal.setAttribute('aria-labelledby', 'staticBackdropLabel');
  modal.setAttribute('aria-hidden', 'true');
  
  const dialog = document.createElement('div');
  dialog.classList.add('modal-dialog', 'modal-dialog-centered');
  
  const content = document.createElement('div');
  content.classList.add('modal-content');
  content.setAttribute('style', 'border-radius: 41px;');
  
  const header = document.createElement('div');
  header.classList.add('modal-header');
  
  const title = document.createElement('h1');
  title.classList.add('modal-title', 'fs-5');
  title.setAttribute('id', 'staticBackdropLabel');
  title.innerHTML = 'Avviso';
  
  const body = document.createElement('div');
  body.classList.add('modal-body');
  
  const text = document.createElement('p');
  text.setAttribute('id', 'testo-pop-up');
  text.innerHTML = 'Sei sicuro di voler annullare l operazione?';
  const button_ann = document.createElement('button');
  button_ann.type = 'button';
  button_ann.classList.add('btn', 'btnannullaPopUp');
  button_ann.setAttribute('style', 'border-radius: 61px;');
  button_ann.innerHTML = 'NO';
  const button_conferma = document.createElement('button');
  button_conferma.type = 'button';
  button_conferma.classList.add('btn', 'btnconfermaPopUp');
  button_conferma.setAttribute('style', 'border-radius: 61px;');
  button_conferma.innerHTML = 'SI';
  button_ann.style.marginRight = '166px';
  
  const footer = document.createElement('div');
  footer.classList.add('modal-footer');
  button_ann.addEventListener('click', function() {
    // Codice per rimuovere il mock-up qui
    $(modal).modal('hide');
      
  
  });
  
  button_conferma.addEventListener('click', function(){
    //aggiunge che ritona alla home html
    window.location.assign("personalizzazione.html");
    
  });
  
  
  // Appendi gli elementi l'uno all'altro
  modal.appendChild(dialog);
  dialog.appendChild(content);
  content.appendChild(header);
  header.appendChild(title);
  content.appendChild(body);
  body.appendChild(text);
  content.appendChild(footer);
  footer.appendChild(button_ann);
  footer.appendChild(button_conferma);
  
  document.body.appendChild(modal);
  $(modal).modal('show');
  
  }


document.getElementById('home').onmouseover =  function () {
       
    this.setAttribute("src", "./img/home-hovered.png")
}

document.getElementById('home').onmouseout =  function () {

this.setAttribute("src", "./img/home-basic.png")
}
function mostraPopupHome(){
  const modal = document.createElement('div');
  modal.classList.add('modal', 'fade');
  modal.setAttribute('id', 'staticBackdrop');
  modal.setAttribute('data-bs-backdrop', 'static');
  modal.setAttribute('data-bs-keyboard', 'false');
  modal.setAttribute('tabindex', '-1');
  modal.setAttribute('aria-labelledby', 'staticBackdropLabel');
  modal.setAttribute('aria-hidden', 'true');
  
  const dialog = document.createElement('div');
  dialog.classList.add('modal-dialog', 'modal-dialog-centered');
  
  const content = document.createElement('div');
  content.classList.add('modal-content');
  content.setAttribute('style', 'border-radius: 41px;');
  
  const header = document.createElement('div');
  header.classList.add('modal-header');
  
  const title = document.createElement('h1');
  title.classList.add('modal-title', 'fs-5');
  title.setAttribute('id', 'staticBackdropLabel');
  title.innerHTML = 'Avviso';
  
  const body = document.createElement('div');
  body.classList.add('modal-body');
  
  const text = document.createElement('p');
  text.setAttribute('id', 'testo-pop-up');
  text.innerHTML = 'Le modifiche correnti verranno annullate.Sei sicuro di voler tornare alla Home?';
  const button_ann = document.createElement('button');
  button_ann.type = 'button';
  button_ann.classList.add('btn', 'btnannullaPopUp');
  button_ann.setAttribute('style', 'border-radius: 61px;');
  button_ann.innerHTML = 'NO';
  const button_conferma = document.createElement('button');
  button_conferma.type = 'button';
  button_conferma.classList.add('btn', 'btnconfermaPopUp');
  button_conferma.setAttribute('style', 'border-radius: 61px;color:white');
  button_conferma.innerHTML = 'SI';
  button_ann.style.marginRight = '166px';
  
  const footer = document.createElement('div');
  footer.classList.add('modal-footer');
  button_ann.addEventListener('click', function() {
    // Codice per rimuovere il mock-up qui
    $(modal).modal('hide');
      
  
  });
  
  button_conferma.addEventListener('click', function(){
    //aggiunge che ritona alla home html
    // a seconda dell utente deve tornare alla home
    //window.location.assign("personalizzazione.html");
    var ruolo=getCookie("ruolo");
      ruolo = ruolo.substring(1,ruolo.length -1);
      
      
        if(ruolo=="amministratore")
        window.location.replace("home-admin.html");
          if(ruolo=="supervisore")
          window.location.replace("home-supervisore.html");
  });
  
  
  // Appendi gli elementi l'uno all'altro
  modal.appendChild(dialog);
  dialog.appendChild(content);
  content.appendChild(header);
  header.appendChild(title);
  content.appendChild(body);
  body.appendChild(text);
  content.appendChild(footer);
  footer.appendChild(button_ann);
  footer.appendChild(button_conferma);
  
  document.body.appendChild(modal);
  $(modal).modal('show');
  
  }
  function mostraPopupAnnulla(){
    const modal = document.createElement('div');
    modal.classList.add('modal', 'fade');
    modal.setAttribute('id', 'staticBackdrop');
    modal.setAttribute('data-bs-backdrop', 'static');
    modal.setAttribute('data-bs-keyboard', 'false');
    modal.setAttribute('tabindex', '-1');
    modal.setAttribute('aria-labelledby', 'staticBackdropLabel');
    modal.setAttribute('aria-hidden', 'true');
    
    const dialog = document.createElement('div');
    dialog.classList.add('modal-dialog', 'modal-dialog-centered');
    
    const content = document.createElement('div');
    content.classList.add('modal-content');
    content.setAttribute('style', 'border-radius: 41px;');
    
    const header = document.createElement('div');
    header.classList.add('modal-header');
    
    const title = document.createElement('h1');
    title.classList.add('modal-title', 'fs-5');
    title.setAttribute('id', 'staticBackdropLabel');
    title.innerHTML = 'Avviso';
    
    const body = document.createElement('div');
    body.classList.add('modal-body');
    
    const text = document.createElement('p');
    text.setAttribute('id', 'testo-pop-up');
    text.innerHTML = 'Le modifiche correnti verranno annullate.Sei sicuro di voler annullare l operazione?';
    const button_ann = document.createElement('button');
    button_ann.type = 'button';
    button_ann.classList.add('btn', 'btnannullaPopUp');
    button_ann.setAttribute('style', 'border-radius: 61px;');
    button_ann.innerHTML = 'NO';
    const button_conferma = document.createElement('button');
    button_conferma.type = 'button';
    button_conferma.classList.add('btn', 'btnconfermaPopUp');
    button_conferma.setAttribute('style', 'border-radius: 61px;');
    button_conferma.innerHTML = 'SI';
    button_ann.style.marginRight = '166px';
    
    const footer = document.createElement('div');
    footer.classList.add('modal-footer');
    button_ann.addEventListener('click', function() {
      // Codice per rimuovere il mock-up qui
      $(modal).modal('hide');
        
    
    });
    
    button_conferma.addEventListener('click', function(){
      //aggiunge che ritona alla home html
      window.location.assign("personalizzazione.html");
      
    });
    
    
    // Appendi gli elementi l'uno all'altro
    modal.appendChild(dialog);
    dialog.appendChild(content);
    content.appendChild(header);
    header.appendChild(title);
    content.appendChild(body);
    body.appendChild(text);
    content.appendChild(footer);
    footer.appendChild(button_ann);
    footer.appendChild(button_conferma);
    
    document.body.appendChild(modal);
    $(modal).modal('show');
    
    }
  document.getElementById('home').onclick =  function () {

     var ruolo=getCookie("ruolo");
    ruolo = ruolo.substring(1,ruolo.length -1);
    
    
      if(ruolo=="amministratore")
      window.location.replace("home-admin.html");
        if(ruolo=="supervisore")
        window.location.replace("home-supervisore.html");
    }
    document.getElementById('back').onclick =  function () {

     window.location.replace("personalizzazione.html");
      }

let elementi;
let array = [];
function elimina(modal,nome){
  const listaPrincipale = document.getElementById('ListaCategorie');
  const elementi = listaPrincipale.getElementsByTagName('li');
  for (let i = 0; i < elementi.length; i++) {
   
    const bottone = elementi[i].querySelector(".button_visualizza")
    if(bottone){
      const divs = bottone.parentNode;
      
      const figlio = divs.children[0];
     
      if(divs){
      for (let i = 0; i < divs.length; i++) {
       
        if (divs[i].textContent === nome) {
          
          divs[i].remove();
        }
      }
    }
      
    }
    
  }
  listaPrincipale.innerHTML='';
 
  let request = new XMLHttpRequest();
  nomelementomenu=nome;
    request.open("POST","http://87.3.142.174:8085/eliminazione_piatto_dalla_categoria/"+nomelementomenu);
      request.send();
      request.onload = () =>  {
      
        if(request.status == 200)
        {
        
          array=[];
          result = request.responseText;   
          $.ajax({
            url: 'http://87.3.142.174:8085/getCategorie',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
             for (let i = 0; i < data.length; i++) {
             
          }
           let elementi_nuovi=data;
      
      let currentIndex = 0;
      
      processArray(elementi_nuovi, currentIndex);

        
        }})
        $(modal).modal('hide');
          
        }
        
        }
    
}

 // document.getElementById("attesa").style.visibility = "hidden";
 
 

function sleep(s){
  var now = new Date().getTime();
  
  while(new Date().getTime() < now + (s*1000)){} 
}
function mostraPopup(nome){
const modal = document.createElement('div');
modal.classList.add('modal', 'fade');
modal.setAttribute('id', 'staticBackdrop');
modal.setAttribute('data-bs-backdrop', 'static');
modal.setAttribute('data-bs-keyboard', 'false');
modal.setAttribute('tabindex', '-1');
modal.setAttribute('aria-labelledby', 'staticBackdropLabel');
modal.setAttribute('aria-hidden', 'true');

const dialog = document.createElement('div');
dialog.classList.add('modal-dialog', 'modal-dialog-centered');

const content = document.createElement('div');
content.classList.add('modal-content');
content.setAttribute('style', 'border-radius: 41px;');

const header = document.createElement('div');
header.classList.add('modal-header');

const title = document.createElement('h1');
title.classList.add('modal-title', 'fs-5');
title.setAttribute('id', 'staticBackdropLabel');
title.innerHTML = 'Avviso';

const body = document.createElement('div');
body.classList.add('modal-body');

const text = document.createElement('p');
text.setAttribute('id', 'testo-pop-up');
text.innerHTML = 'Sei sicuro di voler eliminare '+nome+' ?';
const button_ann = document.createElement('button');
button_ann.type = 'button';
button_ann.classList.add('btn', 'btnannulla');
button_ann.setAttribute('style', 'border-radius: 61px;');
button_ann.innerHTML = 'NO';
const button_conferma = document.createElement('button');
button_conferma.type = 'button';
button_conferma.classList.add('btn', 'btnconferma');
button_conferma.setAttribute('style', 'border-radius: 61px;color:white');
button_conferma.innerHTML = 'SI';
button_ann.style.marginRight = '166px';

const footer = document.createElement('div');
footer.classList.add('modal-footer');
button_ann.addEventListener('click', function() {
  // Codice per rimuovere il mock-up qui
  $(modal).modal('hide');
    

});

button_conferma.addEventListener('click', function(){
  button_ann.style.display = "none";
  button_conferma.style.display = "none";
  title.innerHTML = 'Aggiornamento';
  text.innerHTML = 'Aggiornamento in corso..';
  elimina(modal,nome);
 
  
});


// Appendi gli elementi l'uno all'altro
modal.appendChild(dialog);
dialog.appendChild(content);
content.appendChild(header);
header.appendChild(title);
content.appendChild(body);
body.appendChild(text);
content.appendChild(footer);
footer.appendChild(button_ann);
footer.appendChild(button_conferma);

document.body.appendChild(modal);
$(modal).modal('show');

}
function processArray(arr, index){
  if (index >= arr.length) {
    
    return;
  }
  const listaPrincipale = document.getElementById('ListaCategorie');
  document.getElementById("attesa").style.visibility = "hidden";
  let request = new XMLHttpRequest();
    request.open("GET", "http://87.3.142.174:8085/numsottocategorie/" + arr[index]);
    request.send();
    request.onload = () => {
      if (request.status == 200) {
       
       
        result = request.responseText;
        const intero = parseInt(result);
        if(intero!=0&&arr[index]!='None')
            {
              const elemento_padre = document.createElement('li');
              elemento_padre.style.borderBottom = '2px solid black';
              elemento_padre.style.width = '430px';
                
              const lista = document.createElement('ul');
              lista.style.setProperty('list-style-type', 'none');
              $.ajax({
 
                url: 'http://87.3.142.174:8085/getsottocategorie/'+arr[index],
                type: 'GET',
                dataType: 'json',
                success: function(data) {
                 for (let i = 0; i < data.length; i++) {
                  
                  elemento_padre.textContent=arr[index];
                  listaPrincipale.appendChild(elemento_padre);
                  
                  const elemento = document.createElement('li');
                  
                  const bottone = document.createElement('button');
                  const bottone_nome=document.createElement('button');
                  bottone_nome.className="button_contenuto";
                  bottone_nome.textContent="-"+data[i];
                  bottone.className="button_visualizza";
                 
                  bottone.style.float = 'right';
                
                  bottone.addEventListener('mouseover', function(event) {
                    bottone.style.backgroundImage="url('./img/freccia-dx-blu.png')";
                    bottone_nome.style.border="2px solid rgb(70, 154, 227)"
                    bottone_nome.style.borderRadius = '30px';
                  });
                  let mouseoutHandler = function(event) {
                    bottone.style.backgroundImage = "url('./img/freccia-dx.png')";
                    bottone_nome.style.border = "none";
                  };
                  bottone.addEventListener('mouseout', mouseoutHandler);
                  const quadrato = document.createElement('div');
                    quadrato.style.display = 'block';
                    quadrato.style.position = 'absolute';
                    quadrato.style.width = '300px';
                    quadrato.style.height = '300px';
                    quadrato.style.border = '2px solid blue';
                    quadrato.style.backgroundColor='white';
                    quadrato.style.borderRadius = '13px';
                   
                  bottone.addEventListener('click', function(event) {

                    //bottone.removeEventListener('mouseout', mouseoutHandler);
                    bottone.style.backgroundImage="url('./img/freccia-dx-blu.png')";
                    bottone_nome.style.border="2px solid rgb(70, 154, 227)"
                    bottone_nome.style.borderRadius = '30px';
                    
                    // mostra il quadrato accanto al bottone
                    const elementiLista=listaPrincipale.querySelectorAll('li');
                   
                    for (let altroelemento of elementiLista) {
                      let bottone1 = altroelemento.querySelector('.button_contenuto');
                      let bottone2 = altroelemento.querySelector('.button_visualizza');
                     
                      if (altroelemento.textContent!=data[i]){
                  
                    if (bottone1) {
                        bottone1.style.border="none"; 
                      }
                      if (bottone2) {
                        bottone2.style.backgroundImage="url('./img/freccia-dx.png')";
                      }
                    }
                    }
                  quadrato.style.left = bottone.offsetLeft + bottone.offsetWidth + 'px';
                  quadrato.style.top = bottone.offsetTop + 'px';
                
                  var li = bottone.parentNode;
                 
                  let html = '';
                  html="     <strong>"+data[i]+"</strong>";
                  $.ajax({
                    url: 'http://87.3.142.174:8085/getelementidellacategoria/'+data[i],
                    type: 'GET',
                    dataType: 'json',
                    success: function(elementi) {
                      
                      for (let i = 0; i < elementi.length; i++) {
                        
                        html += `<div align="left"><span style="margin-left:10px;">${elementi[i]}</span><button style="background-image: url('./img/icona-x-cancellazione.jpg');
                    background-size: cover;border: none;;width:25px; height:22px; float:right; margin-right:8px;" onclick="mostraPopup('${elementi[i]}')";>
                    </button>
                    
                    </div>`;
                    
                      }
                   
                  quadrato.innerHTML = html;
                  for (let altroelemento of elementiLista) {
                    const div = altroelemento.querySelector('div');
                    let button = altroelemento.querySelector(".button_visualizza");
                    if(div!==null && altroelemento.textContent!=data[i]){
                    altroelemento.removeChild(div);
                  
                    button.addEventListener("mouseout",mouseoutHandler);
                    }
                  }
               
                  li.appendChild(quadrato);
                  li.addEventListener('click', function(event) {
                    
                      //quadrato.style.display = 'none';
                      li.appendChild(quadrato);
                      li.removeChild(quadrato);
                    
                      bottone.addEventListener('mouseout', mouseoutHandler);
                   
                     
                  });
                 
                  }

                  }
                  )
                  }
                  );
                  elemento.appendChild(bottone_nome);
                  elemento.appendChild(bottone);
                  lista.appendChild(elemento);
                  lista.style.marginBottom='29px';
                  listaPrincipale.appendChild(lista);
                 

              }//for
              //piatti della categoria
              $.ajax({
                url: 'http://87.3.142.174:8085/getelementi_dellaMacrocategoria/'+arr[index],
                type: 'GET',
                dataType: 'json',
                success: function(elementi) {
                 
                  for(i=0;i<elementi.length;i++){
                  const elemento = document.createElement('li');
                  const bottone_cancellazione = document.createElement('button');
                  const bottone_contenuto=document.createElement('button');
                  bottone_contenuto.className="button_contenuto";
                  let contenuto=elementi[i];
                  bottone_contenuto.textContent="-"+elementi[i];
                  bottone_cancellazione.className="button_cancellazione";
                  bottone_cancellazione.style.float = 'right';
                  bottone_cancellazione.addEventListener('mouseover', function(event) {
                    bottone_contenuto.style.border="2px solid rgb(70, 154, 227)"
                    bottone_contenuto.style.borderRadius = '30px';
                  });
                  let mouseoutHandler = function(event) {
                    bottone_contenuto.style.border = "none";
                  };
                  bottone_cancellazione.addEventListener('mouseout', mouseoutHandler);
                  bottone_cancellazione.addEventListener('click',function() {
                  
                   mostraPopup(contenuto);
                  });
                  elemento.appendChild(bottone_contenuto);
                  elemento.appendChild(bottone_cancellazione);
                  lista.appendChild(elemento);
                  lista.style.marginBottom='69px';
                  listaPrincipale.appendChild(lista);
                }




                  processArray(arr, index+1);

             
              }

              }
              )




              //fine piatti categoria
              //processArray(arr, index+1);
              
            }//success_data
          }
          )

            }else{
            if(arr[index]=='None'){
            
              const elemento_padre = document.createElement('li');
            elemento_padre.style.borderBottom = '2px solid black';
            elemento_padre.style.width = '430px';
            elemento_padre.textContent='Elementi del menu senza categoria';
            
                
            const lista = document.createElement('ul');
            $.ajax({
 
              url: 'http://87.3.142.174:8085/elementi_senza_categoria',
              type: 'GET',
              dataType: 'json',
              success: function(data) {
                for (let i = 0; i < data.length; i++) {
                  const elemento = document.createElement('li');
                    
                  const bottone = document.createElement('button');
                  const bottone_nome=document.createElement('button');
                  bottone_nome.className="button_contenuto";
                  bottone_nome.textContent="-"+data[i];
                  bottone.className="button_cancellazione";
                  bottone.style.float = 'right';
                  bottone.addEventListener('mouseover', function(event) {
                    bottone_nome.style.border="2px solid rgb(70, 154, 227)"
                    bottone_nome.style.borderRadius = '30px';
                  });
                  let mouseoutHandler = function(event) {
                    bottone_nome.style.border = "none";
                  };
                  bottone.addEventListener('mouseout', mouseoutHandler);
                  bottone.addEventListener('click',function() {
                   mostraPopup(data[i]);
                  });
                  listaPrincipale.appendChild(elemento_padre);
                  elemento.appendChild(bottone_nome);
                  elemento.appendChild(bottone);
                  lista.appendChild(elemento);
                  lista.style.marginBottom='65px';
                  listaPrincipale.appendChild(lista);
                 

                }
                processArray(arr, index+1);

              }
            }
              
              )
            }else{
            const elemento_padre = document.createElement('li');
            elemento_padre.style.borderBottom = '2px solid black';
            elemento_padre.style.width = '430px';
            elemento_padre.textContent=arr[index];
            
                
            const lista = document.createElement('ul');
            $.ajax({
 
              url: 'http://87.3.142.174:8085/getelementidellacategoria/'+arr[index],
              type: 'GET',
              dataType: 'json',
              success: function(data) {
                for (let i = 0; i < data.length; i++) {
                  const elemento = document.createElement('li');
                    
                  const bottone = document.createElement('button');
                  const bottone_nome=document.createElement('button');
                  bottone_nome.className="button_contenuto";
                  bottone_nome.textContent="-"+data[i];
                  bottone.className="button_cancellazione";
                  bottone.style.float = 'right';
                  bottone.addEventListener('mouseover', function(event) {
                    bottone_nome.style.border="2px solid rgb(70, 154, 227)"
                    bottone_nome.style.borderRadius = '30px';
                  });
                  let mouseoutHandler = function(event) {
                    bottone_nome.style.border = "none";
                  };
                  bottone.addEventListener('mouseout', mouseoutHandler);
                  bottone.addEventListener('click',function() {
                   mostraPopup(data[i]);
                  });
                  listaPrincipale.appendChild(elemento_padre);
                  elemento.appendChild(bottone_nome);
                  elemento.appendChild(bottone);
                  lista.appendChild(elemento);
                  lista.style.marginBottom='65px';
                  listaPrincipale.appendChild(lista);
                  //processArray(arr, index+1);

                }
                processArray(arr, index+1);

              }
            }
              
              )
          }
            }

      }
    }
  
  }

  function procArray(arr, index) {
    if (index >= arr.length) {
      
      return;
    }
    
    let request = new XMLHttpRequest();
    request.open("GET", "http://87.3.142.174:8085/numsottocategorie/" + arr[index]);
    request.send();
    request.onload = () => {
      if (request.status == 200) {
       
       
        result = request.responseText;
        const intero = parseInt(result);
        procArray(arr, index + 1);

      }
    }
  }
  
  
  
  

setTimeout(function() {
    $.ajax({
      url: 'http://87.3.142.174:8085/getCategorie',
      type: 'GET',
      dataType: 'json',
      success:function(data) {
       for (let i = 0; i < data.length; i++) {
        //inserimento_lista_Categorie(data[i]);
      
      }
      elementi=data;
      
      let currentIndex = 0;
     
      processArray(elementi, currentIndex);
        
    

    
  
  }})

  
  
  
  },2000);
  window.onbeforeunload = function(event) {
    event.preventDefault();
  };
  function getCookie(nomeCookie) {
    var name = nomeCookie + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }