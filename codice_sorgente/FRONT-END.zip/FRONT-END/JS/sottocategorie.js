
document.getElementById('button_conferma').addEventListener('mouseover', function() {
  if (this.disabled) return;
  this.style.fontWeight = 'bold';

});
document.getElementById('button_annulla').addEventListener('click', function() {
  window.close();
});
document.getElementById('button_conferma').addEventListener('click', function() {
  if (this.disabled) return;
  const listElements = document.querySelectorAll('#ListaCategorieSelezionate li');
      var j=0;
      listElements.forEach(function(li) {
        j++;
      let request = new XMLHttpRequest();
      var stringa_app=li.innerText;
      stringa_app=stringa_app.substring(0,stringa_app.length-1);
    
      request.open("POST","http://87.3.142.174:8085/settaggiocategorie/"+stringa_app+"/"+j);
      request.send();
      request.onload = () =>  {
    
        if(request.status == 200)
        {
          
          result = request.responseText;   
        }
        
        }

      });
      window.close();
      
});


function premi(nome) {
const listElements = document.querySelectorAll('#ListaCategorieSelezionate li');
listElements.forEach(function(li) {
  const list = document.getElementById('ListaCategorieSelezionate');
  // Fai qualcosa con ogni elemento li della lista
  var nomeCateg=nome;
  var stringaprincipale=li.innerText;
  var stringa_modificata; 
  var stringa;
  if(stringaprincipale.includes('Ordina Sottocategorie')){
  var stringa=stringaprincipale.replace('Ordina Sottocategorie','');
  stringa_modificata=stringa.replace(/\s/g, '');
  nomeCateg=nomeCateg.replace(/\s/g, '');
 
  if(stringa_modificata === nomeCateg){
    list.removeChild(li);
    inseriment_lista_sx(nome);
  }
  //stringa=stringa.replace("","");
}else{
  stringa=stringaprincipale.replace(/\s/g, '');
  nomeCateg=nomeCateg.replace(/\s/g, '');
 
  if(stringa === nomeCateg){
    list.removeChild(li);
    inseriment_lista_sx(nome);
  }
}
  
});

}

// Rimuovi l'elemento dalla lista
//list.removeChild(elementToRemove);
//inseriment_lista_sx(nome);
//}
document.getElementById('button_conferma').addEventListener('mouseout', function() {
  if (this.disabled) return;
  this.style.fontWeight = 'normal';
});
document.getElementById('button_conferma').addEventListener('mouseout', function() {
  if (this.disabled) return;
  this.style.fontWeight = 'normal';
});
function showButton(button) {
  button.style.display = 'inline';
}
function premirimuovi(nome) {
}
function inseriment_lista_sx(nome){
  const list = document.getElementById('ListaCategorie');
  const button = document.createElement('button');
    button.textContent = nome;
    button.setAttribute('style', 'height: 50px; width: 100px; color:rgb(70, 154, 227) ; background-color: white; border:2px solid rgb(70, 154, 227); border-radius: 30px;  margin: 10px; margin-left:25px; font-size: 16px; display: block;');
    button.addEventListener('click', function() {
      this.setAttribute('style', 'display: none;');
      const targetList = document.getElementById('ListaCategorieSelezionate');
      const emptyListItem = targetList.querySelector('li:empty');
      //content=this.textContent; 
      const content=nome;
      emptyListItem.innerHTML = `
      ${content}
        <button onclick="premi('${content}')" id="bottonerimuovi" style="margin-left:10px"></button>`;
    });
      const targetList = document.getElementById('ListaCategorieSelezionate');
      const listItem = document.createElement('li');
      listItem.setAttribute('style', 'height:30px; width:400px; color:rgb(70, 154, 227) ; background-color: white; border-bottom:1px solid rgb(70, 154, 227);margin: 10px; margin-left:250px;font-size: 16px; display: block;');
    
      
      targetList.appendChild(listItem);
      
      list.appendChild(button);
}

function abilitazione_conferma() {
const targetList = document.getElementById('ListaCategorieSelezionate');
const listItems = targetList.querySelectorAll('li');
const hasEmptyText = [...listItems].some(item => item.textContent === '');
const targetButton = document.getElementById('button_conferma');

if (hasEmptyText) {
  targetButton.disabled = true;
  targetButton.style.color = 'gray';
  targetButton.style.borderColor = 'gray'
} else {
  targetButton.disabled = false;
  targetButton.style.borderColor = 'rgb(70, 154, 227)';
  targetButton.style.color='rgb(70, 154, 227)';
 
  

}}
setInterval(abilitazione_conferma,1000);
setTimeout(function() {
  
urlParams = new URLSearchParams(window.location.search);
nomeCategoria = urlParams.get('nomeCategoria'); 
 
 var elemento = document.getElementById("testotitoloCateg");
 
  elemento.innerHTML = "<strong>ORDINA SOTTOCATEGORIE DI " +nomeCategoria+"<strong>";
$.ajax({
 
  url: 'http://87.3.142.174:8085/getsottocategorie/'+nomeCategoria,
  type: 'GET',
  dataType: 'json',
  success: function(data) {
   for (let i = 0; i < data.length; i++) {
    inseriment_lista_sx(data[i]);
   
}}})
},1000);
window.onbeforeunload = function(event) {
  event.preventDefault();
};
