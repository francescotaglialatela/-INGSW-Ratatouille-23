
document.getElementById('btn-visualizza').onclick = function filtraDati() {
  const data_inizio = document.getElementById("data1");
  const dateTimeValue = data_inizio.value;
  var dataInizio = new Date(dateTimeValue);

  const data_fine = document.getElementById("data2");
  const dateTimeValue2 = data_fine.value;
  var dataFine = new Date(dateTimeValue2);

  if (isNaN(dataInizio.getTime())) {

    // Recupero l'elemento dell'alert
    var alert = document.getElementById('alert-warning');
    alert.innerHTML = "Attenzione! Non hai inserito una data di inizio valida, per favore riprova!"
    // Mostro l'alert
    alert.style.display = "block";
    alert.style.opacity = 1;

    // Dopo 5 secondi, faccio scomparire l'alert con un effetto di dissolvenza
    setTimeout(function dissolvenzalert () {
      var fadeEffect = setInterval(function () {
        if (!alert.style.opacity) {
          alert.style.opacity = 1;
        }
        if (alert.style.opacity > 0) {
          alert.style.opacity -= 0.1;
        } else {
          clearInterval(fadeEffect);
        }
      }, 50);
    }, 5000);

  } else if (isNaN(dataFine.getTime())) {

    // Recupero l'elemento dell'alert
    var alert = document.getElementById('alert-warning');
    alert.innerHTML = "Attenzione! Non hai inserito una data di fine valida, per favore riprova!"
    // Mostro l'alert
    alert.style.display = "block";
    alert.style.opacity = 1;

    // Dopo 5 secondi, faccio scomparire l'alert con un effetto di dissolvenza
    setTimeout(function () {
      var fadeEffect = setInterval(function () {
        if (!alert.style.opacity) {
          alert.style.opacity = 1;
        }
        if (alert.style.opacity > 0) {
          alert.style.opacity -= 0.1;
        } else {
          clearInterval(fadeEffect);
        }
      }, 50);
    }, 5000);

  } else {
    var year = dataInizio.getFullYear();
    var month = dataInizio.getMonth() + 1;
    var day = dataInizio.getDate();
    var hour = dataInizio.getHours();
    var min = dataInizio.getMinutes();
    var sec = dataInizio.getSeconds();

    dataInizio = `${year}-${month.toString().padStart(2, "0")}-${day.toString().padStart(2, "0")} ${hour.toString().padStart(2, "0")}:${min.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`;

    year = dataFine.getFullYear();
    month = dataFine.getMonth() + 1;
    day = dataFine.getDate();
    hour = dataFine.getHours();
    min = dataFine.getMinutes();
    sec = dataFine.getSeconds();

    dataFine = `${year}-${month.toString().padStart(2, "0")}-${day.toString().padStart(2, "0")} ${hour.toString().padStart(2, "0")}:${min.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`;

    caricaPaginaStatitiche(dataInizio.toString(),dataFine.toString());
  }

}

function caricaPaginaStatitiche(dataInizio, dataFine)
{
  location.href = 'visualizzazionestatistiche.html?dataInizio='+dataInizio+'&dataFine='+dataFine;
}


document.getElementById("freccia-back").onclick = function () {
  var ruolo=getCookie("ruolo");
      ruolo = ruolo.substring(1,ruolo.length -1);
     
      
        if(ruolo=="amministratore")
        window.location.replace("home-admin.html");
}
function getCookie(nomeCookie) {
  var name = nomeCookie + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(';');
  for(var i = 0; i <ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}