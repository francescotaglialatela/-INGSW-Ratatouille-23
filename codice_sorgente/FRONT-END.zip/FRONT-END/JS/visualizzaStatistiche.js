window.onload = function() {
    statistichePiattiFrequenti();
    creaStatisticheOrdiniEvasi();
}

function statistichePiattiFrequenti() {

    var urlParams = new URLSearchParams(window.location.search);
    var dataInizio = urlParams.get("dataInizio");
    dataInizio = decodeURIComponent(dataInizio);

    var dataFine = urlParams.get("dataFine");
    dataFine = decodeURIComponent(dataFine);

    let request = new XMLHttpRequest();
    request.open("GET", "http://87.3.142.174:8085/recupera/dati/piatti-frequenti/" + dataInizio + "/" + dataFine);
    request.send();
    request.onload = () => {

        if (request.status == 200) {

            let arrayDati = JSON.parse(request.responseText);

            generaGraficoPiattiFrequenti(arrayDati);

        }
    }
}

function creaStatisticheOrdiniEvasi() {

    var urlParams = new URLSearchParams(window.location.search);
    var dataInizio = urlParams.get("dataInizio");
    dataInizio = decodeURIComponent(dataInizio);

    var dataFine = urlParams.get("dataFine");
    dataFine = decodeURIComponent(dataFine);
  
    let request = new XMLHttpRequest();
    request.open("GET", "http://87.3.142.174:8085/recupera/dati/ordini-evasi/" + dataInizio + "/" + dataFine);
    request.send();
    request.onload = () => {
  
      if (request.status == 200) {
  
        let arrayDati = JSON.parse(request.responseText);
  
        generaGraficoOrdiniEvasi(arrayDati);   
  
      }
    }
}

/*METODO PER L'HOVER DI TASTO HOME*/

const element = document.querySelector('#home');

element.addEventListener('mouseenter', () => {
    element.classList.add('hover');
    const image = document.querySelector('#home');
    image.src = './img/home-hovered.png';
})


element.addEventListener('mouseleave', () => {
    const image = document.querySelector('#home');
    image.src = './img/home-basic.png';
    element.classList.remove('hover');
})

element.onclick = function backHome() {
    var ruolo=getCookie("ruolo");
    ruolo = ruolo.substring(1,ruolo.length -1);
    
    
      if(ruolo=="amministratore")
      window.location.replace("home-admin.html");
}
function getCookie(nomeCookie) {
    var name = nomeCookie + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }
document.getElementById("freccia-back").onclick = function () {
    location.href = 'statistiche.html';
}


function generaGraficoPiattiFrequenti(data) {
    
    var canvasElement = document.getElementById("produttività");
    var config = {
        type: "bar",
        data: {
            labels: [],
            datasets: [
                {
                    label: "Numero di volte ordinato",
                    data: [],
                    backgroundColor: [
                        "rgba(255,0,0,0.2)",
                        "rgba(54,162,235,0.2)",
                        "rgba(153,102,255,0.2)",
                    ],
                    borderColor: [
                        "rgba(255,0,0,1)",
                        "rgba(54,162,235,1)",
                        "rgba(153,102,255,1)",
                    ],
                    borderWidth: 1,
                },
            ],
        },
        options: {
            scales: {
                y: {
                    ticks: {
                        min: 0,
                    }
                },
            },
        },
    };


    for (var i = 0; i < data.length; i++) {
        config.data.labels.push(data[i].nome);
        config.data.datasets[0].data.push((data[i]).valore);
    }
    config.data.datasets[0].data.push(0);
    var produttività = new Chart(canvasElement, config);
}





function generaGraficoOrdiniEvasi(dataPiattoUtilizzabili) {
    var canvasElement = document.getElementById("ordini-evasi");
    var config = {
        type: "bar",
        data: {
            labels: [],
            datasets: [
                {
                    label: "Numero di ordini effettuati",
                    data: [],
                    backgroundColor: [
                        "rgba(255,0,0,0.2)",
                        "rgba(54,162,235,0.2)",
                        "rgba(153,102,255,0.2)",
                    ],
                    borderColor: [
                        "rgba(255,0,0,1)",
                        "rgba(54,162,235,1)",
                        "rgba(153,102,255,1)",
                    ],
                    borderWidth: 1,
                },
            ],
        },
        options: {
            scales: {
                y: {
                    gridLines: {
                        zeroLineWidth: 2,
                        zeroLineColor: "rgba(0, 0, 0, 1)",
                    }
                },
            },
        },
    };


    var cumulativoOrdini = new Array();
    var j = 0;

    for (var i = 2; i < dataPiattoUtilizzabili.length; i += 3) {
        cumulativoOrdini[j] = dataPiattoUtilizzabili[i];
        j++;
    }

    for (var i = 0; i < dataPiattoUtilizzabili.length; i++) {
        if (i % 3 == 0)
            config.data.labels.push(dataPiattoUtilizzabili[i]);

        if (i % 3 == 1) {
            config.data.datasets[0].data.push(parseInt(dataPiattoUtilizzabili[i]));
        }
    }
    config.data.datasets[0].data.push(0);
    var produttività = new Chart(canvasElement, config);






    for (var i = 0; i < config.data.labels.length; i++) {
        var row = document.createElement("tr");
        var colorCell = document.createElement("td");
        colorCell.style.backgroundColor = config.data.datasets[0].backgroundColor[i];
        colorCell.style.borderColor = config.data.datasets[0].borderColor[i];
       
        var nameCell = document.createElement("td"); //NOME
        nameCell.innerHTML = config.data.labels[i].split(" ")[0];
        var cognomeCell = document.createElement("td"); //COGNOME
        cognomeCell.innerHTML = config.data.labels[i].split(" ")[1];
        var emailCell = document.createElement("td"); //EMAIL
        emailCell.innerHTML = config.data.labels[i].substring(config.data.labels[i].indexOf("(") + 1, config.data.labels[i].indexOf(")"));
        var dataCell = document.createElement("td");
        dataCell.innerHTML = cumulativoOrdini[i]+"€";

        row.appendChild(colorCell);
        row.appendChild(nameCell);
        row.appendChild(cognomeCell);
        row.appendChild(emailCell);
        row.appendChild(dataCell);
        document.querySelector(".tabella table").appendChild(row);
    }



}

